"""Database layer: one connection object, schema creation and first-run seeding.

OOP ideas used here
-------------------
* Encapsulation : the sqlite3 connection is private to the Database class.
* Singleton     : Database.instance() hands out one shared object so every
                  repository talks to the same file.
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCHEMA_FILE = ROOT / "schema.sql"
SEED_FILE = ROOT / "data" / "seed.json"
DEFAULT_DB = ROOT / "uniguy.db"


class Database:
    _instance: "Database | None" = None

    def __init__(self, path: str | Path = DEFAULT_DB):
        self._path = str(path)
        self._conn = sqlite3.connect(self._path)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._create_schema()
        if self._is_empty():
            Seeder(self).run()

    # ----- singleton access -------------------------------------------------
    @classmethod
    def instance(cls, path: str | Path | None = None) -> "Database":
        if cls._instance is None:
            cls._instance = cls(path or DEFAULT_DB)
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Close and forget the shared instance (used by the tests)."""
        if cls._instance is not None:
            cls._instance.close()
        cls._instance = None

    # ----- small public API -------------------------------------------------
    def execute(self, sql: str, params: tuple | list = ()) -> sqlite3.Cursor:
        cur = self._conn.execute(sql, params)
        self._conn.commit()
        return cur

    def query(self, sql: str, params: tuple | list = ()) -> list[sqlite3.Row]:
        return self._conn.execute(sql, params).fetchall()

    def query_one(self, sql: str, params: tuple | list = ()) -> sqlite3.Row | None:
        return self._conn.execute(sql, params).fetchone()

    def transaction(self):
        """Use as `with db.transaction():` to group several writes."""
        return self._conn

    def close(self) -> None:
        self._conn.close()

    # ----- internals --------------------------------------------------------
    def _create_schema(self) -> None:
        self._conn.executescript(SCHEMA_FILE.read_text(encoding="utf-8"))
        self._conn.commit()

    def _is_empty(self) -> bool:
        return self.query_one("SELECT COUNT(*) AS n FROM horses")["n"] == 0


class Seeder:
    """Loads data/seed.json (the data that used to live inside UniGuy.html)."""

    def __init__(self, db: Database):
        self.db = db
        self.data = json.loads(SEED_FILE.read_text(encoding="utf-8"))

    def run(self) -> None:
        with self.db.transaction():
            self._umamusume()
            self._apex()
            self._maps()
            self.db.execute(
                "INSERT OR IGNORE INTO users (name, color) VALUES (?,?)",
                ("Player One", "#3fd8c6"),
            )

    def _umamusume(self) -> None:
        run = self.db.execute
        for h in self.data["horses"]:
            a = h["apt"]
            run("INSERT INTO horses (name, apt_sprint, apt_mile, apt_medium, apt_long) "
                "VALUES (?,?,?,?,?)", (h["name"], *a))
        for s in self.data["skills"]:
            run("INSERT INTO skills (name, category, tier, description) VALUES (?,?,?,?)",
                (s["name"], s["category"], s["tier"], s["desc"]))
        skill_ids = {r["name"]: r["id"] for r in self.db.query("SELECT id, name FROM skills")}
        for c in self.data["cards"]:
            b = c["bonus"]
            cur = run(
                "INSERT INTO support_cards (name, rarity, type, rating, b_speed, b_stamina, "
                "b_power, b_guts, b_wisdom) VALUES (?,?,?,?,?,?,?,?,?)",
                (c["name"], c["rarity"], c["type"], c["rating"],
                 b["Speed"], b["Stamina"], b["Power"], b["Guts"], b["Wisdom"]))
            for sk in c["skills"]:
                run("INSERT OR IGNORE INTO card_skills (card_id, skill_id) VALUES (?,?)",
                    (cur.lastrowid, skill_ids[sk]))

    def _apex(self) -> None:
        run = self.db.execute
        for c in self.data["classes"]:
            run("INSERT INTO legend_classes (name, color, playstyle) VALUES (?,?,?)",
                (c["name"], c["color"], c["play"]))
        class_ids = {r["name"]: r["id"] for r in self.db.query("SELECT id, name FROM legend_classes")}
        for l in self.data["legends"]:
            guide = self.data["guide"].get(l["id"], {}).get("meta", {})
            cur = run("INSERT INTO legends (name, class_id, description, meta_combo, meta_why) "
                      "VALUES (?,?,?,?,?)",
                      (l["name"], class_ids[l["cls"]], l["desc"],
                       guide.get("combo", ""), guide.get("why", "")))
            lid = cur.lastrowid
            perks = self.data["perks"].get(l["id"])
            if not perks:
                continue
            for lvl, key in (("blue", "b"), ("purple", "p")):
                for i, (pname, pdesc) in enumerate(perks[key]):
                    meta = 1 if guide and guide.get(lvl) == i else 0
                    run("INSERT INTO legend_perks (legend_id, level, name, description, is_meta) "
                        "VALUES (?,?,?,?,?)", (lid, lvl, pname, pdesc, meta))
            for pname in perks["c"]:
                run("INSERT INTO legend_perks (legend_id, level, name) VALUES (?,?,?)",
                    (lid, "passive", pname))

        for wc in self.data["wclass"]:
            run("INSERT INTO weapon_classes (name, kind, ammo, blurb) VALUES (?,?,?,?)",
                (wc["n"], wc["k"], wc["ammo"], wc["blurb"]))
            cid = self.db.query_one("SELECT id FROM weapon_classes WHERE name=?", (wc["n"],))["id"]
            for name, optic, notes in wc["w"]:
                stats = self.data["pgw"].get(name, [0, 0, 0, 0, 0, 0, 0, 0])
                rof = stats[3] or self.data["pgrof"].get(name, 0)
                rec = self.data["grec"].get(name, ["", "", "", "", "", 0])
                run("INSERT INTO weapons (name, class_id, optic, notes, damage, headshot, mag_size, "
                    "fire_rate, reload_time, recoil_ctrl, hipfire, handling, rec_mag, rec_barrel, "
                    "rec_stock, rec_corrupted, rec_note) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (name, cid, optic, notes, stats[0], stats[1], stats[2], rof, stats[4],
                     stats[5], stats[6], stats[7], rec[0], rec[1], rec[2], rec[3], rec[4]))

    def _maps(self) -> None:
        run = self.db.execute
        for m in self.data["maps"]:
            cur = run("INSERT INTO maps (name, description) VALUES (?,?)", (m["n"], m["d"]))
            for legend_name, reason in m["r"]:
                lg = self.db.query_one("SELECT id FROM legends WHERE name=?", (legend_name,))
                if lg:
                    run("INSERT OR IGNORE INTO map_legends (map_id, legend_id, reason) VALUES (?,?,?)",
                        (cur.lastrowid, lg["id"], reason))
