"""Business logic (no SQL and no GUI code in here).

OOP ideas used here
-------------------
* Polymorphism : TierService sorts any list of Rankable objects with score().
* Abstraction  : Attachment is abstract; every attachment type implements apply().
* Inheritance  : Magazine, Barrel, Stock and the Corrupted* classes extend Attachment.
* Composition  : WeaponBuild HAS a Weapon and a list of Attachments.
"""
from __future__ import annotations

import math
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from .models import Deck, Horse, Rankable, SupportCard, TIERS, TRACKS, Weapon

# ==========================================================================
# Tier lists
# ==========================================================================
class TierService:
    """Split a list of Rankable objects into S/A/B/C/D by percentile."""

    CUTS = (0.15, 0.40, 0.70, 0.90, 1.0)

    @classmethod
    def tierize(cls, items: list[Rankable]) -> dict[str, list[Rankable]]:
        ordered = sorted(items, key=lambda x: x.score(), reverse=True)   # polymorphic call
        result: dict[str, list] = {t: [] for t in TIERS}
        for i, item in enumerate(ordered):
            ratio = (i + 1) / len(ordered)
            for tier, cut in zip(TIERS, cls.CUTS):
                if ratio <= cut + 1e-9:
                    result[tier].append(item)
                    break
        return result

    @classmethod
    def tier_of(cls, item: Rankable, items: list[Rankable]) -> str:
        for tier, members in cls.tierize(items).items():
            if any(m is item or (getattr(m, "id", None) == getattr(item, "id", 0)) for m in members):
                return tier
        return "D"


# ==========================================================================
# Deck builder
# ==========================================================================
FIT = {   # how well each support type suits each track length
    "Sprint": {"Speed": 1, "Power": .9, "Wisdom": .7, "Guts": .6, "Stamina": .4, "Friend": .6},
    "Mile":   {"Speed": 1, "Power": .85, "Wisdom": .8, "Guts": .6, "Stamina": .5, "Friend": .6},
    "Medium": {"Speed": 1, "Power": .8, "Wisdom": .8, "Stamina": .7, "Guts": .6, "Friend": .6},
    "Long":   {"Speed": .9, "Stamina": 1, "Power": .7, "Wisdom": .8, "Guts": .6, "Friend": .6},
}


@dataclass
class DeckAnalysis:
    totals: dict[str, int]
    skills: list[str]
    fits: list[tuple[SupportCard, int]]
    average_fit: int
    warnings: list[str] = field(default_factory=list)


class DeckService:
    @staticmethod
    def analyse(deck: Deck) -> DeckAnalysis:
        horse: Horse = deck.horse
        apt = horse.aptitude(deck.track)
        totals = {k: 0 for k in SupportCard.STATS}
        skills: list[str] = []
        fits = []
        for card in deck.cards:
            for stat, value in card.bonuses.items():
                totals[stat] += value
            for s in card.skills:
                if s.name not in skills:
                    skills.append(s.name)
            fit = round(FIT[deck.track][card.type] * (0.6 + 0.4 * apt / 10) * 100)
            fits.append((card, fit))
        average = round(sum(f for _, f in fits) / len(fits)) if fits else 0

        warnings = []
        if len(deck.cards) < Deck.MAX_CARDS:
            warnings.append(f"Deck has {len(deck.cards)} of {Deck.MAX_CARDS} cards.")
        types: dict[str, int] = {}
        for c in deck.cards:
            types[c.type] = types.get(c.type, 0) + 1
        if "Friend" not in types:
            warnings.append("No Friend card. Training bonuses may be lower.")
        for t, n in types.items():
            if n > 3:
                warnings.append(f"More than three {t} cards.")
        if apt < 5:
            warnings.append(f"{horse.name} has low {deck.track.lower()} aptitude in the sample data.")
        return DeckAnalysis(totals, skills, fits, average, warnings)


# ==========================================================================
# Gacha calculator
# ==========================================================================
@dataclass
class GachaResult:
    carats: int
    pulls: int
    total: int
    probability: float          # chance (%) of the featured character
    remaining: int              # pulls still needed to reach pity
    carats_needed: int
    days_more: int
    series: list[int]           # total pulls on each day
    milestones: list[tuple[int, float]]


class GachaCalculator:
    def __init__(self, params: dict[str, float]):
        self.p = params

    def _chance(self, pulls: int) -> float:
        if pulls >= self.p["pity"]:
            return 100.0
        return round((1 - (1 - self.p["feat"] / 100) ** pulls) * 1000) / 10

    def calculate(self) -> GachaResult:
        g = self.p
        per = max(1, g["perpull"])
        days = int(g["days"])
        carats = g["carats"] + days * g["daily"] + (days // 7) * g["weekly"] + (days // 30) * g["monthly"] + g["events"]
        pulls = math.floor(g["tickets"] + carats / per)
        total = int(g["spent"] + pulls)
        remaining = max(0, int(g["pity"] - total))
        need = int(remaining * per)
        avg_daily = g["daily"] + g["weekly"] / 7 + g["monthly"] / 30
        days_more = math.ceil(need / avg_daily) if remaining > 0 and avg_daily > 0 else 0
        series = []
        for d in range(0, max(1, days) + 1):
            cr = g["carats"] + d * g["daily"] + (d // 7) * g["weekly"] + (d // 30) * g["monthly"] + (g["events"] if d > 0 else 0)
            series.append(int(math.floor(g["tickets"] + cr / per) + g["spent"]))
        miles = [(n, self._chance(n)) for n in (50, 100, 150, 200)]
        return GachaResult(int(carats), int(pulls), total, self._chance(total), remaining, need,
                           days_more, series, miles)


# ==========================================================================
# Weapon builder (attachments)
# ==========================================================================
LEVEL_NAMES = ("None", "Level 1 (white)", "Level 2 (blue)", "Level 3 (purple)")


@dataclass
class BuildStats:
    damage: float
    headshot: float
    mag_size: float
    fire_rate: float
    reload_time: float
    recoil_ctrl: float
    hipfire: float
    handling: float
    move_bonus: bool = False

    @classmethod
    def from_weapon(cls, w: Weapon) -> "BuildStats":
        s = w.stats
        return cls(s["damage"], s["headshot"], s["mag_size"], s["fire_rate"], s["reload_time"],
                   s["recoil_ctrl"], s["hipfire"], s["handling"])

    def clamp(self) -> None:
        for f in ("recoil_ctrl", "hipfire", "handling"):
            setattr(self, f, max(0.0, min(100.0, getattr(self, f))))


# which attachment slots each weapon kind can use
SLOTS = {
    "shotgun": {"barrel": None,    "stock": "std"},
    "smg":     {"barrel": "laser", "stock": "std"},
    "pistol":  {"barrel": "laser", "stock": None},
    "ar":      {"barrel": "stab",  "stock": "std"},
    "lmg":     {"barrel": "stab",  "stock": "std"},
    "dmr":     {"barrel": None,    "stock": "snp"},
    "snp":     {"barrel": None,    "stock": "snp"},
}


class Attachment(ABC):
    name = "Attachment"

    @abstractmethod
    def apply(self, stats: BuildStats, base: BuildStats) -> None:
        """Change the stats in place."""


class Magazine(Attachment):
    SIZE = (1, 1.17, 1.33, 1.5)
    RELOAD = (1, 1, .95, .9)

    def __init__(self, level: int):
        self.level = level
        self.name = f"Magazine - {LEVEL_NAMES[level]}"

    def apply(self, stats, base):
        stats.mag_size = base.mag_size * self.SIZE[self.level]
        stats.reload_time = base.reload_time * self.RELOAD[self.level]


class Barrel(Attachment):
    TABLE = {"stab": ("recoil_ctrl", (0, 5, 10, 16), "Barrel Stabilizer"),
             "laser": ("hipfire", (0, 6, 10, 16), "Laser Sight")}

    def __init__(self, kind: str, level: int):
        self.kind, self.level = kind, level
        self.name = f"{self.TABLE[kind][2]} - {LEVEL_NAMES[level]}"

    def apply(self, stats, base):
        field_name, bonus, _ = self.TABLE[self.kind]
        setattr(stats, field_name, getattr(stats, field_name) + bonus[self.level])


class Stock(Attachment):
    HANDLING = (0, 6, 10, 14)
    RELOAD = (1, .96, .93, .9)

    def __init__(self, kind: str, level: int):
        self.kind, self.level = kind, level
        label = "Standard Stock" if kind == "std" else "Sniper Stock"
        self.name = f"{label} - {LEVEL_NAMES[level]}"

    def apply(self, stats, base):
        stats.handling += self.HANDLING[self.level]
        stats.reload_time *= self.RELOAD[self.level]


class CorruptedAttachment(Attachment, ABC):
    """One per gun. Strong buff with a drawback."""
    buff = ""
    drawback = ""

    @abstractmethod
    def compatible(self, slots: dict) -> bool: ...


class OverflowingMagazine(CorruptedAttachment):
    name, buff, drawback = "Overflowing Magazine", "Mag size beyond purple", "Slower reload"

    def compatible(self, slots): return True

    def apply(self, s, b):
        s.mag_size = b.mag_size * 1.8
        s.reload_time *= 1.12


class HeadseekerBarrel(CorruptedAttachment):
    name = "Headseeker Barrel"
    buff, drawback = "Higher headshot damage, purple-barrel recoil", "Worse hipfire accuracy"

    def compatible(self, slots): return slots["barrel"] == "stab"

    def apply(self, s, b):
        s.headshot *= 1.15
        s.recoil_ctrl = max(s.recoil_ctrl, b.recoil_ctrl + 16)
        s.hipfire -= 12


class TacticalLaser(CorruptedAttachment):
    name = "Tactical Laser"
    buff, drawback = "Faster reload, purple-laser hipfire", "Worse ADS recoil control"

    def compatible(self, slots): return slots["barrel"] == "laser"

    def apply(self, s, b):
        s.reload_time *= .9
        s.hipfire = max(s.hipfire, b.hipfire + 16)
        s.recoil_ctrl -= 10


class AgileStandardStock(CorruptedAttachment):
    name = "Agile Standard Stock"
    buff = "No move speed penalty, purple-stock reload and handling"
    drawback = "Smaller magazine"

    def compatible(self, slots): return slots["stock"] == "std"

    def apply(self, s, b):
        s.reload_time = min(s.reload_time, b.reload_time * .9)
        s.handling = max(s.handling, b.handling + 14)
        s.mag_size *= .8
        s.move_bonus = True


class RapidSniperStock(CorruptedAttachment):
    name = "Rapid Sniper Stock"
    buff, drawback = "Higher rate of fire, purple-stock reload and handling", "Smaller magazine"

    def compatible(self, slots): return slots["stock"] == "snp"

    def apply(self, s, b):
        s.fire_rate *= 1.1
        s.reload_time = min(s.reload_time, b.reload_time * .9)
        s.handling = max(s.handling, b.handling + 14)
        s.mag_size *= .8


CORRUPTED = {c.name: c for c in (OverflowingMagazine(), HeadseekerBarrel(), TacticalLaser(),
                                 AgileStandardStock(), RapidSniperStock())}


class WeaponBuild:
    """A weapon plus the attachments the player chose."""

    def __init__(self, weapon: Weapon, mag: int = 3, barrel: int = 0, stock: int = 3,
                 corrupted: str = ""):
        self.weapon = weapon
        self.slots = SLOTS.get(weapon.weapon_class.kind, {"barrel": None, "stock": None})
        self.attachments: list[Attachment] = [Magazine(mag)]
        if self.slots["barrel"]:
            self.attachments.append(Barrel(self.slots["barrel"], barrel))
        if self.slots["stock"]:
            self.attachments.append(Stock(self.slots["stock"], stock))
        self.corrupted = CORRUPTED.get(corrupted)
        if self.corrupted and not self.corrupted.compatible(self.slots):
            self.corrupted = None
        if self.corrupted:
            self.attachments.append(self.corrupted)

    @property
    def base(self) -> BuildStats:
        return BuildStats.from_weapon(self.weapon)

    def calculate(self) -> BuildStats:
        base = self.base
        stats = BuildStats.from_weapon(self.weapon)
        for a in self.attachments:                 # polymorphism: each one applies itself
            a.apply(stats, base)
        stats.clamp()
        return stats

    @staticmethod
    def corrupted_options(weapon: Weapon) -> list[str]:
        slots = SLOTS.get(weapon.weapon_class.kind, {"barrel": None, "stock": None})
        return [n for n, c in CORRUPTED.items() if c.compatible(slots)]
