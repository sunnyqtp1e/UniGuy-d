"""Domain classes (the "M" of the app).

OOP ideas used here
-------------------
* Abstraction   : Entity and Rankable are abstract base classes (cannot be instantiated).
* Inheritance   : Horse, Skill, SupportCard, Legend ... all extend Entity.
* Polymorphism  : every Rankable answers score() in its own way, so one TierService
                  can build a tier list out of horses, cards or skills.
* Encapsulation : attributes are private (_name, _rating ...) and exposed through
                  properties that validate the value before it is stored.
* Composition   : a SupportCard HAS Skills, a Deck HAS a Horse and SupportCards,
                  a Legend HAS a LegendClass and Perks.
"""
from __future__ import annotations

from abc import ABC, abstractmethod

TRACKS = ("Sprint", "Mile", "Medium", "Long")
STAT_TYPES = ("Speed", "Stamina", "Power", "Guts", "Wisdom", "Friend")
RARITIES = ("R", "SR", "SSR")
TIERS = ("S", "A", "B", "C", "D")
SKILL_CATEGORIES = ("Speed", "Acceleration", "Recovery", "Position", "Debuff", "Gold", "Unique")


class ValidationError(ValueError):
    """Raised when a model receives a value that breaks a rule."""


def _clean_text(value: str, label: str = "Name") -> str:
    value = (value or "").strip()
    if not value:
        raise ValidationError(f"{label} cannot be empty.")
    return value


def _in_range(value, low, high, label: str):
    try:
        value = float(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{label} must be a number.") from None
    if not low <= value <= high:
        raise ValidationError(f"{label} must be between {low} and {high}.")
    return value


# --------------------------------------------------------------------------
# Abstract base classes
# --------------------------------------------------------------------------
class Entity(ABC):
    """Anything that is stored as one row in the database."""

    TABLE = ""          # table name, set by every subclass
    LABEL = "Item"      # human name shown in the GUI

    def __init__(self, name: str, id: int | None = None):
        self._id = id
        self.name = name

    @property
    def id(self) -> int | None:
        return self._id

    @id.setter
    def id(self, value: int) -> None:      # set once by the repository after INSERT
        self._id = value

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = _clean_text(value)

    @abstractmethod
    def record(self) -> dict:
        """Column -> value mapping used by the repository for INSERT / UPDATE."""

    @abstractmethod
    def summary(self) -> str:
        """One-line description (polymorphic: each subclass writes its own)."""

    def __eq__(self, other) -> bool:
        return type(self) is type(other) and self.id is not None and self.id == other.id

    def __hash__(self) -> int:
        return hash((type(self).__name__, self.id, self.name))

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f"<{type(self).__name__} #{self.id} {self.name!r}>"


class Rankable(ABC):
    """Mixin for things that can be put in a tier list."""

    @abstractmethod
    def score(self) -> float:
        """Higher is better."""


# --------------------------------------------------------------------------
# Umamusume
# --------------------------------------------------------------------------
class Horse(Entity, Rankable):
    TABLE = "horses"
    LABEL = "Character"

    def __init__(self, name: str, aptitudes, id: int | None = None):
        super().__init__(name, id)
        self.aptitudes = aptitudes

    @property
    def aptitudes(self) -> dict[str, int]:
        return dict(self._apt)

    @aptitudes.setter
    def aptitudes(self, values) -> None:
        if isinstance(values, dict):
            values = [values[t] for t in TRACKS]
        if len(values) != 4:
            raise ValidationError("A character needs four aptitude values (Sprint, Mile, Medium, Long).")
        self._apt = {t: int(_in_range(v, 0, 10, f"{t} aptitude")) for t, v in zip(TRACKS, values)}

    def aptitude(self, track: str) -> int:
        return self._apt[track]

    def score(self) -> float:                       # average of the three best tracks
        best = sorted(self._apt.values(), reverse=True)[:3]
        return sum(best) / 3

    def best_track(self) -> str:
        return max(self._apt, key=self._apt.get)

    def record(self) -> dict:
        return {"name": self.name, "apt_sprint": self._apt["Sprint"], "apt_mile": self._apt["Mile"],
                "apt_medium": self._apt["Medium"], "apt_long": self._apt["Long"]}

    def summary(self) -> str:
        return f"{self.name} - best at {self.best_track()} ({self._apt[self.best_track()]}/10)"

    @classmethod
    def from_row(cls, r) -> "Horse":
        return cls(r["name"], [r["apt_sprint"], r["apt_mile"], r["apt_medium"], r["apt_long"]], r["id"])


class Skill(Entity, Rankable):
    TABLE = "skills"
    LABEL = "Skill"
    TIER_VALUE = {"S": 5, "A": 4, "B": 3, "C": 2, "D": 1}

    def __init__(self, name: str, category: str, tier: str, description: str = "", id: int | None = None):
        super().__init__(name, id)
        self.category = category
        self.tier = tier
        self.description = description

    @property
    def tier(self) -> str:
        return self._tier

    @tier.setter
    def tier(self, value: str) -> None:
        value = (value or "").strip().upper()
        if value not in TIERS:
            raise ValidationError(f"Tier must be one of {', '.join(TIERS)}.")
        self._tier = value

    @property
    def category(self) -> str:
        return self._category

    @category.setter
    def category(self, value: str) -> None:
        self._category = _clean_text(value, "Category")

    def score(self) -> float:
        return self.TIER_VALUE[self._tier]

    def record(self) -> dict:
        return {"name": self.name, "category": self.category, "tier": self.tier,
                "description": self.description}

    def summary(self) -> str:
        return f"{self.name} [{self.category}, tier {self.tier}] {self.description}"

    @classmethod
    def from_row(cls, r) -> "Skill":
        return cls(r["name"], r["category"], r["tier"], r["description"], r["id"])


class SupportCard(Entity, Rankable):
    TABLE = "support_cards"
    LABEL = "Support card"
    STATS = ("Speed", "Stamina", "Power", "Guts", "Wisdom")

    def __init__(self, name: str, rarity: str, type: str, rating: float,
                 bonuses: dict | None = None, skills: list[Skill] | None = None, id: int | None = None):
        super().__init__(name, id)
        self.rarity = rarity
        self.type = type
        self.rating = rating
        self.bonuses = bonuses or {}
        self.skills: list[Skill] = list(skills or [])

    @property
    def rarity(self) -> str:
        return self._rarity

    @rarity.setter
    def rarity(self, value: str) -> None:
        if value not in RARITIES:
            raise ValidationError(f"Rarity must be one of {', '.join(RARITIES)}.")
        self._rarity = value

    @property
    def type(self) -> str:
        return self._type

    @type.setter
    def type(self, value: str) -> None:
        if value not in STAT_TYPES:
            raise ValidationError(f"Type must be one of {', '.join(STAT_TYPES)}.")
        self._type = value

    @property
    def rating(self) -> float:
        return self._rating

    @rating.setter
    def rating(self, value) -> None:
        self._rating = _in_range(value, 0, 10, "Rating")

    @property
    def bonuses(self) -> dict[str, int]:
        return dict(self._bonuses)

    @bonuses.setter
    def bonuses(self, values: dict) -> None:
        self._bonuses = {s: int(_in_range(values.get(s, 0), 0, 999, f"{s} bonus")) for s in self.STATS}

    def score(self) -> float:
        return self._rating

    def record(self) -> dict:
        b = self._bonuses
        return {"name": self.name, "rarity": self.rarity, "type": self.type, "rating": self.rating,
                "b_speed": b["Speed"], "b_stamina": b["Stamina"], "b_power": b["Power"],
                "b_guts": b["Guts"], "b_wisdom": b["Wisdom"]}

    def summary(self) -> str:
        return f"{self.name} [{self.rarity} {self.type}, rating {self.rating:g}]"

    @classmethod
    def from_row(cls, r, skills=None) -> "SupportCard":
        bonus = {"Speed": r["b_speed"], "Stamina": r["b_stamina"], "Power": r["b_power"],
                 "Guts": r["b_guts"], "Wisdom": r["b_wisdom"]}
        return cls(r["name"], r["rarity"], r["type"], r["rating"], bonus, skills, r["id"])


# --------------------------------------------------------------------------
# Apex Legends
# --------------------------------------------------------------------------
class LegendClass(Entity):
    TABLE = "legend_classes"
    LABEL = "Legend class"

    def __init__(self, name: str, color: str, playstyle: str, id: int | None = None):
        super().__init__(name, id)
        self.color = color
        self.playstyle = playstyle

    def record(self) -> dict:
        return {"name": self.name, "color": self.color, "playstyle": self.playstyle}

    def summary(self) -> str:
        return f"{self.name}: {self.playstyle}"

    @classmethod
    def from_row(cls, r) -> "LegendClass":
        return cls(r["name"], r["color"], r["playstyle"], r["id"])


class Perk:
    """Small value object (no database id of its own in the app)."""

    def __init__(self, level: str, name: str, description: str = "", is_meta: bool = False):
        self.level, self.name, self.description, self.is_meta = level, name, description, is_meta

    def __str__(self) -> str:
        star = " *" if self.is_meta else ""
        return f"{self.name}{star}" + (f" - {self.description}" if self.description else "")


class Legend(Entity):
    TABLE = "legends"
    LABEL = "Legend"

    def __init__(self, name: str, legend_class: LegendClass, description: str = "",
                 meta_combo: str = "", meta_why: str = "", perks: list[Perk] | None = None,
                 id: int | None = None):
        super().__init__(name, id)
        self.legend_class = legend_class
        self.description = description
        self.meta_combo = meta_combo
        self.meta_why = meta_why
        self.perks: list[Perk] = list(perks or [])

    def perks_at(self, level: str) -> list[Perk]:
        return [p for p in self.perks if p.level == level]

    def record(self) -> dict:
        return {"name": self.name, "class_id": self.legend_class.id, "description": self.description,
                "meta_combo": self.meta_combo, "meta_why": self.meta_why}

    def summary(self) -> str:
        return f"{self.name} ({self.legend_class.name}) - {self.description}"


class WeaponClass(Entity):
    TABLE = "weapon_classes"
    LABEL = "Weapon class"

    def __init__(self, name: str, kind: str, ammo: str, blurb: str = "", id: int | None = None):
        super().__init__(name, id)
        self.kind, self.ammo, self.blurb = kind, ammo, blurb

    def record(self) -> dict:
        return {"name": self.name, "kind": self.kind, "ammo": self.ammo, "blurb": self.blurb}

    def summary(self) -> str:
        return f"{self.name} ({self.ammo}) - {self.blurb}"

    @classmethod
    def from_row(cls, r) -> "WeaponClass":
        return cls(r["name"], r["kind"], r["ammo"], r["blurb"], r["id"])


class Weapon(Entity):
    TABLE = "weapons"
    LABEL = "Weapon"
    STAT_FIELDS = ("damage", "headshot", "mag_size", "fire_rate", "reload_time",
                   "recoil_ctrl", "hipfire", "handling")

    def __init__(self, name: str, weapon_class: WeaponClass, optic: str = "", notes: str = "",
                 stats: dict | None = None, recommended: dict | None = None, id: int | None = None):
        super().__init__(name, id)
        self.weapon_class = weapon_class
        self.optic = optic
        self.notes = notes
        self.stats = stats or {}
        self.recommended = recommended or {}

    @property
    def stats(self) -> dict[str, float]:
        return dict(self._stats)

    @stats.setter
    def stats(self, values: dict) -> None:
        out = {}
        for f in self.STAT_FIELDS:
            v = float(values.get(f, 0) or 0)
            if v < 0:
                raise ValidationError(f"{f.replace('_', ' ').title()} cannot be negative.")
            if f in ("recoil_ctrl", "hipfire", "handling") and v > 100:
                raise ValidationError(f"{f.replace('_', ' ').title()} is on a 0-100 scale.")
            out[f] = v
        self._stats = out

    @property
    def dps(self) -> float:
        """Rough damage per second: damage x rounds per second."""
        return round(self._stats["damage"] * self._stats["fire_rate"] / 60, 1)

    def record(self) -> dict:
        rec = self.recommended
        return {"name": self.name, "class_id": self.weapon_class.id, "optic": self.optic,
                "notes": self.notes, **self._stats,
                "rec_mag": rec.get("mag", ""), "rec_barrel": rec.get("barrel", ""),
                "rec_stock": rec.get("stock", ""), "rec_corrupted": rec.get("corrupted", ""),
                "rec_note": rec.get("note", "")}

    def summary(self) -> str:
        return f"{self.name} ({self.weapon_class.name}) - {self.notes}"


class GameMap(Entity):
    TABLE = "maps"
    LABEL = "Map"

    def __init__(self, name: str, description: str = "", picks: list[tuple[Legend, str]] | None = None,
                 id: int | None = None):
        super().__init__(name, id)
        self.description = description
        self.picks: list[tuple[Legend, str]] = list(picks or [])

    def record(self) -> dict:
        return {"name": self.name, "description": self.description}

    def summary(self) -> str:
        return f"{self.name} - {self.description}"


# --------------------------------------------------------------------------
# Users and saved work
# --------------------------------------------------------------------------
class User(Entity):
    TABLE = "users"
    LABEL = "Profile"

    def __init__(self, name: str, color: str = "#3fd8c6", id: int | None = None):
        super().__init__(name, id)
        self.color = color

    @property
    def initial(self) -> str:
        return self.name[:1].upper()

    def record(self) -> dict:
        return {"name": self.name, "color": self.color}

    def summary(self) -> str:
        return self.name

    @classmethod
    def from_row(cls, r) -> "User":
        return cls(r["name"], r["color"], r["id"])


class Deck(Entity):
    """A saved support deck. Composition: it HAS a Horse and up to six SupportCards."""

    TABLE = "decks"
    LABEL = "Deck"
    MAX_CARDS = 6

    def __init__(self, name: str, user_id: int, horse: Horse, track: str = "Medium",
                 cards: list[SupportCard] | None = None, id: int | None = None):
        super().__init__(name, id)
        self.user_id = user_id
        self.horse = horse
        self.track = track
        self.cards: list[SupportCard] = []
        for c in cards or []:
            self.add_card(c)

    @property
    def track(self) -> str:
        return self._track

    @track.setter
    def track(self, value: str) -> None:
        if value not in TRACKS:
            raise ValidationError(f"Track must be one of {', '.join(TRACKS)}.")
        self._track = value

    def has_card(self, card: SupportCard) -> bool:
        return any(c.id == card.id for c in self.cards)

    def add_card(self, card: SupportCard) -> None:
        if self.has_card(card):
            raise ValidationError(f"{card.name} is already in this deck.")
        if len(self.cards) >= self.MAX_CARDS:
            raise ValidationError(f"A deck holds at most {self.MAX_CARDS} cards.")
        self.cards.append(card)

    def remove_card(self, card: SupportCard) -> None:
        self.cards = [c for c in self.cards if c.id != card.id]

    def record(self) -> dict:
        return {"user_id": self.user_id, "name": self.name, "horse_id": self.horse.id, "track": self.track}

    def summary(self) -> str:
        return f"{self.name}: {self.horse.name} on {self.track}, {len(self.cards)}/{self.MAX_CARDS} cards"


class GachaPlan(Entity):
    TABLE = "gacha_plans"
    LABEL = "Gacha plan"
    DEFAULTS = dict(carats=9000, tickets=5, spent=40, pity=200, rate=3, feat=0.75, daily=75,
                    weekly=300, monthly=1500, events=3000, days=30, perpull=150)
    LABELS = dict(carats="Carats owned", tickets="Tickets owned", spent="Pulls already spent",
                  pity="Pity (pulls to guarantee)", rate="SSR rate %", feat="Featured rate %",
                  daily="Daily carats", weekly="Weekly carats", monthly="Monthly carats",
                  events="Event carats (total)", days="Days until banner ends", perpull="Carats per pull")

    def __init__(self, name: str, user_id: int, params: dict | None = None, id: int | None = None):
        super().__init__(name, id)
        self.user_id = user_id
        self.params = params or {}

    @property
    def params(self) -> dict[str, float]:
        return dict(self._params)

    @params.setter
    def params(self, values: dict) -> None:
        merged = {}
        for k, default in self.DEFAULTS.items():
            v = values.get(k, default)
            try:
                v = float(v)
            except (TypeError, ValueError):
                raise ValidationError(f"{self.LABELS[k]} must be a number.") from None
            if v < 0:
                raise ValidationError(f"{self.LABELS[k]} cannot be negative.")
            merged[k] = v
        merged["days"] = min(180.0, max(1.0, round(merged["days"])))
        merged["perpull"] = merged["perpull"] or 150.0
        self._params = merged

    def record(self) -> dict:
        return {"user_id": self.user_id, "name": self.name, **self._params}

    def summary(self) -> str:
        return f"{self.name}: {int(self._params['carats'])} carats, {int(self._params['days'])} days"
