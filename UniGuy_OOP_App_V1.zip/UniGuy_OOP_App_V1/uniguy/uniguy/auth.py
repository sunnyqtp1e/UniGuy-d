"""Accounts: sign up, log in, change password, delete account.

How the data is kept apart
--------------------------
* data/accounts.db      small registry: username, random salt, password hash, colour.
* data/users/<name>.db  one complete UniGuy database PER ACCOUNT (its own copy of the guide data plus its
                        decks, gacha plans and history). Nothing is shared, so one player's edits or deletes
                        can never touch another player's data, and deleting an account is just deleting a file.

Passwords are never stored. Only a salted PBKDF2-HMAC-SHA256 hash is, and it is compared in constant time.
NOTE: this separates accounts inside the app. The database files themselves are not encrypted.

OOP ideas used here
-------------------
* Encapsulation : AccountStore hides the registry database and the file layout from the rest of the app.
* Single responsibility : PasswordHasher only hashes, AccountStore only manages accounts.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import re
import shutil
import sqlite3
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
LEGACY_DB = ROOT / "uniguy.db"          # the single-user file from the earlier version of the app

COLORS = ["#3fd8c6", "#ff86bb", "#ea4b3c", "#f5c451", "#74c0fc", "#b197fc"]


class AuthError(Exception):
    """Wrong password, bad username, name already taken ... The message is safe to show to the user."""


@dataclass(frozen=True)
class Account:
    username: str
    color: str = COLORS[0]


class PasswordHasher:
    ITERATIONS = 200_000

    @classmethod
    def hash(cls, password: str, salt: bytes | None = None) -> tuple[str, str]:
        salt = salt or os.urandom(16)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, cls.ITERATIONS)
        return salt.hex(), digest.hex()

    @classmethod
    def verify(cls, password: str, salt_hex: str, hash_hex: str) -> bool:
        _, digest = cls.hash(password, bytes.fromhex(salt_hex))
        return hmac.compare_digest(digest, hash_hex)


class AccountStore:
    USERNAME_RE = re.compile(r"^[A-Za-z0-9_-]{3,20}$")
    MIN_PASSWORD = 6
    BAD_LOGIN = "Wrong username or password."      # same text for both, so it doesn't reveal which exists

    def __init__(self, folder: str | Path = DATA_DIR, legacy_db: Path | None = LEGACY_DB):
        self.folder = Path(folder)
        self.users_dir = self.folder / "users"
        self.users_dir.mkdir(parents=True, exist_ok=True)
        self.legacy_db = legacy_db
        self._db = sqlite3.connect(self.folder / "accounts.db")
        self._db.row_factory = sqlite3.Row
        self._db.executescript(
            "CREATE TABLE IF NOT EXISTS accounts ("
            " username TEXT PRIMARY KEY COLLATE NOCASE, salt TEXT NOT NULL, pw_hash TEXT NOT NULL,"
            " color TEXT NOT NULL, created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);"
            "CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);")

    # ----- queries ----------------------------------------------------------------
    def count(self) -> int:
        return self._db.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]

    def exists(self, username: str) -> bool:
        return self._row(username) is not None

    def db_path(self, username: str) -> Path:
        return self.users_dir / f"{self._row(username)['username'].lower()}.db"

    def last_user(self) -> str:
        row = self._db.execute("SELECT value FROM meta WHERE key='last_user'").fetchone()
        return row["value"] if row else ""

    def set_last_user(self, username: str) -> None:
        self._db.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('last_user', ?)", (username,))
        self._db.commit()

    # ----- commands ---------------------------------------------------------------
    def create(self, username: str, password: str, color: str | None = None) -> Account:
        username = username.strip()
        if not self.USERNAME_RE.match(username):
            raise AuthError("Username must be 3-20 characters: letters, numbers, _ or -.")
        self._check_password(password)
        if self.exists(username):
            raise AuthError("That username is already taken.")
        color = color or COLORS[self.count() % len(COLORS)]
        salt, digest = PasswordHasher.hash(password)
        self._db.execute("INSERT INTO accounts (username, salt, pw_hash, color) VALUES (?,?,?,?)",
                         (username, salt, digest, color))
        self._db.commit()
        target = self.users_dir / f"{username.lower()}.db"
        if self.count() == 1 and self.legacy_db and Path(self.legacy_db).exists() and not target.exists():
            shutil.copy2(self.legacy_db, target)        # the first account keeps the old single-user data
        return Account(username, color)

    def verify(self, username: str, password: str) -> Account:
        row = self._row(username.strip())
        if row is None or not PasswordHasher.verify(password, row["salt"], row["pw_hash"]):
            raise AuthError(self.BAD_LOGIN)
        return Account(row["username"], row["color"])

    def change_password(self, username: str, old: str, new: str) -> None:
        self.verify(username, old)
        self._check_password(new)
        salt, digest = PasswordHasher.hash(new)
        self._db.execute("UPDATE accounts SET salt=?, pw_hash=? WHERE username=?", (salt, digest, username))
        self._db.commit()

    def set_color(self, username: str, color: str) -> None:
        self._db.execute("UPDATE accounts SET color=? WHERE username=?", (color, username))
        self._db.commit()

    def wipe_data(self, username: str) -> None:
        """Delete the account's database file (the account itself stays). It is rebuilt on next sign-in.
        The caller must have closed the database first."""
        self.db_path(username).unlink(missing_ok=True)

    def delete(self, username: str) -> None:
        """Remove the account and all of its data. The caller must have closed the database first."""
        path = self.db_path(username)
        self._db.execute("DELETE FROM accounts WHERE username=?", (username,))
        self._db.commit()
        path.unlink(missing_ok=True)

    def close(self) -> None:
        self._db.close()

    # ----- internals --------------------------------------------------------------
    def _row(self, username: str):
        return self._db.execute("SELECT * FROM accounts WHERE username=?", (username,)).fetchone()

    def _check_password(self, password: str) -> None:
        if len(password) < self.MIN_PASSWORD:
            raise AuthError(f"Password must be at least {self.MIN_PASSWORD} characters.")
