"""Repository classes: the only place that writes SQL for the models.

OOP ideas used here
-------------------
* Abstraction  : Repository is an abstract class. It already knows how to do
                 INSERT / UPDATE / DELETE for any Entity; subclasses only say how to
                 turn a database row back into an object (build()).
* Inheritance  : CardRepository, LegendRepository ... extend Repository and override
                 the parts that need joins (many-to-many tables).
* Polymorphism : the GUI calls repo.all(), repo.add(x), repo.delete(id) on any repository
                 without caring which table is behind it.
"""
from __future__ import annotations

import sqlite3
from abc import ABC, abstractmethod

from .database import Database
from .models import (Deck, Entity, GachaPlan, GameMap, Horse, Legend, LegendClass, Perk, Skill,
                     SupportCard, User, Weapon, WeaponClass)


class RepositoryError(Exception):
    """Friendly database error (duplicate name, still in use ...)."""


class Repository(ABC):
    TABLE = ""
    ORDER = "name COLLATE NOCASE"
    SEARCH_COLUMNS = ("name",)

    def __init__(self, db: Database | None = None):
        self.db = db or Database.instance()

    @abstractmethod
    def build(self, row: sqlite3.Row) -> Entity:
        """Turn one database row into a model object."""

    # ----- read -------------------------------------------------------------
    def all(self) -> list[Entity]:
        rows = self.db.query(f"SELECT * FROM {self.TABLE} ORDER BY {self.ORDER}")
        return [self.build(r) for r in rows]

    def get(self, id: int) -> Entity | None:
        row = self.db.query_one(f"SELECT * FROM {self.TABLE} WHERE id=?", (id,))
        return self.build(row) if row else None

    def find_by_name(self, name: str) -> Entity | None:
        row = self.db.query_one(f"SELECT * FROM {self.TABLE} WHERE name=? COLLATE NOCASE", (name,))
        return self.build(row) if row else None

    def search(self, text: str) -> list[Entity]:
        text = f"%{text.strip()}%"
        where = " OR ".join(f"{c} LIKE ?" for c in self.SEARCH_COLUMNS)
        rows = self.db.query(f"SELECT * FROM {self.TABLE} WHERE {where} ORDER BY {self.ORDER}",
                             [text] * len(self.SEARCH_COLUMNS))
        return [self.build(r) for r in rows]

    def count(self) -> int:
        return self.db.query_one(f"SELECT COUNT(*) AS n FROM {self.TABLE}")["n"]

    # ----- write ------------------------------------------------------------
    def add(self, entity: Entity) -> Entity:
        data = entity.record()
        cols = ", ".join(data)
        marks = ", ".join("?" for _ in data)
        try:
            cur = self.db.execute(f"INSERT INTO {self.TABLE} ({cols}) VALUES ({marks})", list(data.values()))
        except sqlite3.IntegrityError as e:
            raise RepositoryError(self._friendly(e, entity)) from e
        entity.id = cur.lastrowid
        self.after_save(entity)
        return entity

    def update(self, entity: Entity) -> Entity:
        if entity.id is None:
            raise RepositoryError("This item has not been saved yet.")
        data = entity.record()
        sets = ", ".join(f"{c}=?" for c in data)
        try:
            self.db.execute(f"UPDATE {self.TABLE} SET {sets} WHERE id=?", [*data.values(), entity.id])
        except sqlite3.IntegrityError as e:
            raise RepositoryError(self._friendly(e, entity)) from e
        self.after_save(entity)
        return entity

    def save(self, entity: Entity) -> Entity:
        return self.update(entity) if entity.id is not None else self.add(entity)

    def delete(self, id: int) -> None:
        try:
            self.db.execute(f"DELETE FROM {self.TABLE} WHERE id=?", (id,))
        except sqlite3.IntegrityError as e:
            raise RepositoryError("This item is still used by something else, so it cannot be deleted.") from e

    # ----- hooks for subclasses ---------------------------------------------
    def after_save(self, entity: Entity) -> None:
        """Called after INSERT/UPDATE (used to write link tables)."""

    @staticmethod
    def _friendly(error: sqlite3.IntegrityError, entity: Entity) -> str:
        msg = str(error)
        if "UNIQUE" in msg:
            return f"A {entity.LABEL.lower()} called '{entity.name}' already exists."
        if "CHECK" in msg:
            return "One of the values is outside the allowed range."
        return f"Database refused the change: {msg}"


# --------------------------------------------------------------------------
# Umamusume
# --------------------------------------------------------------------------
class HorseRepository(Repository):
    TABLE = "horses"

    def build(self, row) -> Horse:
        return Horse.from_row(row)


class SkillRepository(Repository):
    TABLE = "skills"
    SEARCH_COLUMNS = ("name", "description", "category")

    def build(self, row) -> Skill:
        return Skill.from_row(row)

    def categories(self) -> list[str]:
        return [r["category"] for r in self.db.query("SELECT DISTINCT category FROM skills ORDER BY category")]


class CardRepository(Repository):
    TABLE = "support_cards"
    SEARCH_COLUMNS = ("name", "type", "rarity")

    def __init__(self, db: Database | None = None):
        super().__init__(db)
        self.skills = SkillRepository(self.db)

    def build(self, row) -> SupportCard:
        skills = [Skill.from_row(r) for r in self.db.query(
            "SELECT s.* FROM skills s JOIN card_skills cs ON cs.skill_id = s.id "
            "WHERE cs.card_id=? ORDER BY s.name", (row["id"],))]
        return SupportCard.from_row(row, skills)

    def after_save(self, card: SupportCard) -> None:            # keep the link table in sync
        self.db.execute("DELETE FROM card_skills WHERE card_id=?", (card.id,))
        for s in card.skills:
            self.db.execute("INSERT OR IGNORE INTO card_skills (card_id, skill_id) VALUES (?,?)",
                            (card.id, s.id))


# --------------------------------------------------------------------------
# Apex
# --------------------------------------------------------------------------
class LegendClassRepository(Repository):
    TABLE = "legend_classes"

    def build(self, row) -> LegendClass:
        return LegendClass.from_row(row)


class LegendRepository(Repository):
    TABLE = "legends"
    SEARCH_COLUMNS = ("name", "description")

    def __init__(self, db: Database | None = None):
        super().__init__(db)
        self.classes = LegendClassRepository(self.db)

    def build(self, row) -> Legend:
        cls = self.classes.get(row["class_id"])
        perks = [Perk(p["level"], p["name"], p["description"], bool(p["is_meta"]))
                 for p in self.db.query("SELECT * FROM legend_perks WHERE legend_id=? ORDER BY id", (row["id"],))]
        return Legend(row["name"], cls, row["description"], row["meta_combo"], row["meta_why"],
                      perks, row["id"])

    def add_perk(self, legend: Legend, perk: Perk) -> None:
        self.db.execute("INSERT INTO legend_perks (legend_id, level, name, description, is_meta) "
                        "VALUES (?,?,?,?,?)",
                        (legend.id, perk.level, perk.name, perk.description, int(perk.is_meta)))
        legend.perks.append(perk)

    def remove_perk(self, legend: Legend, perk: Perk) -> None:
        self.db.execute("DELETE FROM legend_perks WHERE legend_id=? AND level=? AND name=?",
                        (legend.id, perk.level, perk.name))
        legend.perks = [p for p in legend.perks if p is not perk]

    def by_class(self, class_name: str) -> list[Legend]:
        rows = self.db.query(
            "SELECT l.* FROM legends l JOIN legend_classes c ON c.id = l.class_id "
            "WHERE c.name=? ORDER BY l.name COLLATE NOCASE", (class_name,))
        return [self.build(r) for r in rows]


class WeaponClassRepository(Repository):
    TABLE = "weapon_classes"
    ORDER = "id"

    def build(self, row) -> WeaponClass:
        return WeaponClass.from_row(row)


class WeaponRepository(Repository):
    TABLE = "weapons"
    SEARCH_COLUMNS = ("name", "notes", "optic")

    def __init__(self, db: Database | None = None):
        super().__init__(db)
        self.classes = WeaponClassRepository(self.db)

    def build(self, row) -> Weapon:
        wc = self.classes.get(row["class_id"])
        stats = {f: row[f] for f in Weapon.STAT_FIELDS}
        rec = {"mag": row["rec_mag"], "barrel": row["rec_barrel"], "stock": row["rec_stock"],
               "corrupted": row["rec_corrupted"], "note": row["rec_note"]}
        return Weapon(row["name"], wc, row["optic"], row["notes"], stats, rec, row["id"])

    def by_class(self, class_id: int) -> list[Weapon]:
        rows = self.db.query("SELECT * FROM weapons WHERE class_id=? ORDER BY name COLLATE NOCASE", (class_id,))
        return [self.build(r) for r in rows]


class MapRepository(Repository):
    TABLE = "maps"
    ORDER = "id"
    SEARCH_COLUMNS = ("name", "description")

    def __init__(self, db: Database | None = None):
        super().__init__(db)
        self.legends = LegendRepository(self.db)

    def build(self, row) -> GameMap:
        picks = []
        for r in self.db.query("SELECT legend_id, reason FROM map_legends WHERE map_id=?", (row["id"],)):
            picks.append((self.legends.get(r["legend_id"]), r["reason"]))
        return GameMap(row["name"], row["description"], picks, row["id"])

    def set_picks(self, game_map: GameMap, picks: list[tuple[Legend, str]]) -> None:
        self.db.execute("DELETE FROM map_legends WHERE map_id=?", (game_map.id,))
        for legend, reason in picks:
            self.db.execute("INSERT OR IGNORE INTO map_legends (map_id, legend_id, reason) VALUES (?,?,?)",
                            (game_map.id, legend.id, reason))
        game_map.picks = list(picks)


# --------------------------------------------------------------------------
# Users and saved work
# --------------------------------------------------------------------------
class UserRepository(Repository):
    TABLE = "users"

    def build(self, row) -> User:
        return User.from_row(row)


class DeckRepository(Repository):
    TABLE = "decks"

    def __init__(self, db: Database | None = None):
        super().__init__(db)
        self.horses = HorseRepository(self.db)
        self.cards = CardRepository(self.db)

    def build(self, row) -> Deck:
        horse = self.horses.get(row["horse_id"])
        card_ids = [r["card_id"] for r in self.db.query(
            "SELECT card_id FROM deck_cards WHERE deck_id=? ORDER BY rowid", (row["id"],))]
        cards = [self.cards.get(i) for i in card_ids]
        return Deck(row["name"], row["user_id"], horse, row["track"], cards, row["id"])

    def for_user(self, user_id: int) -> list[Deck]:
        rows = self.db.query("SELECT * FROM decks WHERE user_id=? ORDER BY name COLLATE NOCASE", (user_id,))
        return [self.build(r) for r in rows]

    def delete_for_user(self, user_id: int) -> int:
        """Delete every saved deck of one user (its card list goes with it). Returns how many."""
        return self.db.execute("DELETE FROM decks WHERE user_id=?", (user_id,)).rowcount

    def after_save(self, deck: Deck) -> None:
        self.db.execute("DELETE FROM deck_cards WHERE deck_id=?", (deck.id,))
        for c in deck.cards:
            self.db.execute("INSERT INTO deck_cards (deck_id, card_id) VALUES (?,?)", (deck.id, c.id))


class GachaPlanRepository(Repository):
    TABLE = "gacha_plans"

    def build(self, row) -> GachaPlan:
        return GachaPlan(row["name"], row["user_id"], {k: row[k] for k in GachaPlan.DEFAULTS}, row["id"])

    def for_user(self, user_id: int) -> list[GachaPlan]:
        rows = self.db.query("SELECT * FROM gacha_plans WHERE user_id=? ORDER BY name COLLATE NOCASE", (user_id,))
        return [self.build(r) for r in rows]

    def delete_for_user(self, user_id: int) -> int:
        """Delete every saved plan of one user. Returns how many."""
        return self.db.execute("DELETE FROM gacha_plans WHERE user_id=?", (user_id,)).rowcount


class VisitLogRepository:
    """Not an Entity table, just an append-only log, so it stands alone."""

    def __init__(self, db: Database | None = None):
        self.db = db or Database.instance()

    def log(self, user_id: int, page: str) -> None:
        last = self.db.query_one(
            "SELECT page FROM visit_log WHERE user_id=? ORDER BY id DESC LIMIT 1", (user_id,))
        if last and last["page"] == page:
            return
        self.db.execute("INSERT INTO visit_log (user_id, page) VALUES (?,?)", (user_id, page))

    def recent(self, user_id: int, limit: int = 50) -> list[tuple[str, str]]:
        rows = self.db.query(
            "SELECT page, visited_at FROM visit_log WHERE user_id=? ORDER BY id DESC LIMIT ?",
            (user_id, limit))
        return [(r["page"], r["visited_at"]) for r in rows]

    def clear(self, user_id: int) -> None:
        self.db.execute("DELETE FROM visit_log WHERE user_id=?", (user_id,))

