"""Reusable GUI building blocks.

OOP ideas used here
-------------------
* Abstraction / Template Method : CrudView is an abstract screen. It implements the whole
  list + form + Save/Delete workflow once; each subclass only fills in the small abstract
  steps (make_repo, row_values, to_entity ...).
* Inheritance   : RankedCrudView extends CrudView and adds a tier column.
* Polymorphism  : CrudView calls self.to_entity(...) and does not care which model it builds.
"""
from __future__ import annotations

import tkinter as tk
from abc import ABC, abstractmethod
from tkinter import messagebox, ttk

from ..models import Entity, Rankable, ValidationError
from ..repositories import Repository, RepositoryError
from ..services import TierService
from . import theme
from .widgets import PillTabs, TierBoard


class FieldSpec:
    """Describes one input of an entity form."""

    def __init__(self, key: str, label: str, kind: str = "text", choices=None, height: int = 3):
        self.key, self.label, self.kind, self.choices, self.height = key, label, kind, choices, height

    def options(self) -> list:
        return list(self.choices() if callable(self.choices) else (self.choices or []))


class EntityForm(ttk.Frame):
    """Builds input widgets from FieldSpec objects and reads/writes values as a dict."""

    def __init__(self, master, specs: list[FieldSpec]):
        super().__init__(master)
        self.specs = specs
        self.widgets: dict[str, tk.Widget] = {}
        self.vars: dict[str, tk.StringVar] = {}
        self.columnconfigure(1, weight=1)
        for row, spec in enumerate(specs):
            ttk.Label(self, text=spec.label, style="Mute.TLabel").grid(
                row=row, column=0, sticky="nw", padx=(0, 8), pady=3)
            w = self._make_widget(spec)
            w.grid(row=row, column=1, sticky="ew", pady=3)
            self.widgets[spec.key] = w

    def _make_widget(self, spec: FieldSpec) -> tk.Widget:
        if spec.kind in ("text", "int", "float"):
            var = tk.StringVar()
            self.vars[spec.key] = var
            return ttk.Entry(self, textvariable=var)
        if spec.kind in ("choice", "combo"):
            var = tk.StringVar()
            self.vars[spec.key] = var
            state = "readonly" if spec.kind == "choice" else "normal"
            return ttk.Combobox(self, textvariable=var, values=spec.options(), state=state)
        if spec.kind == "multiline":
            t = tk.Text(self, height=spec.height, wrap="word", bg=theme.PANEL2, fg=theme.FG,
                        insertbackground=theme.FG, relief="flat", highlightthickness=1,
                        highlightbackground=theme.LINE, highlightcolor=theme.BRAND, font="TkDefaultFont")
            return t
        if spec.kind == "multilist":
            f = ttk.Frame(self)
            lb = tk.Listbox(f, selectmode="multiple", height=spec.height, exportselection=False,
                            bg=theme.PANEL2, fg=theme.FG, selectbackground="#1f5f58",
                            relief="flat", highlightthickness=1, highlightbackground=theme.LINE)
            sb = ttk.Scrollbar(f, orient="vertical", command=lb.yview)
            lb.configure(yscrollcommand=sb.set)
            lb.pack(side="left", fill="both", expand=True)
            sb.pack(side="right", fill="y")
            f.listbox = lb
            return f
        raise ValueError(spec.kind)

    # ----- choices ----------------------------------------------------------
    def refresh_choices(self) -> None:
        for spec in self.specs:
            w = self.widgets[spec.key]
            if spec.kind in ("choice", "combo"):
                w.configure(values=spec.options())
            elif spec.kind == "multilist":
                keep = [w.listbox.get(i) for i in w.listbox.curselection()]   # keep the user's ticks
                w.listbox.delete(0, "end")
                for o in spec.options():
                    w.listbox.insert("end", o)
                names = list(w.listbox.get(0, "end"))
                for name in keep:
                    if name in names:
                        w.listbox.selection_set(names.index(name))

    # ----- read / write -----------------------------------------------------
    def clear(self) -> None:
        self.set({})

    def set(self, values: dict) -> None:
        for spec in self.specs:
            w, v = self.widgets[spec.key], values.get(spec.key)
            if spec.kind in ("text", "int", "float", "choice", "combo"):
                self.vars[spec.key].set("" if v is None else self._fmt(v))
            elif spec.kind == "multiline":
                w.delete("1.0", "end")
                w.insert("1.0", v or "")
            elif spec.kind == "multilist":
                w.listbox.selection_clear(0, "end")
                items = list(w.listbox.get(0, "end"))
                for name in v or []:
                    if name in items:
                        w.listbox.selection_set(items.index(name))

    @staticmethod
    def _fmt(v) -> str:
        if isinstance(v, float) and v.is_integer():
            return str(int(v))
        return str(v)

    def get(self) -> dict:
        out = {}
        for spec in self.specs:
            w = self.widgets[spec.key]
            if spec.kind == "multiline":
                out[spec.key] = w.get("1.0", "end").strip()
            elif spec.kind == "multilist":
                out[spec.key] = [w.listbox.get(i) for i in w.listbox.curselection()]
            else:
                raw = self.vars[spec.key].get().strip()
                if spec.kind == "int":
                    out[spec.key] = self._number(raw, spec.label, int)
                elif spec.kind == "float":
                    out[spec.key] = self._number(raw, spec.label, float)
                else:
                    out[spec.key] = raw
        return out

    @staticmethod
    def _number(raw: str, label: str, cast):
        try:
            return cast(float(raw)) if cast is int else cast(raw)
        except ValueError:
            kind = "a whole number" if cast is int else "a number"
            raise ValidationError(f"{label} must be {kind}.") from None


def make_tree(master, columns: list[tuple], height: int = 15) -> ttk.Treeview:
    """columns: (key, heading, width, anchor). Returns a Treeview with a scrollbar and click-to-sort."""
    frame = ttk.Frame(master)
    tree = ttk.Treeview(frame, columns=[c[0] for c in columns], show="headings", height=height,
                        selectmode="browse")
    for key, heading, width, anchor in columns:
        tree.heading(key, text=heading, anchor=anchor, command=lambda k=key: sort_tree(tree, k))
        tree.column(key, width=width, anchor=anchor, stretch=(anchor == "w"))
    sb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=sb.set)
    tree.pack(side="left", fill="both", expand=True)
    sb.pack(side="right", fill="y")
    tree.container = frame
    tree._sort_reverse = {}
    for tier, color in theme.TIER_COLORS.items():
        tree.tag_configure(f"tier_{tier}", foreground=color)
    return tree


def sort_tree(tree: ttk.Treeview, key: str) -> None:
    rows = [(tree.set(i, key), i) for i in tree.get_children("")]

    def conv(v):
        try:
            return (0, float(v.rstrip("%")))
        except ValueError:
            return (1, v.lower())

    rev = tree._sort_reverse.get(key, False)
    rows.sort(key=lambda r: conv(r[0]), reverse=rev)
    for idx, (_, iid) in enumerate(rows):
        tree.move(iid, "", idx)
    tree._sort_reverse[key] = not rev


class ScrollFrame(ttk.Frame):
    """A frame whose content scrolls vertically (used for long forms)."""

    def __init__(self, master, panel: bool = True, width: int = 340):
        bg = theme.PANEL if panel else theme.BG                 # panel=False blends into the page
        style = "Panel.TFrame" if panel else "TFrame"
        super().__init__(master, style=style)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, width=width)
        sb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=sb.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.body = ttk.Frame(self.canvas, style=style, padding=12)
        self._win = self.canvas.create_window((0, 0), window=self.body, anchor="nw")
        self.body.bind("<Configure>", lambda _e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self._win, width=e.width))
        self.scroll_canvas = self.canvas          # found by widgets.install_mouse_wheel()


class PageHeader(tk.Frame):
    """Small coloured label, big capital title and a muted sentence (the website's page heading)."""

    def __init__(self, master, title: str, subtitle: str = "", eyebrow: str = "", accent: str = theme.BRAND):
        super().__init__(master, bg=theme.BG)
        if eyebrow:
            tk.Label(self, text=eyebrow.upper(), bg=theme.BG, fg=accent, font=theme.display(11)).pack(anchor="w")
        tk.Label(self, text=title.upper(), bg=theme.BG, fg=theme.FG, font=theme.display(28)).pack(anchor="w")
        if subtitle:
            tk.Label(self, text=subtitle, bg=theme.BG, fg=theme.MUTE, font=theme.body(11), wraplength=760,
                     justify="left").pack(anchor="w", pady=(2, 0))


# --------------------------------------------------------------------------
class CrudView(ABC, ttk.Frame):
    """List on the left, form on the right, Create / Read / Update / Delete buttons."""

    TITLE = ""
    SUBTITLE = ""
    EYEBROW = ""                     # small coloured label above the title (the game name)
    ACCENT = theme.BRAND             # the game's colour
    COLUMNS: list[tuple] = []        # (key, heading, width, anchor)
    FIELDS: list[FieldSpec] = []
    FILTER_LABEL = ""                # set to show a filter box

    def __init__(self, master, app):
        ttk.Frame.__init__(self, master)
        self.app = app
        self.repo: Repository = self.make_repo()
        self.items: dict[int, Entity] = {}
        self.current: Entity | None = None
        self._build()
        self.refresh()

    # ----- the abstract steps every screen must supply ----------------------
    @abstractmethod
    def make_repo(self) -> Repository: ...

    @abstractmethod
    def row_values(self, entity: Entity) -> tuple: ...

    @abstractmethod
    def to_entity(self, values: dict, existing: Entity | None) -> Entity:
        """Create a new object (existing is None) or update the existing one from form values."""

    @abstractmethod
    def to_form(self, entity: Entity) -> dict: ...

    # ----- optional hooks ---------------------------------------------------
    def filter_choices(self) -> list[str]:
        return []

    def passes_filter(self, entity: Entity, value: str) -> bool:
        return True

    def row_tags(self, entity: Entity) -> tuple:
        return ()

    def decorate(self, entities: list[Entity]) -> list[Entity]:
        return entities

    def make_board(self, parent):
        """Return a board widget (tier rows, card grid ...) to offer a Board/Table switch, or None."""
        return None

    def fill_board(self, entities: list[Entity]) -> None:
        """Draw the shown entities on the board. Call self.pick(entity) when one is clicked."""

    def build_extra(self, parent) -> None:
        """Add extra widgets below the form (read-only details, link tables ...)."""

    def show_extra(self, entity: Entity | None) -> None:
        """Called whenever the selected entity changes."""

    # ----- layout -----------------------------------------------------------
    def _build(self) -> None:
        self.columnconfigure(0, weight=3)
        self.columnconfigure(1, weight=2, minsize=400)
        self.rowconfigure(0, weight=1)

        left = ttk.Frame(self)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        left.rowconfigure(1, weight=1)
        left.columnconfigure(0, weight=1)

        bar = ttk.Frame(left)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(bar, text="Search", style="Mute.TLabel").pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self.refresh())
        ttk.Entry(bar, textvariable=self.search_var, width=18).pack(side="left", padx=6)
        self.filter_var = tk.StringVar(value="All")
        if self.FILTER_LABEL:
            ttk.Label(bar, text=self.FILTER_LABEL, style="Mute.TLabel").pack(side="left", padx=(12, 0))
            self.filter_box = ttk.Combobox(bar, textvariable=self.filter_var, state="readonly", width=12,
                                           values=["All"] + self.filter_choices())
            self.filter_box.pack(side="left", padx=6)
            self.filter_box.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        self.board = self.make_board(left)
        self._mode, self._shown = "table", []
        if self.board is not None:                  # the Board / Table switch
            self._mode = "board"
            self.mode_tabs = PillTabs(bar, [("board", "Board"), ("table", "Table")], self._set_mode,
                                      accent=self.ACCENT, active="board")
            self.mode_tabs.pack(side="right", padx=(10, 0))
        self.count_label = ttk.Label(bar, text="", style="Mute.TLabel")
        self.count_label.pack(side="right")

        self.tree = make_tree(left, self.COLUMNS)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        self._apply_mode()

        scroller = ScrollFrame(self, panel=False)
        scroller.grid(row=0, column=1, sticky="nsew")
        right = scroller.body
        right.columnconfigure(0, weight=1)
        ttk.Label(right, text="Details", style="H2.TLabel").grid(sticky="w", pady=(0, 6))
        self.form = EntityForm(right, self.FIELDS)
        self.form.grid(sticky="ew")
        btns = ttk.Frame(right)
        btns.grid(sticky="w", pady=10)
        ttk.Button(btns, text="New", command=self.new).pack(side="left", padx=(0, 6))
        ttk.Button(btns, text="Save", style="Accent.TButton", command=self.save).pack(side="left", padx=(0, 6))
        self.delete_btn = ttk.Button(btns, text="Delete", style="Danger.TButton", command=self.delete)
        self.delete_btn.pack(side="left")
        self.status = ttk.Label(right, text="", style="Warn.TLabel", wraplength=330, justify="left")
        self.status.grid(sticky="w")
        self.extra = ttk.Frame(right)
        self.extra.grid(sticky="nsew", pady=(8, 0))
        self.build_extra(self.extra)

    # ----- data flow --------------------------------------------------------
    def refresh(self, select_id: int | None = None) -> None:
        self.form.refresh_choices()
        if self.FILTER_LABEL:
            self.filter_box.configure(values=["All"] + self.filter_choices())
        text = self.search_var.get().strip()
        entities = self.repo.search(text) if text else self.repo.all()
        entities = self.decorate(entities)
        flt = self.filter_var.get()
        if self.FILTER_LABEL and flt != "All":
            entities = [e for e in entities if self.passes_filter(e, flt)]
        self.items = {e.id: e for e in entities}
        self.tree.delete(*self.tree.get_children())
        for e in entities:
            self.tree.insert("", "end", iid=str(e.id), values=self.row_values(e), tags=self.row_tags(e))
        self.count_label.configure(text=f"{len(entities)} shown")
        self._shown = entities
        if self.board is not None and self._mode == "board":
            self.fill_board(entities)
        if select_id is not None and str(select_id) in self.tree.get_children():
            self.tree.selection_set(str(select_id))
            self.tree.see(str(select_id))
            self._board_select(select_id)
        elif self.current is None or self.current.id not in self.items:
            self.current = None
            self.show_extra(None)

    def _on_select(self, _event=None) -> None:
        sel = self.tree.selection()
        if not sel:
            return
        self.current = self.items.get(int(sel[0]))
        if self.current:
            self._board_select(self.current.id)
            self.form.set(self.to_form(self.current))
            self.status.configure(text="")
            self.show_extra(self.current)

    # ----- board / table switch ---------------------------------------------
    def _apply_mode(self) -> None:
        if self._mode == "board":
            self.tree.container.grid_remove()
            self.board.grid(row=1, column=0, sticky="nsew")
        else:
            if self.board is not None:
                self.board.grid_remove()
            self.tree.container.grid(row=1, column=0, sticky="nsew")

    def _set_mode(self, mode: str) -> None:
        self._mode = mode
        self._apply_mode()
        if mode == "board":
            self.fill_board(self._shown)
            self._board_select(self.current.id if self.current else None)

    def _board_select(self, item_id) -> None:
        if self.board is not None and hasattr(self.board, "select"):
            self.board.select(item_id)

    def pick(self, entity: Entity) -> None:
        """A board item was clicked: select it in the table, which fills the form."""
        if str(entity.id) in self.tree.get_children():
            self.tree.selection_set(str(entity.id))

    def new(self) -> None:
        self.tree.selection_remove(self.tree.selection())
        self._board_select(None)
        self.current = None
        self.form.clear()
        self.status.configure(text="Fill in the form and press Save to add a new item.")
        self.show_extra(None)

    def save(self) -> None:
        try:
            entity = self.to_entity(self.form.get(), self.current)
            self.repo.save(entity)
        except (ValidationError, RepositoryError) as e:
            messagebox.showwarning("Cannot save", str(e), parent=self)
            return
        self.current = entity
        self.app.notify_data_changed(self)
        self.refresh(select_id=entity.id)
        self.status.configure(text="Saved.")

    def delete(self) -> None:
        if not self.current:
            messagebox.showinfo("Delete", "Select an item in the list first.", parent=self)
            return
        if not messagebox.askyesno("Delete", f"Delete '{self.current.name}'? This cannot be undone.", parent=self):
            return
        try:
            self.repo.delete(self.current.id)
        except RepositoryError as e:
            messagebox.showwarning("Cannot delete", str(e), parent=self)
            return
        self.current = None
        self.form.clear()
        self.app.notify_data_changed(self)
        self.refresh()
        self.status.configure(text="Deleted.")

    def on_data_changed(self) -> None:
        """Another screen changed the data (for example a skill was deleted). Reload."""
        self.refresh(select_id=self.current.id if self.current else None)


class RankedCrudView(CrudView):
    """CrudView for Rankable entities: adds a Tier column colored S..D."""

    def decorate(self, entities):
        everything = self.repo.all()
        self._tiers = {}
        for tier, members in TierService.tierize(everything).items():
            for m in members:
                self._tiers[m.id] = tier
        return sorted(entities, key=lambda e: e.score(), reverse=True)

    def tier_of(self, entity: Rankable) -> str:
        return self._tiers.get(entity.id, "D")

    def row_tags(self, entity):
        return (f"tier_{self.tier_of(entity)}",)

    def passes_filter(self, entity, value):
        return self.tier_of(entity) == value

    # the tier board: S..D rows with a chip per item (same layout as the website's tier lists)
    def make_board(self, parent):
        return TierBoard(parent)

    def chip_sub(self, entity: Rankable) -> str:
        return f"{entity.score():.1f}"

    def fill_board(self, entities):
        groups = {t: [e for e in entities if self.tier_of(e) == t] for t in theme.TIER_COLORS}
        self.board.set_data(groups, lambda e: e.name, self.chip_sub, self.pick)
        self.board.select(self.current.id if self.current else None)
