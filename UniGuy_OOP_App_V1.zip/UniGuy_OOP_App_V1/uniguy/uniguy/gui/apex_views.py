"""Apex Legends screens: legends (+perks), weapons, weapon builder, maps."""
from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk

from ..models import GameMap, Legend, Perk, ValidationError, Weapon
from ..repositories import (LegendClassRepository, LegendRepository, MapRepository, RepositoryError,
                            WeaponClassRepository, WeaponRepository)
from ..services import LEVEL_NAMES, WeaponBuild
from . import theme
from .base import CrudView, FieldSpec, make_tree
from .images import ImageStore
from .widgets import GroupedBoard, LegendCard, MapCard, WeaponCard


class PerkDialog(tk.Toplevel):
    """Small modal form used to add a perk to a legend."""

    def __init__(self, master):
        super().__init__(master)
        self.title("Add perk")
        self.configure(bg=theme.BG, padx=14, pady=12)
        self.resizable(False, False)
        self.result: Perk | None = None
        self.level, self.name, self.desc = tk.StringVar(value="blue"), tk.StringVar(), tk.StringVar()
        self.meta = tk.BooleanVar()
        for r, (label, w) in enumerate([("Level", ttk.Combobox(self, textvariable=self.level, state="readonly",
                                                                values=["blue", "purple", "passive"])),
                                         ("Name", ttk.Entry(self, textvariable=self.name, width=36)),
                                         ("Description", ttk.Entry(self, textvariable=self.desc, width=36))]):
            ttk.Label(self, text=label, style="Mute.TLabel").grid(row=r, column=0, sticky="w", pady=3, padx=(0, 8))
            w.grid(row=r, column=1, sticky="ew", pady=3)
        ttk.Checkbutton(self, text="Mark as the meta pick", variable=self.meta).grid(row=3, columnspan=2, sticky="w")
        bt = ttk.Frame(self)
        bt.grid(row=4, columnspan=2, sticky="e", pady=(10, 0))
        ttk.Button(bt, text="Cancel", command=self.destroy).pack(side="left", padx=6)
        ttk.Button(bt, text="Add", style="Accent.TButton", command=self._ok).pack(side="left")
        self.transient(master)
        self.grab_set()

    def _ok(self):
        try:
            if not self.name.get().strip():
                raise ValidationError("Perk name cannot be empty.")
            self.result = Perk(self.level.get(), self.name.get().strip(), self.desc.get().strip(), self.meta.get())
        except ValidationError as e:
            messagebox.showwarning("Perk", str(e), parent=self)
            return
        self.destroy()


class LegendView(CrudView):
    TITLE = "Apex Guide"
    SUBTITLE = "Legends grouped by class. Click a legend to see its perks; every legend belongs to a class and owns a list of perks."
    EYEBROW = "Apex Legends"
    ACCENT = theme.APEX
    COLUMNS = [("name", "Legend", 120, "w"), ("cls", "Class", 90, "w"), ("perks", "Perks", 50, "center"),
               ("meta", "Meta combination", 190, "w"), ("desc", "Description", 300, "w")]
    FIELDS = [FieldSpec("name", "Name"),
              FieldSpec("cls", "Class", "choice", lambda: [c.name for c in LegendClassRepository().all()]),
              FieldSpec("description", "Description", "multiline", height=2),
              FieldSpec("meta_combo", "Meta combination"),
              FieldSpec("meta_why", "Why it is meta", "multiline", height=3)]
    FILTER_LABEL = "Class"

    def make_repo(self):
        return LegendRepository()

    def filter_choices(self):
        return [c.name for c in self.repo.classes.all()]

    def passes_filter(self, l, value):
        return l.legend_class.name == value

    def row_values(self, l: Legend):
        return (l.name, l.legend_class.name, len(l.perks), l.meta_combo, l.description)

    def to_form(self, l: Legend):
        return {"name": l.name, "cls": l.legend_class.name, "description": l.description,
                "meta_combo": l.meta_combo, "meta_why": l.meta_why}

    def to_entity(self, v, existing):
        cls = self.repo.classes.find_by_name(v["cls"])
        if cls is None:
            raise ValidationError("Choose a class.")
        if existing is None:
            return Legend(v["name"], cls, v["description"], v["meta_combo"], v["meta_why"])
        existing.name, existing.legend_class = v["name"], cls
        existing.description, existing.meta_combo, existing.meta_why = v["description"], v["meta_combo"], v["meta_why"]
        return existing

    # ----- the card board: portraits grouped by class, like the website --------------
    def make_board(self, parent):
        return GroupedBoard(parent)

    def fill_board(self, legends):
        board = self.board
        board.reset()
        for cls in self.repo.classes.all():
            members = [l for l in legends if l.legend_class.id == cls.id]
            if not members:
                continue
            flow = board.add_group(cls.name, cls.color, len(members))
            for l in members:
                card = LegendCard(flow, l.name, cls.name, command=lambda e=l: self.pick(e))
                flow.add(card)
                board.cards[l.id] = card
        board.select(self.current.id if self.current else None)

    def build_extra(self, parent):
        parent.columnconfigure(0, weight=1)
        self.banner = tk.Label(parent, bg=theme.BG, bd=0)
        self.banner.grid(sticky="ew", pady=(0, 8))
        ttk.Label(parent, text="Perks", style="H2.TLabel").grid(sticky="w")
        self.perk_tree = make_tree(parent, [("lvl", "Level", 60, "w"), ("name", "Perk", 140, "w"),
                                            ("desc", "Effect", 180, "w")], height=6)
        self.perk_tree.tag_configure("meta", foreground=theme.BRAND)
        self.perk_tree.container.grid(sticky="ew")
        bt = ttk.Frame(parent)
        bt.grid(sticky="w", pady=6)
        ttk.Button(bt, text="Add perk", command=self.add_perk).pack(side="left", padx=(0, 6))
        ttk.Button(bt, text="Remove perk", command=self.remove_perk).pack(side="left")
        ttk.Label(parent, text="Teal rows are the meta picks.", style="Mute.TLabel").grid(sticky="w")

    def show_extra(self, legend):
        self.perk_tree.delete(*self.perk_tree.get_children())
        self._perks = []
        art = ImageStore.instance().legend_art(legend.name) if legend else None
        self._art = art                                   # keep a reference or Tk drops the picture
        if art:
            self.banner.configure(image=art)
            self.banner.grid()
        else:
            self.banner.grid_remove()
        if legend is None:
            return
        for i, p in enumerate(sorted(legend.perks, key=lambda p: ("blue", "purple", "passive").index(p.level))):
            self._perks.append(p)
            self.perk_tree.insert("", "end", iid=str(i), values=(p.level, p.name, p.description),
                                  tags=("meta",) if p.is_meta else ())

    def add_perk(self):
        if not self.current:
            messagebox.showinfo("Perks", "Save or select a legend first.", parent=self)
            return
        dlg = PerkDialog(self)
        self.wait_window(dlg)
        if dlg.result:
            self.repo.add_perk(self.current, dlg.result)
            self.show_extra(self.current)
            self.refresh(select_id=self.current.id)

    def remove_perk(self):
        sel = self.perk_tree.selection()
        if not (sel and self.current):
            return
        self.repo.remove_perk(self.current, self._perks[int(sel[0])])
        self.show_extra(self.current)
        self.refresh(select_id=self.current.id)


class WeaponView(CrudView):
    TITLE = "Apex Guide"
    SUBTITLE = "Weapon menu: base stats and the recommended attachment build for every weapon. DPS = damage x rounds per second."
    EYEBROW = "Apex Legends"
    ACCENT = theme.APEX
    COLUMNS = [("name", "Weapon", 130, "w"), ("cls", "Class", 110, "w"), ("dmg", "Dmg", 50, "center"),
               ("rof", "RPM", 55, "center"), ("dps", "DPS", 55, "center"), ("optic", "Optic", 110, "w")]
    FIELDS = [FieldSpec("name", "Name"),
              FieldSpec("cls", "Class", "choice", lambda: [c.name for c in WeaponClassRepository().all()]),
              FieldSpec("optic", "Optic"), FieldSpec("notes", "Notes", "multiline", height=2),
              FieldSpec("damage", "Damage", "float"), FieldSpec("headshot", "Headshot dmg", "float"),
              FieldSpec("mag_size", "Magazine", "float"), FieldSpec("fire_rate", "Rounds / min", "float"),
              FieldSpec("reload_time", "Reload (s)", "float"), FieldSpec("recoil_ctrl", "Recoil ctrl 0-100", "float"),
              FieldSpec("hipfire", "Hipfire 0-100", "float"), FieldSpec("handling", "Handling 0-100", "float"),
              FieldSpec("rec_mag", "Rec. magazine"), FieldSpec("rec_barrel", "Rec. barrel"),
              FieldSpec("rec_stock", "Rec. stock"), FieldSpec("rec_corrupted", "Rec. corrupted"),
              FieldSpec("rec_note", "Build note", "multiline", height=2)]
    FILTER_LABEL = "Class"

    def make_repo(self):
        return WeaponRepository()

    def filter_choices(self):
        return [c.name for c in self.repo.classes.all()]

    def passes_filter(self, w, value):
        return w.weapon_class.name == value

    def make_board(self, parent):
        return GroupedBoard(parent)

    def fill_board(self, weapons):
        board = self.board
        board.reset()
        for wc in self.repo.classes.all():
            members = [w for w in weapons if w.weapon_class.id == wc.id]
            if not members:
                continue
            flow = board.add_group(wc.name, theme.APEX, len(members))
            for w in members:
                card = WeaponCard(flow, w.name, f"DPS {w.dps:g}  \u00b7  {w.optic}" if w.optic else f"DPS {w.dps:g}",
                                  command=lambda e=w: self.pick(e))
                flow.add(card)
                board.cards[w.id] = card
        board.select(self.current.id if self.current else None)

    def row_values(self, w: Weapon):
        s = w.stats
        return (w.name, w.weapon_class.name, f"{s['damage']:g}", f"{s['fire_rate']:g}", f"{w.dps:g}", w.optic)

    def to_form(self, w: Weapon):
        r = w.recommended
        return {"name": w.name, "cls": w.weapon_class.name, "optic": w.optic, "notes": w.notes, **w.stats,
                "rec_mag": r.get("mag", ""), "rec_barrel": r.get("barrel", ""), "rec_stock": r.get("stock", ""),
                "rec_corrupted": r.get("corrupted", ""), "rec_note": r.get("note", "")}

    def to_entity(self, v, existing):
        wc = self.repo.classes.find_by_name(v["cls"])
        if wc is None:
            raise ValidationError("Choose a weapon class.")
        stats = {f: v[f] for f in Weapon.STAT_FIELDS}
        rec = {"mag": v["rec_mag"], "barrel": v["rec_barrel"], "stock": v["rec_stock"],
               "corrupted": v["rec_corrupted"], "note": v["rec_note"]}
        if existing is None:
            return Weapon(v["name"], wc, v["optic"], v["notes"], stats, rec)
        existing.name, existing.weapon_class, existing.optic, existing.notes = v["name"], wc, v["optic"], v["notes"]
        existing.stats, existing.recommended = stats, rec
        return existing


class MapView(CrudView):
    TITLE = "Apex Guide"
    SUBTITLE = "Legends recommended for each map. The picks live in a link table with a reason column."
    EYEBROW = "Apex Legends"
    ACCENT = theme.APEX
    COLUMNS = [("name", "Map", 130, "w"), ("picks", "Recommended legends", 200, "w"), ("desc", "Description", 330, "w")]
    FIELDS = [FieldSpec("name", "Name"), FieldSpec("description", "Description", "multiline", height=3)]

    def make_repo(self):
        return MapRepository()

    def make_board(self, parent):
        return GroupedBoard(parent)

    def fill_board(self, maps):
        board = self.board
        board.reset()
        flow = board.add_flat()
        for m in maps:
            card = MapCard(flow, m.name, f"{len(m.picks)} legend picks", command=lambda e=m: self.pick(e))
            flow.add(card)
            board.cards[m.id] = card
        board.select(self.current.id if self.current else None)

    def row_values(self, m: GameMap):
        return (m.name, ", ".join(l.name for l, _ in m.picks), m.description)

    def to_form(self, m):
        return {"name": m.name, "description": m.description}

    def to_entity(self, v, existing):
        if existing is None:
            return GameMap(v["name"], v["description"])
        existing.name, existing.description = v["name"], v["description"]
        return existing

    def build_extra(self, parent):
        parent.columnconfigure(1, weight=1)
        ttk.Label(parent, text="Recommended legends", style="H2.TLabel").grid(columnspan=2, sticky="w")
        self.pick_tree = make_tree(parent, [("legend", "Legend", 90, "w"), ("reason", "Why", 230, "w")], height=5)
        self.pick_tree.container.grid(columnspan=2, sticky="ew")
        self.legend_var, self.reason_var = tk.StringVar(), tk.StringVar()
        ttk.Label(parent, text="Legend", style="Mute.TLabel").grid(row=2, column=0, sticky="w", pady=(8, 2))
        self.legend_box = ttk.Combobox(parent, textvariable=self.legend_var, state="readonly",
                                       values=[l.name for l in self.repo.legends.all()])
        self.legend_box.grid(row=2, column=1, sticky="ew", pady=(8, 2))
        ttk.Label(parent, text="Reason", style="Mute.TLabel").grid(row=3, column=0, sticky="w")
        ttk.Entry(parent, textvariable=self.reason_var).grid(row=3, column=1, sticky="ew")
        bt = ttk.Frame(parent)
        bt.grid(columnspan=2, sticky="w", pady=6)
        ttk.Button(bt, text="Add / update pick", command=self.add_pick).pack(side="left", padx=(0, 6))
        ttk.Button(bt, text="Remove pick", command=self.remove_pick).pack(side="left")

    def show_extra(self, m):
        self.pick_tree.delete(*self.pick_tree.get_children())
        if m is None:
            return
        for i, (legend, reason) in enumerate(m.picks):
            self.pick_tree.insert("", "end", iid=str(i), values=(legend.name, reason))

    def _write_picks(self, picks):
        self.repo.set_picks(self.current, picks)
        self.show_extra(self.current)
        self.refresh(select_id=self.current.id)

    def add_pick(self):
        if not self.current:
            messagebox.showinfo("Maps", "Save or select a map first.", parent=self)
            return
        legend = self.repo.legends.find_by_name(self.legend_var.get())
        if not legend:
            messagebox.showinfo("Maps", "Choose a legend.", parent=self)
            return
        picks = [(l, r) for l, r in self.current.picks if l.id != legend.id] + [(legend, self.reason_var.get().strip())]
        self._write_picks(picks)

    def remove_pick(self):
        sel = self.pick_tree.selection()
        if sel and self.current:
            picks = [p for i, p in enumerate(self.current.picks) if i != int(sel[0])]
            self._write_picks(picks)


# --------------------------------------------------------------------------
class WeaponBuilderView(ttk.Frame):
    """Playground: choose attachments and see the stats change (WeaponBuild + Attachment classes)."""
    TITLE = "Apex Guide"
    SUBTITLE = "Weapon builder: choose attachments and watch the stats change. Green = better, red = worse than the base weapon."
    EYEBROW = "Apex Legends"
    ACCENT = theme.APEX

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.weapons = WeaponRepository()
        self._build()
        self.on_data_changed()

    def _build(self):
        self.columnconfigure(1, weight=1)
        left = ttk.Frame(self, style="Panel.TFrame", padding=12)
        left.grid(row=1, column=0, sticky="ns", padx=(0, 12))
        self.icon = tk.Label(left, bg=theme.PANEL, bd=0)
        self.icon.grid(row=0, pady=(0, 6))
        self.vars = {k: tk.StringVar() for k in ("gun", "mag", "bar", "stk", "cor")}
        self.boxes = {}
        for r, (k, label) in enumerate([("gun", "Weapon"), ("mag", "Magazine"), ("bar", "Barrel"),
                                        ("stk", "Stock"), ("cor", "Corrupted")]):
            ttk.Label(left, text=label, style="PanelMute.TLabel").grid(row=r * 2 + 1, sticky="w", pady=(6, 0))
            cb = ttk.Combobox(left, textvariable=self.vars[k], state="readonly", width=30)
            cb.grid(row=r * 2 + 2, sticky="ew")
            cb.bind("<<ComboboxSelected>>", lambda _e, key=k: self._changed(key))
            self.boxes[k] = cb
        ttk.Button(left, text="Apply recommended build", style="Accent.TButton", command=self.apply_recommended).grid(
            row=11, sticky="ew", pady=(14, 4))
        self.rec_label = ttk.Label(left, text="", style="PanelMute.TLabel", wraplength=260, justify="left")
        self.rec_label.grid(row=12, sticky="w")
        self.cor_note = ttk.Label(left, text="", style="Panel.TLabel", wraplength=260, justify="left")
        self.cor_note.grid(row=13, sticky="w", pady=(8, 0))

        right = ttk.Frame(self, style="Panel.TFrame", padding=14)
        right.grid(row=1, column=1, sticky="nsew")
        right.columnconfigure(1, weight=1)
        self.big = {}
        tiles = ttk.Frame(right, style="Panel.TFrame")
        tiles.grid(columnspan=3, sticky="w", pady=(0, 10))
        for i, (k, t) in enumerate([("damage", "DMG"), ("headshot", "HEAD"), ("mag_size", "MAG"), ("fire_rate", "RPM")]):
            cell = ttk.Frame(tiles, style="Panel.TFrame")
            cell.grid(row=0, column=i, padx=(0, 24))
            lab = ttk.Label(cell, text="0", style="Big.TLabel")
            lab.pack(anchor="w")
            ttk.Label(cell, text=t, style="PanelMute.TLabel").pack(anchor="w")
            self.big[k] = lab
        self.bars = {}
        for r, (k, t, mx, good_up, unit) in enumerate([("reload_time", "Reload speed", 5, False, "s"),
                                                       ("recoil_ctrl", "Recoil control", 100, True, ""),
                                                       ("hipfire", "Hipfire accuracy", 100, True, ""),
                                                       ("handling", "Weapon handling", 100, True, "")], start=1):
            ttk.Label(right, text=t, style="Panel.TLabel").grid(row=r, column=0, sticky="w", pady=6)
            pb = ttk.Progressbar(right, maximum=mx, style="Horizontal.TProgressbar")
            pb.grid(row=r, column=1, sticky="ew", padx=12)
            val = ttk.Label(right, text="", style="Panel.TLabel", width=16, anchor="e")
            val.grid(row=r, column=2)
            self.bars[k] = (pb, val, good_up, unit)
        self.move = ttk.Label(right, text="", style="Panel.TLabel", foreground=theme.BRAND)
        self.move.grid(columnspan=3, sticky="w", pady=(8, 0))

    def on_data_changed(self):
        self._all = [w for w in self.weapons.all() if w.weapon_class.kind != "ord"]
        self._all.sort(key=lambda w: (w.weapon_class.id, w.name.lower()))
        self._labels = {f"{w.name}  ({w.weapon_class.name})": w for w in self._all}
        self.boxes["gun"].configure(values=list(self._labels))
        if not self.vars["gun"].get() or self.vars["gun"].get() not in self._labels:
            self.vars["gun"].set(next(iter(self._labels), ""))
        self._setup_slots()
        for k in ("mag", "bar", "stk"):
            self.boxes[k].configure(values=list(LEVEL_NAMES))
        self.vars["mag"].set(LEVEL_NAMES[3])
        self.vars["bar"].set(LEVEL_NAMES[0])
        self.vars["stk"].set(LEVEL_NAMES[3])
        self._setup_slots()
        self.update_stats()

    @property
    def weapon(self) -> Weapon | None:
        return self._labels.get(self.vars["gun"].get())

    def _setup_slots(self):
        from ..services import SLOTS
        w = self.weapon
        if not w:
            return
        slots = SLOTS.get(w.weapon_class.kind, {})
        for key, slot in (("bar", "barrel"), ("stk", "stock")):
            has = bool(slots.get(slot))
            self.boxes[key].configure(state="readonly" if has else "disabled")
            if not has:
                self.vars[key].set("Not available")
            elif self.vars[key].get() not in LEVEL_NAMES:
                self.vars[key].set(LEVEL_NAMES[3 if key == "stk" else 0])
        opts = ["None"] + WeaponBuild.corrupted_options(w)
        self.boxes["cor"].configure(values=opts)
        if self.vars["cor"].get() not in opts:
            self.vars["cor"].set("None")

    def _changed(self, key):
        if key == "gun":
            self._setup_slots()
        self.update_stats()

    @staticmethod
    def _level(text: str) -> int:
        return LEVEL_NAMES.index(text) if text in LEVEL_NAMES else 0

    @staticmethod
    def _parse_level(text: str) -> int:
        for i, tag in enumerate(("None", "(white)", "(blue)", "(purple)")):
            if tag in text:
                return i
        return 0

    def apply_recommended(self):
        w = self.weapon
        if not w or not w.recommended:
            return
        r = w.recommended
        self.vars["mag"].set(LEVEL_NAMES[self._parse_level(r.get("mag", ""))])
        if self.boxes["bar"].cget("state") != "disabled":
            self.vars["bar"].set(LEVEL_NAMES[self._parse_level(r.get("barrel", ""))])
        if self.boxes["stk"].cget("state") != "disabled":
            self.vars["stk"].set(LEVEL_NAMES[self._parse_level(r.get("stock", ""))])
        cor = r.get("corrupted", "")
        self.vars["cor"].set(cor if cor in self.boxes["cor"].cget("values") else "None")
        self.update_stats()

    def update_stats(self):
        w = self.weapon
        if not w:
            return
        self._icon = ImageStore.instance().weapon(w.name, 230)
        self.icon.configure(image=self._icon or "")
        r = w.recommended
        self.rec_label.configure(text=(f"Recommended: {r.get('mag', '-')} / {r.get('barrel', '-')} / "
                                       f"{r.get('stock', '-')} / {r.get('corrupted', '-')}\n{r.get('note', '')}")
                                 if r else "")
        cor = self.vars["cor"].get()
        build = WeaponBuild(w, self._level(self.vars["mag"].get()), self._level(self.vars["bar"].get()),
                            self._level(self.vars["stk"].get()), "" if cor == "None" else cor)
        s, b = build.calculate(), build.base
        self.cor_note.configure(text=(f"+ {build.corrupted.buff}\n- {build.corrupted.drawback}") if build.corrupted else
                                "One Corrupted attachment per gun. Each trades a strong buff for a drawback.")
        for k, lab in self.big.items():
            v, base = getattr(s, k), getattr(b, k)
            lab.configure(text=f"{v:.0f}", foreground=theme.GOOD if v > base + 1e-9 else theme.BAD if v < base - 1e-9 else theme.FG)
        for k, (pb, val, good_up, unit) in self.bars.items():
            v, base = getattr(s, k), getattr(b, k)
            dec = 1 if k == "reload_time" else 0
            better = (v > base) == good_up
            changed = round(v, dec) != round(base, dec)
            pb.configure(value=min(v, pb.cget("maximum")),
                         style=("Good" if better else "Bad") + ".Horizontal.TProgressbar" if changed else "Horizontal.TProgressbar")
            val.configure(text=(f"{round(base, dec)}{unit} -> {round(v, dec)}{unit}" if changed else f"{round(v, dec)}{unit}"))
        self.move.configure(text="+ Increased movement speed" if s.move_bonus else "")
