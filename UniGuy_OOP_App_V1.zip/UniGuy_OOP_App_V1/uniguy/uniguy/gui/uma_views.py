"""Umamusume screens: characters, support cards, skills, deck builder, gacha calculator."""
from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk

from ..models import (Deck, GachaPlan, Horse, RARITIES, SKILL_CATEGORIES, STAT_TYPES, Skill, SupportCard,
                      TIERS, TRACKS, ValidationError)
from ..repositories import (CardRepository, DeckRepository, GachaPlanRepository, HorseRepository,
                            RepositoryError, SkillRepository)
from ..services import DeckService, GachaCalculator
from . import theme
from .base import CrudView, FieldSpec, RankedCrudView, ScrollFrame, make_tree


def fmt_num(v) -> str:
    """9000.0 -> '9000', 0.75 -> '0.75'"""
    v = float(v)
    return str(int(v)) if v.is_integer() else str(v)


# --------------------------------------------------------------------------
class HorseView(RankedCrudView):
    TITLE = "Characters"
    SUBTITLE = "Tier list built from each character's three best track aptitudes (0-10). Pick a name to edit it; Table view sorts by any column."
    EYEBROW = "Umamusume"
    ACCENT = theme.UMA
    COLUMNS = [("tier", "Tier", 50, "center"), ("name", "Name", 190, "w"), ("sprint", "Sprint", 60, "center"),
               ("mile", "Mile", 60, "center"), ("medium", "Medium", 65, "center"),
               ("long", "Long", 60, "center"), ("score", "Score", 60, "center")]
    FIELDS = [FieldSpec("name", "Name"), FieldSpec("Sprint", "Sprint (0-10)", "int"),
              FieldSpec("Mile", "Mile (0-10)", "int"), FieldSpec("Medium", "Medium (0-10)", "int"),
              FieldSpec("Long", "Long (0-10)", "int")]
    FILTER_LABEL = "Tier"

    def make_repo(self):
        return HorseRepository()

    def filter_choices(self):
        return list(TIERS)

    def row_values(self, h: Horse):
        a = h.aptitudes
        return (self.tier_of(h), h.name, a["Sprint"], a["Mile"], a["Medium"], a["Long"], f"{h.score():.1f}")

    def to_form(self, h: Horse):
        return {"name": h.name, **h.aptitudes}

    def to_entity(self, v, existing):
        apt = [v[t] for t in TRACKS]
        if existing is None:
            return Horse(v["name"], apt)
        existing.name = v["name"]            # property setters validate
        existing.aptitudes = apt
        return existing


class CardView(RankedCrudView):
    TITLE = "Support cards"
    SUBTITLE = "Each card has a type, rating, stat bonuses and the skills it teaches (a many-to-many link table)."
    EYEBROW = "Umamusume"
    ACCENT = theme.UMA
    COLUMNS = [("tier", "Tier", 50, "center"), ("name", "Name", 260, "w"), ("rarity", "Rarity", 55, "center"),
               ("type", "Type", 75, "center"), ("rating", "Rating", 55, "center"), ("skills", "Skills", 180, "w")]
    FIELDS = [FieldSpec("name", "Name"), FieldSpec("rarity", "Rarity", "choice", RARITIES),
              FieldSpec("type", "Type", "choice", STAT_TYPES), FieldSpec("rating", "Rating (0-10)", "float"),
              FieldSpec("Speed", "Speed bonus", "int"), FieldSpec("Stamina", "Stamina bonus", "int"),
              FieldSpec("Power", "Power bonus", "int"), FieldSpec("Guts", "Guts bonus", "int"),
              FieldSpec("Wisdom", "Wisdom bonus", "int"),
              FieldSpec("skills", "Skills taught", "multilist", lambda: [s.name for s in SkillRepository().all()], 5)]
    FILTER_LABEL = "Type"

    def make_repo(self):
        return CardRepository()

    def filter_choices(self):
        return list(STAT_TYPES)

    def passes_filter(self, c, value):
        return c.type == value

    def row_values(self, c: SupportCard):
        return (self.tier_of(c), c.name, c.rarity, c.type, f"{c.rating:g}", ", ".join(s.name for s in c.skills))

    def to_form(self, c: SupportCard):
        return {"name": c.name, "rarity": c.rarity, "type": c.type, "rating": c.rating,
                "skills": [s.name for s in c.skills], **c.bonuses}

    def to_entity(self, v, existing):
        skills = [self.repo.skills.find_by_name(n) for n in v["skills"]]
        bonuses = {s: v[s] for s in SupportCard.STATS}
        if existing is None:
            return SupportCard(v["name"], v["rarity"], v["type"], v["rating"], bonuses, skills)
        existing.name, existing.rarity, existing.type, existing.rating = v["name"], v["rarity"], v["type"], v["rating"]
        existing.bonuses = bonuses
        existing.skills = skills
        return existing


class SkillView(RankedCrudView):
    TITLE = "Skills"
    SUBTITLE = "Skill tiers are stored in the database; edit them here."
    EYEBROW = "Umamusume"
    ACCENT = theme.UMA
    COLUMNS = [("tier", "Tier", 50, "center"), ("name", "Name", 210, "w"), ("category", "Category", 100, "w"),
               ("desc", "Description", 330, "w")]
    FIELDS = [FieldSpec("name", "Name"), FieldSpec("category", "Category", "combo", SKILL_CATEGORIES),
              FieldSpec("tier", "Tier", "choice", TIERS), FieldSpec("description", "Description", "multiline", height=4)]
    FILTER_LABEL = "Category"

    def make_repo(self):
        return SkillRepository()

    def filter_choices(self):
        return self.repo.categories()

    def passes_filter(self, s, value):
        return s.category == value

    def decorate(self, entities):
        super().decorate(entities)       # fills the tier lookup
        return sorted(entities, key=lambda s: (-s.score(), s.name.lower()))

    def row_values(self, s: Skill):
        return (s.tier, s.name, s.category, s.description)

    def row_tags(self, s):
        return (f"tier_{s.tier}",)

    def to_form(self, s: Skill):
        return {"name": s.name, "category": s.category, "tier": s.tier, "description": s.description}

    def to_entity(self, v, existing):
        if existing is None:
            return Skill(v["name"], v["category"], v["tier"], v["description"])
        existing.name, existing.category, existing.tier, existing.description = \
            v["name"], v["category"], v["tier"], v["description"]
        return existing


# --------------------------------------------------------------------------
class DeckBuilderView(ttk.Frame):
    """Saved decks (one table per user) + live calculation."""
    TITLE = "Deck builder"
    SUBTITLE = "Pick a character and track, add up to six support cards, then save the deck to your profile."
    EYEBROW = "Umamusume"
    ACCENT = theme.UMA

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.horses = HorseRepository()
        self.cards = CardRepository()
        self.decks = DeckRepository()
        self._build()
        self.reload_user()

    def _build(self):
        self.columnconfigure(1, weight=1)
        self.columnconfigure(2, weight=1)
        self.rowconfigure(1, weight=1)

        # saved decks
        left = ttk.Frame(self, style="Panel.TFrame", padding=10)
        left.grid(row=1, column=0, sticky="nsew", padx=(0, 10))
        left.rowconfigure(1, weight=1)
        ttk.Label(left, text="My decks", style="H2.TLabel", background=theme.PANEL).grid(sticky="w")
        self.deck_list = tk.Listbox(left, width=24, bg=theme.PANEL2, fg=theme.FG, selectbackground="#1f5f58",
                                    relief="flat", highlightthickness=0, exportselection=False)
        self.deck_list.grid(row=1, sticky="nsew", pady=6)
        self.deck_list.bind("<<ListboxSelect>>", self._open_deck)
        ttk.Button(left, text="New deck", command=self.new_deck).grid(sticky="ew", pady=2)
        ttk.Button(left, text="Delete deck", style="Danger.TButton", command=self.delete_deck).grid(sticky="ew", pady=2)

        # middle: editor
        mid = ttk.Frame(self)
        mid.grid(row=1, column=1, sticky="nsew", padx=(0, 10))
        mid.columnconfigure(1, weight=1)
        ttk.Label(mid, text="Deck name", style="Mute.TLabel").grid(row=0, column=0, sticky="w", pady=3)
        self.name_var = tk.StringVar()
        ttk.Entry(mid, textvariable=self.name_var).grid(row=0, column=1, sticky="ew", pady=3)
        ttk.Label(mid, text="Character", style="Mute.TLabel").grid(row=1, column=0, sticky="w", pady=3)
        self.horse_var = tk.StringVar()
        self.horse_box = ttk.Combobox(mid, textvariable=self.horse_var, state="readonly")
        self.horse_box.grid(row=1, column=1, sticky="ew", pady=3)
        self.horse_box.bind("<<ComboboxSelected>>", lambda _e: self._recalc())
        ttk.Label(mid, text="Track", style="Mute.TLabel").grid(row=2, column=0, sticky="w", pady=3)
        tr = ttk.Frame(mid)
        tr.grid(row=2, column=1, sticky="w")
        self.track_var = tk.StringVar(value="Medium")
        for t in TRACKS:
            ttk.Radiobutton(tr, text=t, value=t, variable=self.track_var, command=self._recalc).pack(side="left", padx=(0, 10))
        ttk.Label(mid, text="Deck slots (select a card and press Remove)", style="Mute.TLabel").grid(
            row=3, column=0, columnspan=2, sticky="w", pady=(10, 2))
        self.slots = tk.Listbox(mid, height=6, bg=theme.PANEL, fg=theme.FG, selectbackground="#1f5f58",
                                relief="flat", highlightthickness=1, highlightbackground=theme.LINE,
                                exportselection=False)
        self.slots.grid(row=4, column=0, columnspan=2, sticky="ew")
        sb = ttk.Frame(mid)
        sb.grid(row=5, column=0, columnspan=2, sticky="nw", pady=8)
        ttk.Button(sb, text="Remove selected", command=self.remove_card).pack(side="left", padx=(0, 6))
        ttk.Button(sb, text="Save deck", style="Accent.TButton", command=self.save_deck).pack(side="left")

        # picker
        pick = ttk.Frame(mid)
        pick.grid(row=6, column=0, columnspan=2, sticky="nsew")
        pick.columnconfigure(0, weight=1)
        pick.rowconfigure(1, weight=1)
        mid.rowconfigure(6, weight=3)
        top = ttk.Frame(pick)
        top.grid(row=0, sticky="ew", pady=4)
        ttk.Label(top, text="Add support card", style="H2.TLabel").pack(side="left")
        self.q = tk.StringVar()
        self.q.trace_add("write", lambda *_: self._fill_picker())
        ttk.Entry(top, textvariable=self.q, width=18).pack(side="right")
        ttk.Label(top, text="Search", style="Mute.TLabel").pack(side="right", padx=6)
        self.picker = make_tree(pick, [("name", "Card", 230, "w"), ("type", "Type", 70, "center"),
                                       ("rating", "Rating", 55, "center")], height=8)
        self.picker.container.grid(row=1, sticky="nsew")
        self.picker.bind("<Double-1>", lambda _e: self.add_card())
        ttk.Button(pick, text="Add to deck", command=self.add_card).grid(row=2, sticky="w", pady=6)

        # result
        res = ttk.Frame(self, style="Panel.TFrame", padding=12)
        res.grid(row=1, column=2, sticky="nsew")
        res.columnconfigure(0, weight=1)
        ttk.Label(res, text="Deck result", style="H2.TLabel", background=theme.PANEL).grid(sticky="w")
        self.stat_labels = {}
        grid = ttk.Frame(res, style="Panel.TFrame")
        grid.grid(sticky="ew", pady=8)
        for i, stat in enumerate(SupportCard.STATS + ("Fit",)):
            cell = ttk.Frame(grid, style="Panel.TFrame")
            cell.grid(row=0, column=i, padx=6)
            lab = ttk.Label(cell, text="0", style="Big.TLabel", foreground=theme.TYPE_COLORS.get(stat, theme.BRAND))
            lab.pack()
            ttk.Label(cell, text="Avg fit" if stat == "Fit" else stat, style="PanelMute.TLabel").pack()
            self.stat_labels[stat] = lab
        ttk.Label(res, text="Skills gained", style="H2.TLabel", background=theme.PANEL).grid(sticky="w", pady=(8, 2))
        self.skill_label = ttk.Label(res, text="", style="Panel.TLabel", wraplength=330, justify="left")
        self.skill_label.grid(sticky="w")
        ttk.Label(res, text="Warnings", style="H2.TLabel", background=theme.PANEL).grid(sticky="w", pady=(10, 2))
        self.warn_label = ttk.Label(res, text="", style="Panel.TLabel", foreground=theme.GOLD,
                                    wraplength=330, justify="left")
        self.warn_label.grid(sticky="w")
        self.msg = ttk.Label(res, text="", style="PanelMute.TLabel")
        self.msg.grid(sticky="w", pady=(10, 0))

    # ----- data -------------------------------------------------------------
    def reload_user(self):
        self.horse_names = [h.name for h in self.horses.all()]
        self.horse_box.configure(values=self.horse_names)
        self._all_cards = self.cards.all()
        self._fill_picker()
        self._refresh_deck_list()
        self.new_deck()

    def on_data_changed(self):
        self.reload_user()

    def _fill_picker(self):
        self.picker.delete(*self.picker.get_children())
        q = self.q.get().strip().lower()
        for c in self._all_cards:
            if q in c.name.lower():
                self.picker.insert("", "end", iid=str(c.id), values=(c.name, c.type, f"{c.rating:g}"))

    def _refresh_deck_list(self):
        self._saved = self.decks.for_user(self.app.user.id)
        self.deck_list.delete(0, "end")
        for d in self._saved:
            self.deck_list.insert("end", d.name)

    def new_deck(self):
        self._cards: list[SupportCard] = []
        self._editing_id: int | None = None
        self.name_var.set("My deck")
        self.horse_var.set(self.horse_names[0] if self.horse_names else "")
        self.track_var.set("Medium")
        self.deck_list.selection_clear(0, "end")
        self._recalc()

    def _open_deck(self, _e=None):
        sel = self.deck_list.curselection()
        if not sel:
            return
        d = self._saved[sel[0]]
        self._editing_id = d.id
        self._cards = list(d.cards)
        self.name_var.set(d.name)
        self.horse_var.set(d.horse.name)
        self.track_var.set(d.track)
        self._recalc()

    def _current_deck(self) -> Deck:
        horse = self.horses.find_by_name(self.horse_var.get())
        if horse is None:
            raise ValidationError("Choose a character first.")
        deck = Deck(self.name_var.get(), self.app.user.id, horse, self.track_var.get())
        for c in self._cards:
            deck.add_card(c)
        deck.id = self._editing_id
        return deck

    def add_card(self):
        sel = self.picker.selection()
        if not sel:
            return
        card = next(c for c in self._all_cards if c.id == int(sel[0]))
        try:
            probe = Deck("probe", 0, self.horses.find_by_name(self.horse_var.get()), "Medium", list(self._cards))
            probe.add_card(card)
        except ValidationError as e:
            messagebox.showinfo("Deck", str(e), parent=self)
            return
        self._cards.append(card)
        self._recalc()

    def remove_card(self):
        sel = self.slots.curselection()
        if sel:
            del self._cards[sel[0]]
            self._recalc()

    def _recalc(self):
        self.slots.delete(0, "end")
        for c in self._cards:
            self.slots.insert("end", f"{c.name}   ({c.type})")
        for i in range(Deck.MAX_CARDS - len(self._cards)):
            self.slots.insert("end", "(empty slot)")
        horse = self.horses.find_by_name(self.horse_var.get())
        if horse is None:
            return
        deck = Deck("calc", self.app.user.id, horse, self.track_var.get(), list(self._cards))
        r = DeckService.analyse(deck)
        for stat in SupportCard.STATS:
            self.stat_labels[stat].configure(text=f"+{r.totals[stat]}")
        self.stat_labels["Fit"].configure(text=f"{r.average_fit}%")
        self.skill_label.configure(text=", ".join(r.skills) or "Add cards to see skills.")
        self.warn_label.configure(text="\n".join(r.warnings) or "None")

    def save_deck(self):
        try:
            deck = self._current_deck()
            self.decks.save(deck)
        except (ValidationError, RepositoryError) as e:
            messagebox.showwarning("Cannot save deck", str(e), parent=self)
            return
        self._editing_id = deck.id
        self._refresh_deck_list()
        self.msg.configure(text=f"Saved '{deck.name}'.")
        self.app.log_visit(f"Saved deck '{deck.name}'")

    def delete_deck(self):
        if self._editing_id is None:
            return
        if messagebox.askyesno("Delete deck", "Delete this saved deck?", parent=self):
            self.decks.delete(self._editing_id)
            self._refresh_deck_list()
            self.new_deck()


# --------------------------------------------------------------------------
class GachaView(ttk.Frame):
    TITLE = "Gacha calculator"
    SUBTITLE = "Estimate how many pulls you will have by banner end and the chance of the featured character."
    EYEBROW = "Umamusume"
    ACCENT = theme.UMA

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.plans = GachaPlanRepository()
        self.vars: dict[str, tk.StringVar] = {}
        self._editing_id: int | None = None
        self._build()
        self.reload_user()

    def _build(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(1, weight=1)
        scroller = ScrollFrame(self, width=420)      # long form: scrolls on small screens
        scroller.grid(row=1, column=0, sticky="ns", padx=(0, 12))
        left = scroller.body
        ttk.Label(left, text="Saved plans", style="H2.TLabel", background=theme.PANEL).grid(columnspan=2, sticky="w")
        self.plan_var = tk.StringVar()
        self.plan_box = ttk.Combobox(left, textvariable=self.plan_var, state="readonly", width=24)
        self.plan_box.grid(row=1, columnspan=2, sticky="ew", pady=4)
        self.plan_box.bind("<<ComboboxSelected>>", self._load_plan)
        self.name_var = tk.StringVar(value="My plan")
        ttk.Label(left, text="Plan name", style="PanelMute.TLabel").grid(row=2, column=0, sticky="w", pady=(6, 0))
        ttk.Entry(left, textvariable=self.name_var, width=14).grid(row=2, column=1, sticky="ew", pady=(6, 0))
        bt = ttk.Frame(left, style="Panel.TFrame")
        bt.grid(row=3, columnspan=2, sticky="w", pady=8)
        ttk.Button(bt, text="Save plan", style="Accent.TButton", command=self.save_plan).pack(side="left", padx=(0, 6))
        ttk.Button(bt, text="Reset", command=self.reset).pack(side="left", padx=(0, 6))
        ttk.Button(bt, text="Delete", style="Danger.TButton", command=self.delete_plan).pack(side="left")
        self.msg = ttk.Label(left, text="", style="PanelMute.TLabel", wraplength=260)
        self.msg.grid(row=4, columnspan=2, sticky="w")
        for i, (key, label) in enumerate(GachaPlan.LABELS.items(), start=5):
            ttk.Label(left, text=label, style="PanelMute.TLabel").grid(row=i, column=0, sticky="w", pady=2, padx=(0, 8))
            v = tk.StringVar(value=fmt_num(GachaPlan.DEFAULTS[key]))
            v.trace_add("write", lambda *_: self.calculate())
            ttk.Entry(left, textvariable=v, width=12).grid(row=i, column=1, sticky="ew", pady=2)
            self.vars[key] = v
        right = ttk.Frame(self)
        right.grid(row=1, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(2, weight=1)
        tiles = ttk.Frame(right)
        tiles.grid(row=0, sticky="ew")
        self.tile = {}
        for i, (k, t) in enumerate([("pulls", "Pulls by banner end"), ("total", "Total incl. spent"),
                                    ("prob", "Chance of featured"), ("remain", "Pulls left to pity")]):
            box = ttk.Frame(tiles, style="Panel.TFrame", padding=10)
            box.grid(row=0, column=i, padx=(0, 8), sticky="ew")
            tiles.columnconfigure(i, weight=1)
            lab = ttk.Label(box, text="0", style="Big.TLabel", foreground=theme.UMA)
            lab.pack(anchor="w")
            ttk.Label(box, text=t, style="PanelMute.TLabel").pack(anchor="w")
            self.tile[k] = lab
        self.summary = ttk.Label(right, text="", style="Mute.TLabel", wraplength=700, justify="left")
        self.summary.grid(row=1, sticky="w", pady=8)
        self.canvas = tk.Canvas(right, bg=theme.PANEL, highlightthickness=1, highlightbackground=theme.LINE, height=300)
        self.canvas.grid(row=2, sticky="nsew")
        self.canvas.bind("<Configure>", lambda _e: self.calculate())
        self.miles = make_tree(right, [("n", "Pulls", 80, "center"), ("p", "Chance of featured", 160, "center")], height=4)
        self.miles.container.grid(row=3, sticky="ew", pady=(10, 0))
        self._result = None

    # ----- helpers ----------------------------------------------------------
    def _params(self) -> dict:
        out = {}
        for k, v in self.vars.items():
            try:
                x = float(v.get())
                out[k] = x if x >= 0 else GachaPlan.DEFAULTS[k]
            except ValueError:
                out[k] = GachaPlan.DEFAULTS[k]
        return GachaPlan("calc", 0, out).params

    def calculate(self):
        p = self._params()
        r = GachaCalculator(p).calculate()
        self.tile["pulls"].configure(text=str(r.pulls))
        self.tile["total"].configure(text=str(r.total))
        self.tile["prob"].configure(text=f"{r.probability}%")
        self.tile["remain"].configure(text=str(r.remaining))
        if r.remaining == 0:
            self.summary.configure(text="You reach the guarantee before the banner ends.")
        else:
            more = f" (about {r.days_more} more days at your income)" if r.days_more else ""
            self.summary.configure(text=f"You need {r.carats_needed:,} more carats{more} to reach the guarantee.")
        self.miles.delete(*self.miles.get_children())
        for n, pr in r.milestones:
            self.miles.insert("", "end", values=(n, f"{pr}%"))
        self._draw(r, p)

    def _draw(self, r, p):
        c = self.canvas
        c.delete("all")
        w, h = max(c.winfo_width(), 300), max(c.winfo_height(), 200)
        l, rr, t, b = 50, w - 20, 20, h - 30
        top = max(max(r.series), p["pity"]) * 1.08
        n = len(r.series) - 1 or 1
        for i in range(5):
            y = b - (b - t) * i / 4
            c.create_line(l, y, rr, y, fill=theme.LINE, dash=(2, 4))
            c.create_text(l - 6, y, text=str(int(top * i / 4)), fill=theme.MUTE, anchor="e")
        pts = []
        for i, v in enumerate(r.series):
            pts += [l + (rr - l) * i / n, b - (b - t) * v / top]
        if len(pts) >= 4:
            c.create_line(*pts, fill=theme.UMA, width=2, smooth=False)
        py = b - (b - t) * p["pity"] / top
        c.create_line(l, py, rr, py, fill=theme.GOLD, dash=(6, 3))
        c.create_text(rr, py - 8, text=f"pity {int(p['pity'])}", fill=theme.GOLD, anchor="e")
        c.create_text(l, b + 14, text="day 0", fill=theme.MUTE, anchor="w")
        c.create_text(rr, b + 14, text=f"day {n}", fill=theme.MUTE, anchor="e")

    # ----- saved plans ------------------------------------------------------
    def reload_user(self):
        self._plans = self.plans.for_user(self.app.user.id)
        self.plan_box.configure(values=[p.name for p in self._plans])
        self.plan_var.set("")
        self._editing_id = None

    def on_data_changed(self):
        pass

    def _load_plan(self, _e=None):
        plan = next((p for p in self._plans if p.name == self.plan_var.get()), None)
        if plan:
            self._editing_id = plan.id
            self.name_var.set(plan.name)
            for k, v in plan.params.items():
                self.vars[k].set(fmt_num(v))
            self.calculate()

    def save_plan(self):
        try:
            plan = GachaPlan(self.name_var.get(), self.app.user.id, self._params())
            plan.id = self._editing_id
            self.plans.save(plan)
        except (ValidationError, RepositoryError) as e:
            messagebox.showwarning("Cannot save plan", str(e), parent=self)
            return
        self._editing_id = plan.id
        self.reload_user()
        self.plan_var.set(plan.name)
        self._editing_id = plan.id
        self.msg.configure(text=f"Saved '{plan.name}'.")

    def delete_plan(self):
        if self._editing_id is None:
            return
        self.plans.delete(self._editing_id)
        self.reload_user()
        self.msg.configure(text="Plan deleted.")

    def reset(self):
        for k, v in GachaPlan.DEFAULTS.items():
            self.vars[k].set(fmt_num(v))
        self._editing_id = None
        self.plan_var.set("")
        self.name_var.set("My plan")
