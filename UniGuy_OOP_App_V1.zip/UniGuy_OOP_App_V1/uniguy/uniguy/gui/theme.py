"""Dark 'game menu' look, borrowed from the original UniGuy web page."""
from tkinter import ttk
import tkinter.font as tkfont

BG, PANEL, PANEL2, LINE = "#0b0d10", "#13161b", "#1a1e25", "#3b434d"
FG, MUTE = "#e9edf1", "#8f9aa6"
BRAND, APEX, UMA, GOLD = "#3fd8c6", "#ea4b3c", "#ff86bb", "#f5c451"
GOOD, BAD = "#8ce99a", "#ff6b6b"
TIER_COLORS = {"S": "#ff6b6b", "A": "#ffa94d", "B": "#ffe066", "C": "#8ce99a", "D": "#74c0fc"}
TYPE_COLORS = {"Speed": "#4dabf7", "Stamina": "#ff8787", "Power": "#ffa94d",
               "Guts": "#f783ac", "Wisdom": "#69db7c", "Friend": "#ffd43b"}
EDGE = "#aab1b9"            # light border used on the chamfered cards
STRIPE = "#171a20"          # the faint diagonal stripes on cards
HEX_BG = "#0e1115"

# The website uses Rajdhani + Barlow. Tk can only use fonts that are installed on the machine,
# so we pick the closest installed match and fall back gracefully (see apply_theme).
DISPLAY = "TkDefaultFont"
BODY = "TkDefaultFont"
_DISPLAY_CHOICES = ("Rajdhani", "Bahnschrift SemiBold", "Bahnschrift", "Barlow Semi Condensed",
                    "Arial Narrow", "Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans")
_BODY_CHOICES = ("Barlow", "Segoe UI", "Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans")


def display(size: int, weight: str = "bold") -> tuple:
    """Heading font (condensed, bold, used in capitals like the website)."""
    return (DISPLAY, size, weight)


def body(size: int = 10, weight: str = "normal") -> tuple:
    return (BODY, size, weight)


def _pick_font(choices) -> str:
    have = {f.lower(): f for f in tkfont.families()}
    for c in choices:
        if c.lower() in have:
            return have[c.lower()]
    return "TkDefaultFont"


def blend(fg: str, bg: str, alpha: float) -> str:
    """Mix two #rrggbb colours (Tk has no real transparency)."""
    a = [int(fg[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(bg[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(x * alpha + y * (1 - alpha)):02x}" for x, y in zip(a, b))


def apply_theme(root) -> None:
    global DISPLAY, BODY
    DISPLAY, BODY = _pick_font(_DISPLAY_CHOICES), _pick_font(_BODY_CHOICES)
    for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
        try:
            f = tkfont.nametofont(name)
            f.configure(size=10)
            if BODY != "TkDefaultFont":
                f.configure(family=BODY)
        except Exception:
            pass
    root.configure(bg=BG)
    root.option_add("*TCombobox*Listbox.background", PANEL2)
    root.option_add("*TCombobox*Listbox.foreground", FG)
    root.option_add("*TCombobox*Listbox.selectBackground", BRAND)
    root.option_add("*TCombobox*Listbox.selectForeground", "#06201c")

    s = ttk.Style(root)
    s.theme_use("clam")
    s.configure(".", background=BG, foreground=FG, fieldbackground=PANEL2, bordercolor=LINE,
                lightcolor=LINE, darkcolor=LINE, troughcolor=PANEL, focuscolor=BRAND)
    s.configure("TFrame", background=BG)
    s.configure("Panel.TFrame", background=PANEL)
    s.configure("TLabel", background=BG, foreground=FG)
    s.configure("Panel.TLabel", background=PANEL)
    s.configure("Mute.TLabel", foreground=MUTE)
    s.configure("PanelMute.TLabel", background=PANEL, foreground=MUTE)
    s.configure("H1.TLabel", font=display(26))
    s.configure("H2.TLabel", font=display(13), foreground=BRAND)
    s.configure("Big.TLabel", font=display(20), background=PANEL)
    s.configure("Warn.TLabel", foreground=GOLD)
    s.configure("Brand.TLabel", font=display(20), foreground=BRAND)

    s.configure("TButton", background=PANEL2, foreground=FG, padding=(8, 4), borderwidth=1)
    s.map("TButton", background=[("active", LINE)], foreground=[("disabled", MUTE)])
    s.configure("Accent.TButton", background=BRAND, foreground="#06201c", font=display(11))
    s.map("Accent.TButton", background=[("active", "#6ef0e0"), ("disabled", LINE)])
    s.configure("Danger.TButton", background="#4a2321", foreground="#ffb3ad")
    s.map("Danger.TButton", background=[("active", "#6b2f2c")])

    s.configure("TEntry", padding=4, insertcolor=FG)
    s.configure("TCombobox", padding=4, arrowcolor=FG)
    s.map("TCombobox", fieldbackground=[("readonly", PANEL2)], foreground=[("readonly", FG)])
    s.configure("TCheckbutton", background=BG)
    s.configure("TRadiobutton", background=BG)
    s.map("TRadiobutton", background=[("active", BG)])

    s.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=FG, rowheight=24,
                borderwidth=0)
    s.map("Treeview", background=[("selected", "#1f5f58")], foreground=[("selected", "#ffffff")])
    s.configure("Treeview.Heading", background=PANEL2, foreground=MUTE, relief="flat",
                font=display(10), padding=5)
    s.map("Treeview.Heading", background=[("active", LINE)])

    s.configure("TNotebook", background=BG, borderwidth=0, tabmargins=(0, 0, 0, 0))
    s.configure("TNotebook.Tab", background=PANEL, foreground=MUTE, padding=(18, 8),
                font=("TkDefaultFont", 10, "bold"))
    s.map("TNotebook.Tab", background=[("selected", BRAND)], foreground=[("selected", "#06201c")])
    s.configure("Sub.TNotebook.Tab", padding=(12, 6))
    s.configure("Uma.TNotebook", background=BG)
    s.configure("Uma.TNotebook.Tab", background=PANEL, foreground=MUTE, padding=(12, 6))
    s.map("Uma.TNotebook.Tab", background=[("selected", UMA)], foreground=[("selected", "#2a0a18")])
    s.configure("Apex.TNotebook", background=BG)
    s.configure("Apex.TNotebook.Tab", background=PANEL, foreground=MUTE, padding=(12, 6))
    s.map("Apex.TNotebook.Tab", background=[("selected", APEX)], foreground=[("selected", "#ffffff")])

    s.configure("TLabelframe", background=BG, bordercolor=LINE)
    s.configure("TLabelframe.Label", background=BG, foreground=MUTE, font=display(10))
    s.configure("Vertical.TScrollbar", background=LINE, troughcolor=PANEL, bordercolor=PANEL,
                arrowcolor=MUTE, lightcolor=LINE, darkcolor=LINE, relief="flat")
    s.map("Vertical.TScrollbar", background=[("active", MUTE), ("!active", LINE)])
    s.configure("Horizontal.TProgressbar", background=BRAND, troughcolor=PANEL2, thickness=8)
    s.configure("Good.Horizontal.TProgressbar", background=GOOD, troughcolor=PANEL2, thickness=8)
    s.configure("Bad.Horizontal.TProgressbar", background=BAD, troughcolor=PANEL2, thickness=8)
