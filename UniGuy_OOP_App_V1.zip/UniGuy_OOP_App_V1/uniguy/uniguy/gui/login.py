"""Log in / Create account screen, drawn in the same style as the rest of the app."""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ..auth import Account, AccountStore, AuthError
from . import theme
from .widgets import PillTabs, hex_points


class LoginScreen(tk.Frame):
    def __init__(self, master, store: AccountStore, on_success, notice: str = ""):
        super().__init__(master, bg=theme.BG)
        self.store, self.on_success = store, on_success
        self.mode = "login" if store.count() else "create"

        wrap = tk.Frame(self, bg=theme.BG)
        wrap.place(relx=0.5, rely=0.45, anchor="center")

        brand = tk.Canvas(wrap, width=460, height=80, bg=theme.BG, highlightthickness=0)
        brand.pack(pady=(0, 14))
        brand.create_polygon(hex_points(40, 40, 30), fill=theme.BRAND, outline="")
        brand.create_text(40, 40, text="U", fill="#06201c", font=theme.display(26))
        x = 88
        for text, color in (("UNI", theme.FG), ("GUY'D", theme.BRAND)):
            for ch in text:
                t = brand.create_text(x, 40, text=ch, anchor="w", fill=color, font=theme.display(34))
                x = brand.bbox(t)[2] + 5

        panel = tk.Frame(wrap, bg=theme.PANEL, highlightthickness=1, highlightbackground=theme.EDGE, padx=28, pady=24)
        panel.pack()
        self.tabs = PillTabs(panel, [("login", "Log in"), ("create", "Create account")], self._set_mode,
                             accent=theme.BRAND, active=self.mode, bg=theme.PANEL)
        self.tabs.pack(anchor="w", pady=(0, 16))

        self.user_var, self.pw_var, self.pw2_var = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.user_entry = self._field(panel, "Username", self.user_var)
        self.pw_entry = self._field(panel, "Password", self.pw_var, secret=True)
        self.pw2_row = tk.Frame(panel, bg=theme.PANEL)
        self.pw2_row.pack(fill="x")
        self.pw2_entry = self._field(self.pw2_row, "Confirm password", self.pw2_var, secret=True)

        self.msg = tk.Label(panel, text=notice, bg=theme.PANEL, fg=theme.GOOD, font=theme.body(10),
                            wraplength=300, justify="left")
        self.msg.pack(anchor="w", pady=(4, 8))
        self.submit = ttk.Button(panel, text="LOG IN", style="Accent.TButton", command=self.submit_form)
        self.submit.pack(fill="x", ipady=4)
        self.hint = tk.Label(panel, text="", bg=theme.PANEL, fg=theme.MUTE, font=theme.body(9),
                             wraplength=300, justify="left")
        self.hint.pack(anchor="w", pady=(12, 0))

        for e in (self.user_entry, self.pw_entry, self.pw2_entry):
            e.bind("<Return>", lambda _e: self.submit_form())
        last = store.last_user()
        if last and self.mode == "login":
            self.user_var.set(last)
        self._set_mode(self.mode)
        self.msg.configure(text=notice, fg=theme.GOOD)
        self.after(100, lambda: (self.pw_entry if self.user_var.get() else self.user_entry).focus_set())

    def _field(self, parent, label: str, var: tk.StringVar, secret: bool = False) -> ttk.Entry:
        tk.Label(parent, text=label.upper(), bg=theme.PANEL, fg=theme.MUTE, font=theme.display(10)).pack(anchor="w")
        entry = ttk.Entry(parent, textvariable=var, width=34, show="\u2022" if secret else "")
        entry.pack(fill="x", pady=(2, 10), ipady=3)
        return entry

    def _set_mode(self, mode: str) -> None:
        self.mode = mode
        self.tabs.select(mode)
        self.msg.configure(text="")
        self.pw_var.set("")
        self.pw2_var.set("")
        if mode == "create":
            self.pw2_row.pack(fill="x", before=self.msg)
            self.submit.configure(text="CREATE ACCOUNT")
            self.hint.configure(text=f"Each account gets its own private copy of the guide data, decks and plans. "
                                     f"Password: at least {AccountStore.MIN_PASSWORD} characters.")
        else:
            self.pw2_row.pack_forget()
            self.submit.configure(text="LOG IN")
            self.hint.configure(text="Don't have an account yet? Open the Create account tab.")

    def error(self, text: str) -> None:
        self.msg.configure(text=text, fg=theme.BAD)

    def submit_form(self) -> None:
        name, pw = self.user_var.get().strip(), self.pw_var.get()
        try:
            if self.mode == "create":
                if pw != self.pw2_var.get():
                    raise AuthError("The two passwords do not match.")
                account: Account = self.store.create(name, pw)
            else:
                account = self.store.verify(name, pw)
        except AuthError as e:
            self.error(str(e))
            self.pw_var.set("")
            self.pw2_var.set("")
            return
        self.on_success(account)
