"""Run the UniGuy desktop app:   python main.py   (you will be asked to log in or create an account)"""
import sys

from uniguy.database import Database


def main() -> None:
    if "--no-gui" in sys.argv:          # quick check that the seed data loads (uses a throw-away database)
        db = Database(":memory:")
        for table in ("horses", "support_cards", "skills", "legends", "weapons", "maps"):
            print(f"{table:15} {db.query_one(f'SELECT COUNT(*) AS n FROM {table}')['n']} rows")
        return
    from uniguy.gui.app import App
    App().mainloop()


if __name__ == "__main__":
    main()
