-- UniGuy database schema (SQLite)
-- Run automatically by uniguy/database.py the first time the app starts.

PRAGMA foreign_keys = ON;

-- ---------- Umamusume ----------
CREATE TABLE IF NOT EXISTS horses (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT    NOT NULL UNIQUE,
    apt_sprint   INTEGER NOT NULL CHECK (apt_sprint BETWEEN 0 AND 10),
    apt_mile     INTEGER NOT NULL CHECK (apt_mile   BETWEEN 0 AND 10),
    apt_medium   INTEGER NOT NULL CHECK (apt_medium BETWEEN 0 AND 10),
    apt_long     INTEGER NOT NULL CHECK (apt_long   BETWEEN 0 AND 10)
);

CREATE TABLE IF NOT EXISTS skills (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    category    TEXT NOT NULL,
    tier        TEXT NOT NULL CHECK (tier IN ('S','A','B','C','D')),
    description TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS support_cards (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    name      TEXT NOT NULL UNIQUE,
    rarity    TEXT NOT NULL CHECK (rarity IN ('R','SR','SSR')),
    type      TEXT NOT NULL CHECK (type IN ('Speed','Stamina','Power','Guts','Wisdom','Friend')),
    rating    REAL NOT NULL CHECK (rating BETWEEN 0 AND 10),
    b_speed   INTEGER NOT NULL DEFAULT 0,
    b_stamina INTEGER NOT NULL DEFAULT 0,
    b_power   INTEGER NOT NULL DEFAULT 0,
    b_guts    INTEGER NOT NULL DEFAULT 0,
    b_wisdom  INTEGER NOT NULL DEFAULT 0
);

-- many-to-many: a card teaches several skills, a skill is taught by several cards
CREATE TABLE IF NOT EXISTS card_skills (
    card_id  INTEGER NOT NULL REFERENCES support_cards(id) ON DELETE CASCADE,
    skill_id INTEGER NOT NULL REFERENCES skills(id)        ON DELETE CASCADE,
    PRIMARY KEY (card_id, skill_id)
);

-- ---------- Apex Legends ----------
CREATE TABLE IF NOT EXISTS legend_classes (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    name      TEXT NOT NULL UNIQUE,
    color     TEXT NOT NULL,
    playstyle TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS legends (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    class_id    INTEGER NOT NULL REFERENCES legend_classes(id),
    description TEXT NOT NULL DEFAULT '',
    meta_combo  TEXT NOT NULL DEFAULT '',
    meta_why    TEXT NOT NULL DEFAULT ''
);

-- level is 'blue', 'purple' or 'passive'
CREATE TABLE IF NOT EXISTS legend_perks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    legend_id   INTEGER NOT NULL REFERENCES legends(id) ON DELETE CASCADE,
    level       TEXT NOT NULL CHECK (level IN ('blue','purple','passive')),
    name        TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    is_meta     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS weapon_classes (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    name  TEXT NOT NULL UNIQUE,
    kind  TEXT NOT NULL,           -- shotgun, smg, pistol, ord, ar, lmg, dmr, snp
    ammo  TEXT NOT NULL,
    blurb TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS weapons (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL UNIQUE,
    class_id      INTEGER NOT NULL REFERENCES weapon_classes(id),
    optic         TEXT NOT NULL DEFAULT '',
    notes         TEXT NOT NULL DEFAULT '',
    damage        REAL NOT NULL DEFAULT 0,
    headshot      REAL NOT NULL DEFAULT 0,
    mag_size      REAL NOT NULL DEFAULT 0,
    fire_rate     REAL NOT NULL DEFAULT 0,   -- rounds per minute
    reload_time   REAL NOT NULL DEFAULT 0,   -- seconds
    recoil_ctrl   REAL NOT NULL DEFAULT 0,   -- 0-100
    hipfire       REAL NOT NULL DEFAULT 0,   -- 0-100
    handling      REAL NOT NULL DEFAULT 0,   -- 0-100
    rec_mag       TEXT NOT NULL DEFAULT '',
    rec_barrel    TEXT NOT NULL DEFAULT '',
    rec_stock     TEXT NOT NULL DEFAULT '',
    rec_corrupted TEXT NOT NULL DEFAULT '',
    rec_note      TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS maps (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL DEFAULT ''
);

-- many-to-many with an extra column (the reason this legend suits the map)
CREATE TABLE IF NOT EXISTS map_legends (
    map_id    INTEGER NOT NULL REFERENCES maps(id)    ON DELETE CASCADE,
    legend_id INTEGER NOT NULL REFERENCES legends(id) ON DELETE CASCADE,
    reason    TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (map_id, legend_id)
);

-- ---------- Users and their saved data ----------
CREATE TABLE IF NOT EXISTS users (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    name  TEXT NOT NULL UNIQUE,
    color TEXT NOT NULL DEFAULT '#3fd8c6'
);

CREATE TABLE IF NOT EXISTS decks (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id  INTEGER NOT NULL REFERENCES users(id)  ON DELETE CASCADE,
    name     TEXT NOT NULL,
    horse_id INTEGER NOT NULL REFERENCES horses(id) ON DELETE CASCADE,
    track    TEXT NOT NULL CHECK (track IN ('Sprint','Mile','Medium','Long')),
    UNIQUE (user_id, name)
);

CREATE TABLE IF NOT EXISTS deck_cards (
    deck_id INTEGER NOT NULL REFERENCES decks(id)         ON DELETE CASCADE,
    card_id INTEGER NOT NULL REFERENCES support_cards(id) ON DELETE CASCADE,
    PRIMARY KEY (deck_id, card_id)
);

CREATE TABLE IF NOT EXISTS gacha_plans (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name    TEXT NOT NULL,
    carats  REAL NOT NULL, tickets REAL NOT NULL, spent REAL NOT NULL,
    pity    REAL NOT NULL, rate    REAL NOT NULL, feat  REAL NOT NULL,
    daily   REAL NOT NULL, weekly  REAL NOT NULL, monthly REAL NOT NULL,
    events  REAL NOT NULL, days    REAL NOT NULL, perpull REAL NOT NULL,
    UNIQUE (user_id, name)
);

CREATE TABLE IF NOT EXISTS visit_log (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    page    TEXT NOT NULL,
    visited_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
