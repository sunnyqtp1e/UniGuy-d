# UniGuy (OOP + SQLite desktop app)

UniGuy is a game guide for **Umamusume** and **Apex Legends**: tier lists, deck builder, gacha calculator,
legends with perks, weapons with an attachment builder, and map picks.
This version is a Python desktop app (Tkinter) that stores everything in a **SQLite database**.
The data comes from your original `UniGuyV7.html` (69 characters, 200 support cards, 24 skills, 28 legends,
32 weapons, 6 maps).

## Run it

```
python main.py
```

* Python 3.9 or newer. There are **no packages to install** (Tkinter and SQLite ship with Python).
* On Linux, Tkinter may need: `sudo apt install python3-tk`.
* The first start creates `uniguy.db` from `schema.sql` and `data/seed.json`.
  Delete `uniguy.db` to reset everything to the original data.
* Quick database check without the GUI: `python main.py --no-gui`
* Tests: `python -m unittest discover -s tests -v`

## Project layout (layered design)

```
main.py                 entry point
schema.sql              the database design (tables, keys, constraints)
data/seed.json          data extracted from UniGuyV7.html
uniguy/
  database.py           Database (singleton) + Seeder
  models.py             domain classes: Entity, Rankable, Horse, Skill, SupportCard, Legend, Weapon, Deck ...
  repositories.py       one Repository class per table (all the SQL lives here)
  services.py           logic: TierService, DeckService, GachaCalculator, WeaponBuild + Attachment classes
  gui/
    base.py             CrudView (abstract screen), RankedCrudView, EntityForm
    widgets.py          website look: ChamferCard (+ Game/Tool/Legend/Weapon/Map cards), PillTabs, TierBoard, GroupedBoard
    images.py           ImageStore (singleton) that loads assets/ by file name
    uma_views.py        Characters, Support cards, Skills, Deck builder, Gacha calculator
    apex_views.py       Legends, Weapons, Weapon builder, Maps
    app.py              main window: login/session handling, header, page routing, Home, hub, History drop-down, Account & data
    login.py            LoginScreen (log in / create account)
uniguy/assets/          PNGs: legends/, legend_art/, weapons/, maps/
tests/test_app.py       21 tests (models, CRUD, services, and a GUI smoke test)
```

Rule of the design: the GUI never writes SQL, and models never know about the GUI or the database.

## OOP concepts and where to find them

| Concept | Where | How |
|---|---|---|
| **Abstraction** | `models.Entity`, `models.Rankable`, `repositories.Repository`, `services.Attachment`, `gui.base.CrudView` | Abstract base classes (`ABC` + `@abstractmethod`). They cannot be instantiated; subclasses must fill in the abstract methods. |
| **Inheritance** | `Horse`, `Skill`, `SupportCard`, `Legend`, `Weapon`, `Deck` extend `Entity`; `CardRepository` extends `Repository`; `HorseView` extends `RankedCrudView` extends `CrudView`; `Magazine`, `Barrel`, `Stock`, `CorruptedAttachment` extend `Attachment` | Shared behaviour (id, validated name, equality) is written once in the parent. |
| **Multiple inheritance** | `class Horse(Entity, Rankable)` | A horse is both a database entity and something that can be ranked. |
| **Polymorphism** | `TierService.tierize()` calls `item.score()` on horses, cards and skills. `WeaponBuild.calculate()` calls `attachment.apply()` on every attachment. `CrudView` calls `self.to_entity()` and `self.repo.save()` without knowing which model. | Same call, different behaviour per class. |
| **Encapsulation** | `Horse.aptitudes`, `SupportCard.rating`, `Skill.tier`, `Entity.name`; the sqlite connection is private in `Database` | Private attributes (`_rating`) with properties that validate and raise `ValidationError`. |
| **Composition / aggregation** | `SupportCard` has `Skill`s, `Deck` has a `Horse` and `SupportCard`s, `Legend` has a `LegendClass` and `Perk`s, `WeaponBuild` has a `Weapon` and `Attachment`s | "Has-a" relationships, mirrored by foreign keys in the database. |
| **Singleton** | `Database.instance()` | One shared database object. |
| **Template Method** | `CrudView` | Implements the whole list/form/save/delete flow once; subclasses supply `make_repo`, `row_values`, `to_entity`, `to_form`. |
| **Repository pattern** | `repositories.py` | Separates SQL from the domain classes. |
| **Exceptions** | `ValidationError`, `RepositoryError` | Raised by models/repositories, caught in the GUI and shown as a message box. |

## Database design (SQLite)

```
horses            skills           support_cards
  id PK             id PK            id PK
  name UNIQUE       name UNIQUE      name UNIQUE, rarity, type, rating, b_speed ... b_wisdom
  apt_sprint..long  category, tier        |
                    description           |  card_skills (card_id FK, skill_id FK)  many-to-many
                         \________________/

legend_classes 1---* legends 1---* legend_perks (level: blue/purple/passive, is_meta)
weapon_classes 1---* weapons
maps *---* legends        via map_legends (map_id, legend_id, reason)

users 1---* decks *---* support_cards   via deck_cards
             decks *---1 horses
users 1---* gacha_plans
users 1---* visit_log
```

* Primary keys, foreign keys (`PRAGMA foreign_keys = ON`), `UNIQUE` and `CHECK` constraints are in `schema.sql`.
* `ON DELETE CASCADE` on link tables and on a user's decks/plans/history; classes that are still used cannot be deleted.
* Two many-to-many tables (`card_skills`, `map_legends`) and one many-to-many with a payload column (`reason`).

## What the app does

* **Characters / Support cards / Skills**: tier lists (S to D) calculated from the data, search, filter, click a heading to sort, full Create / Read / Update / Delete.
* **Deck builder**: up to 6 cards, live stat totals, skills gained, compatibility and warnings. Decks are saved per profile.
* **Gacha calculator**: pulls by banner end, chance of the featured character, pity chart. Plans saved per profile.
* **Legends**: class, meta combination, add or remove perks. **Weapons**: base stats and recommended builds.
* **Weapon builder**: choose attachments and see the stats change; "Apply recommended build" uses the stored recommendation.
* **Maps**: recommended legends with a reason.
* **Profiles**: switch profile in the top bar; each has its own decks, plans and visit history (replaces the old `localStorage`).

## Notes

* Scores and tier values are the placeholder values from your HTML; edit them in the app.
* The legend portraits, weapon icons and map photos were extracted from the HTML into `uniguy/assets/` and are used by the cards (see "Look and feel").
* Corrupted-attachment numbers are approximate (same as in the HTML).

## Look and feel (matches UniGuyV7.html)

* Same palette, chamfered stripe cards with white corner slashes, hex logo, "Pick a game" home, breadcrumbs,
  pill tabs, S to D tier boards, legend portraits grouped by class, weapon cards and map photos.
* Pages are chosen by route (`home`, `uma`, `uma-chars`, `apex-guns` ...) like the website's `#` links.
* Every list screen has a **Board / Table** switch. Board is the website look; Table is the sortable grid.
  Both edit the same data (Create / Read / Update / Delete still works from the form on the right).
* **Images**: files are found by name, for example `assets/legends/bangalore.png`, `assets/weapons/r_99.png`,
  `assets/maps/olympus.png`. A missing file shows a placeholder. To use your own originals, drop in a PNG with
  the same name. With Pillow installed (`pip install pillow`, optional) any size is shrunk to fit.
* **Fonts**: the site uses Rajdhani and Barlow. The app uses them if installed, otherwise the closest match
  (Bahnschrift, Arial Narrow, Helvetica ...), so letter shapes can differ a little from the web page.
* OOP: `ChamferCard` draws the frame and calls `paint_content()`; each card type overrides only that method.

## Accounts, separate data and deleting data

* `python main.py` opens a **login screen**. The first time, create an account (username 3-20 letters/numbers/_/-,
  password at least 6 characters). The account chip (top right) has *Account & data* and *Log out*.
* **Separate data**: every account gets its own complete database, `data/users/<name>.db`, seeded with its own copy
  of the guide data. Decks, gacha plans, history and any edits to characters, cards, skills, legends, weapons or
  maps belong to that account only. `data/accounts.db` only stores usernames, salts and password hashes.
* **Passwords** are stored as salted PBKDF2-HMAC-SHA256 hashes (`uniguy/auth.py`), never as text.
  This separates accounts inside the app; the database files themselves are not encrypted.
* **Account & data page**: change colour and password, and delete data: saved decks, gacha plans, visit history,
  *reset everything to defaults* (guide data + decks + plans + history, keeps the account) or *delete my account*
  (asks for your password, then removes the account and its file).
* Your old single-user `uniguy.db` is no longer used directly. If it exists when the **first** account is created,
  that account adopts its data (a copy is made).
* New code: `auth.py` (AccountStore, PasswordHasher, AuthError), `gui/login.py` (LoginScreen),
  `DeckRepository.delete_for_user`, `GachaPlanRepository.delete_for_user`.

## Playing with the guide open (Window menu and compact mode)

* **WINDOW** button (top right): *Always on top*, an *Opacity* slider (35-100%) and *Compact mode*.
  A teal dot on the button shows when the window is pinned. Pin and opacity are remembered between runs.
* **Compact mode** shrinks the app to a narrow window with a slim bar: page menu (top left), opacity,
  PIN and EXPAND. Lists and boards, the Home page and the weapon builder fit it. The deck builder, gacha
  calculator and account page need the full window, so opening one of them expands the window automatically.
* **Limits**: this is a normal window, so it floats over games in *windowed* or *borderless* mode. A game in true
  *exclusive fullscreen* hides it. Opacity needs a compositing window manager on Linux (Windows and macOS are fine).
