"""Visual building blocks that reproduce the look of the UniGuy website in Tkinter.

OOP ideas used here
-------------------
* Inheritance + Polymorphism : every card is a ChamferCard. The base class draws the frame (stripes,
  chamfered corners, white slashes, hover) and calls paint_content(); GameCard, ToolCard, LegendCard,
  WeaponCard and MapCard each override only paint_content().
* Encapsulation : cards keep their own hover / selected state and repaint themselves.
* Composition : TierBoard and GroupedBoard are built from a VScroll (scrolling) + FlowFrames (wrapping rows).
"""
from __future__ import annotations

import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk

from . import theme
from .images import ImageStore

_fonts: dict[tuple, tkfont.Font] = {}


def font_of(spec: tuple) -> tkfont.Font:
    """Cached Font objects (measuring text is needed a lot). Rebuilt if the Tk window they belonged to is gone."""
    try:
        if spec in _fonts:
            _fonts[spec].metrics("linespace")
            return _fonts[spec]
    except tk.TclError:
        _fonts.clear()
    _fonts[spec] = tkfont.Font(font=spec)
    return _fonts[spec]


def text_on(color: str) -> str:
    """Dark or white text, whichever reads better on this background (like the website's active tabs)."""
    r, g, b = (int(color[i:i + 2], 16) for i in (1, 3, 5))
    return "#06100f" if (0.299 * r + 0.587 * g + 0.114 * b) > 140 else "#ffffff"


def hex_points(cx: float, cy: float, r: float) -> list[float]:
    """Pointy-top hexagon, same shape as the website's logo and legend portraits."""
    import math
    pts = []
    for i in range(6):
        a = math.radians(60 * i - 90)
        pts += [cx + r * math.cos(a), cy + r * math.sin(a)]
    return pts


def _clip(poly: list[tuple], w: float, h: float) -> list[tuple]:
    """Sutherland-Hodgman: cut a polygon to the rectangle (0,0)-(w,h). Used for the diagonal stripes."""
    def run(pts, inside, cross):
        out = []
        for i, cur in enumerate(pts):
            prev = pts[i - 1]
            if inside(cur):
                if not inside(prev):
                    out.append(cross(prev, cur))
                out.append(cur)
            elif inside(prev):
                out.append(cross(prev, cur))
        return out

    def at_x(x):
        return lambda a, b: (x, a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0]))

    def at_y(y):
        return lambda a, b: (a[0] + (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]), y)

    for inside, cross in ((lambda p: p[0] >= 0, at_x(0)), (lambda p: p[0] <= w, at_x(w)),
                          (lambda p: p[1] >= 0, at_y(0)), (lambda p: p[1] <= h, at_y(h))):
        if not poly:
            break
        poly = run(poly, inside, cross)
    return poly


# ==========================================================================
# Cards
# ==========================================================================
class ChamferCard(tk.Canvas):
    """Dark panel with faint diagonal stripes and white slashes on two corners (the website's 'cut' card)."""

    def __init__(self, master, width: int = 0, height: int = 160, command=None, dashed: bool = False,
                 cut: int = 26, accent: str = theme.BRAND, **kw):
        super().__init__(master, width=width or 10, height=height, bg=theme.BG, highlightthickness=0, bd=0, **kw)
        self.cut, self.dashed, self.command, self.accent = cut, dashed, command, accent
        self.hover = self.selected = False
        self._size = (0, 0)
        self._job = None
        self.bind("<Configure>", self._on_configure)
        if command:
            self.configure(cursor="hand2")
            self.bind("<Enter>", lambda _e: self._set_hover(True))
            self.bind("<Leave>", lambda _e: self._set_hover(False))
            self.bind("<Button-1>", lambda _e: command())

    # ----- state ------------------------------------------------------------
    def _set_hover(self, on: bool) -> None:
        self.hover = on
        self.repaint()

    def set_selected(self, on: bool) -> None:
        if on != self.selected:
            self.selected = on
            self.repaint()

    def _on_configure(self, e) -> None:
        if (e.width, e.height) != self._size:
            self._size = (e.width, e.height)
            self.repaint()

    def repaint(self) -> None:
        if self._job is None:
            self._job = self.after_idle(self.paint)

    # ----- drawing (template method) -----------------------------------------
    def paint(self) -> None:
        self._job = None
        w, h = self.winfo_width(), self.winfo_height()
        if w < 8 or h < 8:
            return
        self.delete("all")
        self.paint_base(w, h)
        self.paint_content(w, h)
        self.paint_corners(w, h)

    def paint_content(self, w: int, h: int) -> None:
        """Subclasses draw their text and pictures here."""

    def paint_base(self, w: int, h: int) -> None:
        c = self.cut
        poly = [c, 0, w, 0, w, h - c, w - c, h, 0, h, 0, c]
        self.create_polygon(poly, fill=theme.PANEL, outline="")
        band, period = 38 * 1.4142, 76 * 1.4142                  # 135deg stripes, 38px on / 38px off
        k = 0.0
        while k < w + h:
            y0, y1 = -10, h + 10
            quad = [(k - y0, y0), (k + band - y0, y0), (k + band - y1, y1), (k - y1, y1)]
            pts = _clip(quad, w, h)
            if len(pts) >= 3:
                self.create_polygon([v for p in pts for v in p], fill=theme.STRIPE, outline="")
            k += period

    def paint_corners(self, w: int, h: int) -> None:
        c = self.cut
        for tri in ([0, 0, c, 0, 0, c], [w, h, w - c, h, w, h - c]):     # cut the two corners away
            self.create_polygon(tri, fill=self["bg"], outline="")
        if self.selected:
            edge = theme.BRAND
        elif self.dashed:
            edge = theme.LINE
        else:
            edge = self.accent if self.hover else theme.EDGE
        poly = [c, 0, w - 1, 0, w - 1, h - c, w - c, h - 1, 0, h - 1, 0, c]
        self.create_polygon(poly, fill="", outline=edge, width=2 if self.selected else 1,
                            dash=(4, 3) if self.dashed else ())
        slash = "#8a929b" if self.dashed else "#ffffff"
        self.create_line(0, c, c, 0, fill=slash, width=3)
        self.create_line(w, h - c, w - c, h, fill=slash, width=3)

    # ----- helper shared by subclasses --------------------------------------
    def tag_chip(self, x: int, y: int, text: str, fnt) -> int:
        """Small bordered capital label (the website's '.tag'); returns its width."""
        text = text.upper()
        f = font_of(fnt)
        tw = f.measure(text) + 20
        self.create_rectangle(x, y, x + tw, y + 24, fill=theme.PANEL2, outline=theme.LINE)
        self.create_text(x + tw / 2, y + 12, text=text, fill=theme.MUTE, font=fnt)
        return tw

    def fit_font(self, text: str, max_width: int, start: int, minimum: int = 14) -> tuple:
        """Biggest display font (up to `start` pt) whose text still fits; fonts differ between computers."""
        size = start
        while size > minimum and font_of(theme.display(size)).measure(text) > max_width:
            size -= 1
        return theme.display(size)


class GameCard(ChamferCard):
    """Big 'Pick a game' card: coloured title, blurb and tag chips along the bottom."""

    def __init__(self, master, title, blurb, tags, accent, decor=None, command=None, dashed=False, height=300):
        super().__init__(master, height=height, command=command, dashed=dashed, accent=accent)
        self.title, self.blurb, self.tags, self.decor = title, blurb, tags, decor

    def paint_content(self, w, h):
        pad, tag_font = 26, theme.display(10)
        if self.decor == "uma":
            self.create_oval(w - 215, -40, w + 25, 200, fill=theme.blend(self.accent, theme.PANEL, .20), outline="")
            for cx, cy, r in ((w - 115, 85, 45), (w - 160, 140, 45)):
                self.create_oval(cx - r, cy - r, cx + r, cy + r, outline=theme.blend(self.accent, theme.PANEL, .55), width=2)
        elif self.decor == "apex":
            self.create_polygon(hex_points(w - 150, 120, 105), fill=theme.blend(self.accent, theme.PANEL, .22), outline="")
            self.create_polygon(hex_points(w - 65, 105, 42), fill=theme.blend(self.accent, theme.PANEL, .30),
                                outline=theme.blend(self.accent, theme.PANEL, .6))
        if self.dashed:
            title = self.title.upper()
            self.create_text(w / 2, h / 2 - 14, text=title, fill=theme.LINE,
                             font=self.fit_font(title, w - 2 * pad, 34))
            self.create_text(w / 2, h / 2 + 24, text=self.blurb, fill=theme.LINE, font=theme.body(11))
            return
        f = font_of(tag_font)
        rows, cur, x = [], [], 0
        for t in self.tags:                                       # wrap the tag chips into rows
            tw = f.measure(t.upper()) + 20
            if cur and x + tw > w - 2 * pad:
                rows.append(cur)
                cur, x = [], 0
            cur.append((t, tw))
            x += tw + 8
        rows.append(cur)
        y = h - pad - 24 * len(rows) - 6 * (len(rows) - 1)
        for row in rows:
            x = pad
            for t, _ in row:
                x += self.tag_chip(x, y, t, tag_font) + 8
            y += 30
        top = h - pad - 30 * len(rows) - 8
        blurb = self.create_text(pad, top, text=self.blurb, anchor="sw", fill=theme.MUTE,
                                 font=theme.body(11), width=w - 2 * pad)
        y0 = self.bbox(blurb)[1] - 8
        title = self.title.upper()
        self.create_text(pad, y0, text=title, anchor="sw", fill=self.accent,
                         font=self.fit_font(title, w - 2 * pad - 10, 34))


class ToolCard(ChamferCard):
    """Hub card: title in the game colour, one-line description and an OPEN chip."""

    def __init__(self, master, title, blurb, accent, command, height=170):
        super().__init__(master, height=height, command=command, accent=accent)
        self.title, self.blurb = title, blurb

    def paint_content(self, w, h):
        pad = 24
        t = self.create_text(pad, 20, text=self.title.upper(), anchor="nw", fill=self.accent, font=theme.display(20))
        self.create_text(pad, self.bbox(t)[3] + 6, text=self.blurb, anchor="nw", fill=theme.MUTE,
                         font=theme.body(11), width=w - 2 * pad - 10)
        self.tag_chip(pad, h - 40, "OPEN", theme.display(10))


class LegendCard(ChamferCard):
    """Legend portrait on a hexagon, name and class (the website's Apex character grid)."""

    def __init__(self, master, name, cls_name, command=None, width=176, height=158):
        super().__init__(master, width=width, height=height, command=command, cut=22)
        self.name, self.cls_name = name, cls_name
        self.img = ImageStore.instance().legend(name)

    def paint_content(self, w, h):
        cx, cy = w / 2, 62
        self.create_polygon(hex_points(cx, cy, 46), fill=theme.HEX_BG, outline="")
        if self.img:
            self.create_image(cx, cy, image=self.img)
        else:                                                        # placeholder until the PNG exists
            self.create_text(cx, cy, text=self.name[:1].upper(), fill=theme.MUTE, font=theme.display(30))
        self.create_text(cx, h - 38, text=self.name.upper(), fill=theme.FG, font=theme.display(14), width=w - 14)
        self.create_text(cx, h - 18, text=self.cls_name, fill=theme.MUTE, font=theme.body(9))


class WeaponCard(ChamferCard):
    def __init__(self, master, name, sub, command=None, width=208, height=124):
        super().__init__(master, width=width, height=height, command=command, cut=22)
        self.name, self.sub = name, sub
        self.img = ImageStore.instance().weapon(name, 170)

    def paint_content(self, w, h):
        if self.img:
            self.create_image(w / 2, 46, image=self.img)
        else:
            self.create_text(w / 2, 46, text="NO ICON", fill=theme.LINE, font=theme.display(14))
        self.create_text(w / 2, h - 34, text=self.name.upper(), fill=theme.FG, font=theme.display(13), width=w - 16)
        self.create_text(w / 2, h - 15, text=self.sub, fill=theme.MUTE, font=theme.body(9))


class MapCard(ChamferCard):
    def __init__(self, master, name, sub, command=None, width=320, height=226):
        super().__init__(master, width=width, height=height, command=command, cut=24)
        self.name, self.sub = name, sub
        self.img = ImageStore.instance().map(name)

    def paint_content(self, w, h):
        if self.img:
            self.create_image(0, 0, image=self.img, anchor="nw")
        else:
            self.create_text(w / 2, 90, text="MAP IMAGE", fill=theme.LINE, font=theme.display(16))
        self.create_rectangle(0, 180, w, h, fill=theme.PANEL2, outline="")
        self.create_text(14, 190, text=self.name.upper(), anchor="nw", fill=theme.FG, font=theme.display(15))
        self.create_text(w - 14, 193, text=self.sub, anchor="ne", fill=theme.MUTE, font=theme.body(9))


# ==========================================================================
# Small controls
# ==========================================================================
class Chip(tk.Canvas):
    """Tier-list name tag: 'Special Week  7.7'."""

    def __init__(self, master, text: str, sub: str = "", command=None, bg=theme.PANEL):
        f, small = font_of(theme.body(10, "bold")), font_of(theme.body(8))
        w = f.measure(text) + (small.measure(sub) + 8 if sub else 0) + 22
        super().__init__(master, width=w, height=28, bg=bg, highlightthickness=0, bd=0)
        self._rect = self.create_rectangle(0, 0, w - 1, 27, fill=theme.PANEL2, outline=theme.LINE)
        self.create_text(11, 14, text=text, anchor="w", fill=theme.FG, font=theme.body(10, "bold"))
        if sub:
            self.create_text(11 + f.measure(text) + 8, 15, text=sub, anchor="w", fill=theme.MUTE, font=theme.body(8))
        self.selected = False
        if command:
            self.configure(cursor="hand2")
            self.bind("<Button-1>", lambda _e: command())
            self.bind("<Enter>", lambda _e: self.itemconfigure(self._rect, outline=theme.BRAND))
            self.bind("<Leave>", lambda _e: self.itemconfigure(self._rect, outline=theme.BRAND if self.selected else theme.LINE))

    def set_selected(self, on: bool) -> None:
        self.selected = on
        self.itemconfigure(self._rect, outline=theme.BRAND if on else theme.LINE,
                           fill="#1f5f58" if on else theme.PANEL2)


class PillTabs(tk.Frame):
    """Row of square tabs: the active one is filled with the game colour."""

    def __init__(self, master, items: list[tuple[str, str]], command, accent=theme.BRAND, active: str | None = None,
                 bg=theme.BG):
        super().__init__(master, bg=bg)
        self.command, self.accent, self.labels, self.active = command, accent, {}, None
        for key, text in items:
            lab = tk.Label(self, text=text.upper(), font=theme.display(12), padx=16, pady=6, bg=theme.PANEL,
                           fg=theme.MUTE, highlightthickness=1, highlightbackground=theme.LINE, cursor="hand2")
            lab.pack(side="left", padx=(0, 6))
            lab.bind("<Button-1>", lambda _e, k=key: self.select(k, True))
            lab.bind("<Enter>", lambda _e, k=key: self.labels[k].configure(fg=theme.FG) if k != self.active else None)
            lab.bind("<Leave>", lambda _e, k=key: self.labels[k].configure(fg=theme.MUTE) if k != self.active else None)
            self.labels[key] = lab
        if active:
            self.select(active)

    def select(self, key: str, notify: bool = False) -> None:
        self.active = key
        for k, lab in self.labels.items():
            on = k == key
            lab.configure(bg=self.accent if on else theme.PANEL, fg=text_on(self.accent) if on else theme.MUTE,
                          highlightbackground=self.accent if on else theme.LINE)
        if notify:
            self.command(key)


class Breadcrumb(tk.Frame):
    """Home / Umamusume / Characters  (earlier parts are clickable)."""

    def __init__(self, master, go):
        super().__init__(master, bg=theme.BG)
        self.go = go

    def set(self, parts: list[tuple[str, str | None]]) -> None:
        for w in self.winfo_children():
            w.destroy()
        for i, (text, route) in enumerate(parts):
            last = i == len(parts) - 1
            lab = tk.Label(self, text=text, bg=theme.BG, fg=theme.FG if last else theme.MUTE, font=theme.body(10),
                           cursor="" if last or not route else "hand2")
            lab.pack(side="left")
            if route and not last:
                lab.bind("<Button-1>", lambda _e, r=route: self.go(r))
                lab.bind("<Enter>", lambda _e, w=lab: w.configure(fg=theme.FG))
                lab.bind("<Leave>", lambda _e, w=lab: w.configure(fg=theme.MUTE))
            if not last:
                tk.Label(self, text="  /  ", bg=theme.BG, fg=theme.LINE, font=theme.body(10)).pack(side="left")


class BorderBox(tk.Frame):
    """Clickable outlined box (the header's History and account buttons)."""

    def __init__(self, master, command=None, pad=(8, 5)):
        super().__init__(master, bg=theme.BG, highlightthickness=1, highlightbackground=theme.LINE,
                         padx=pad[0], pady=pad[1], cursor="hand2" if command else "")
        self.command = command
        self.bind("<Enter>", lambda _e: self.configure(highlightbackground=theme.BRAND))
        self.bind("<Leave>", lambda _e: self.configure(highlightbackground=theme.LINE))
        self.bind("<Button-1>", self._click)

    def _click(self, _e=None):
        if self.command:
            self.command()

    def adopt(self, *widgets) -> None:
        """Make child widgets pass their clicks and hover to the box."""
        for w in widgets:
            w.bind("<Button-1>", self._click)
            w.bind("<Enter>", lambda _e: self.configure(highlightbackground=theme.BRAND))
            w.bind("<Leave>", lambda _e: self.configure(highlightbackground=theme.LINE))
            w.configure(cursor="hand2")


# ==========================================================================
# Layout helpers
# ==========================================================================
class FlowFrame(tk.Frame):
    """Wraps its children into rows like CSS flex-wrap. Children need a fixed requested size (Chip, cards)."""

    def __init__(self, master, gap: int = 8, bg=theme.BG):
        super().__init__(master, bg=bg, height=1)
        self.gap, self.kids, self._last_w, self._job = gap, [], 0, None
        self.bind("<Configure>", self._on_configure)

    def add(self, widget) -> None:
        self.kids.append(widget)
        self.reflow_later()

    def clear(self) -> None:
        for k in self.kids:
            k.destroy()
        self.kids = []
        self.configure(height=1)

    def _on_configure(self, e) -> None:
        if e.width != self._last_w:
            self._last_w = e.width
            self.reflow_later()

    def reflow_later(self) -> None:
        if self._job is None:
            self._job = self.after_idle(self.reflow)

    def reflow(self) -> None:
        self._job = None
        w = self.winfo_width()
        if w <= 1:
            return
        x = y = row_h = 0
        for k in self.kids:
            kw, kh = k.winfo_reqwidth(), k.winfo_reqheight()
            if x and x + kw > w:
                x, y, row_h = 0, y + row_h + self.gap, 0
            k.place(x=x, y=y)
            x += kw + self.gap
            row_h = max(row_h, kh)
        self.configure(height=max(1, y + row_h))


def scroll_target(widget):
    """Find the scrollable ancestor (VScroll / ScrollFrame) of a widget, if any."""
    while widget is not None:
        canvas = getattr(widget, "scroll_canvas", None)
        if canvas is not None:
            return canvas
        widget = getattr(widget, "master", None)
    return None


def install_mouse_wheel(root: tk.Misc) -> None:
    """One global handler: the wheel scrolls whichever scrollable panel is under the pointer."""
    def on_wheel(e):
        try:
            under = root.winfo_containing(e.x_root, e.y_root)
        except (KeyError, tk.TclError):
            return
        if under is None or under.winfo_class() in ("Treeview", "Listbox", "Text", "TCombobox"):
            return
        canvas = scroll_target(under)
        if canvas is None:
            return
        step = -1 if (getattr(e, "num", 0) == 4 or getattr(e, "delta", 0) > 0) else 1
        canvas.yview_scroll(step * 2, "units")

    for ev in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
        root.bind_all(ev, on_wheel, add="+")


class VScroll(tk.Frame):
    """Vertical scroll area. Put content into .body."""

    def __init__(self, master, bg=theme.BG):
        super().__init__(master, bg=bg)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        sb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.body = tk.Frame(self.canvas, bg=bg)
        self._win = self.canvas.create_window((0, 0), window=self.body, anchor="nw")
        self.body.bind("<Configure>", lambda _e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self._win, width=e.width))
        self.scroll_canvas = self.canvas

    def clear(self) -> None:
        for w in self.body.winfo_children():
            w.destroy()
        self.canvas.yview_moveto(0)


# ==========================================================================
# Boards (what the CrudViews show instead of a table)
# ==========================================================================
class TierBoard(VScroll):
    """S / A / B / C / D rows with a coloured letter block and a chip per item."""

    def __init__(self, master):
        super().__init__(master)
        self.chips: dict[int, Chip] = {}
        self._selected: int | None = None

    def set_data(self, groups: dict[str, list], name, sub, on_pick) -> None:
        self.clear()
        self.chips, self._selected = {}, None
        for tier, items in groups.items():
            row = tk.Frame(self.body, bg=theme.PANEL, highlightthickness=1, highlightbackground=theme.LINE)
            row.pack(fill="x", pady=(0, 8))
            color = theme.TIER_COLORS.get(tier, theme.BRAND)
            tk.Label(row, text=tier, bg=color, fg="#161616", font=theme.display(28), width=3).pack(side="left", fill="y")
            flow = FlowFrame(row, gap=6, bg=theme.PANEL)
            flow.pack(side="left", fill="x", expand=True, padx=10, pady=10)
            if not items:
                tk.Label(flow, text="Nothing here", bg=theme.PANEL, fg=theme.MUTE).place(x=0, y=0)
                flow.configure(height=28)
            for item in items:
                chip = Chip(flow, name(item), sub(item), command=lambda i=item: on_pick(i))
                flow.add(chip)
                self.chips[item.id] = chip

    def select(self, item_id: int | None) -> None:
        if self._selected in self.chips:
            self.chips[self._selected].set_selected(False)
        self._selected = item_id
        if item_id in self.chips:
            self.chips[item_id].set_selected(True)


class GroupedBoard(VScroll):
    """Groups with a coloured heading, a count badge and a wrapping grid of cards (collapsible)."""

    def __init__(self, master):
        super().__init__(master)
        self.cards: dict[int, ChamferCard] = {}
        self._selected: int | None = None

    def reset(self) -> None:
        self.clear()
        self.cards, self._selected = {}, None

    def add_group(self, title: str, color: str, count: int) -> FlowFrame:
        head = tk.Frame(self.body, bg=theme.BG)
        head.pack(fill="x", pady=(10, 8))
        flow = FlowFrame(self.body, gap=10)
        arrow = tk.Label(head, text="\u25BE", bg=theme.BG, fg=theme.MUTE, font=theme.body(9), cursor="hand2")
        arrow.pack(side="left", padx=(2, 8))
        tk.Label(head, text=title.upper(), bg=theme.BG, fg=color, font=theme.display(17)).pack(side="left")
        tk.Label(head, text=str(count), bg=theme.BG, fg=theme.MUTE, font=theme.body(9), padx=8,
                 highlightthickness=1, highlightbackground=theme.LINE).pack(side="right")
        tk.Frame(head, bg=theme.LINE, height=1).pack(side="left", fill="x", expand=True, padx=12)
        flow.pack(fill="x")

        def toggle(_e=None):
            if flow.winfo_manager():
                flow.pack_forget()
                arrow.configure(text="\u25B8")
            else:
                flow.pack(fill="x")
                arrow.configure(text="\u25BE")
        arrow.bind("<Button-1>", toggle)
        return flow

    def add_flat(self) -> FlowFrame:
        """A grid of cards without a heading (used for the maps)."""
        flow = FlowFrame(self.body, gap=12)
        flow.pack(fill="x", pady=(10, 0))
        return flow

    def select(self, item_id: int | None) -> None:
        if self._selected in self.cards:
            self.cards[self._selected].set_selected(False)
        self._selected = item_id
        if item_id in self.cards:
            self.cards[item_id].set_selected(True)
