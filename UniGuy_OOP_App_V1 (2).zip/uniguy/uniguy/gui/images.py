"""Loads the game art (legend portraits, weapon icons, map photos) from the assets/ folder.

Files are found by name:  assets/legends/bangalore.png, assets/weapons/r_99.png, assets/maps/olympus.png ...
If a file is missing the method returns None and the card draws a placeholder, so you can drop in
your own originals later (same file name) without touching any code.
If Pillow is installed, images of any size are shrunk to fit; without Pillow, Tk shows them as they are.
"""
from __future__ import annotations

import re
import tkinter as tk
from pathlib import Path

try:                                    # optional: only used to resize your own originals
    from PIL import Image, ImageTk
except ImportError:                     # pragma: no cover
    Image = ImageTk = None

ASSETS = Path(__file__).resolve().parent.parent / "assets"


def slug(name: str) -> str:
    """'Mad Maggie' -> 'mad_maggie',  "World's Edge" -> 'worlds_edge',  'C.A.R.' -> 'c_a_r'"""
    name = re.sub(r"[\u2019']", "", name.lower())
    return re.sub(r"[^a-z0-9]+", "_", name).strip("_")


class ImageStore:
    """Singleton cache so every card shares one PhotoImage per file (Tk drops unreferenced images)."""

    _instance: "ImageStore | None" = None

    @classmethod
    def instance(cls) -> "ImageStore":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._cache: dict[tuple, tk.PhotoImage | None] = {}
        self._root = None

    def _load(self, folder: str, name: str, max_size: tuple | None):
        key = (folder, slug(name), max_size)
        if tk._default_root is not self._root:      # a new window (e.g. after the tests close one): old pictures are void
            self._cache.clear()
            self._root = tk._default_root
        if key not in self._cache:
            path = ASSETS / folder / f"{slug(name)}.png"
            img = None
            if path.exists():
                try:
                    if Image is not None and max_size:
                        pil = Image.open(path).convert("RGBA")
                        pil.thumbnail(max_size)
                        img = ImageTk.PhotoImage(pil)
                    else:
                        img = tk.PhotoImage(file=str(path))
                except Exception:       # damaged file: behave as if it was missing
                    img = None
            self._cache[key] = img
        return self._cache[key]

    def legend(self, name: str, size: int = 76):
        return self._load("legends", name, (size, size))

    def legend_art(self, name: str):
        return self._load("legend_art", name, (300, 170))

    def weapon(self, name: str, width: int = 230):
        return self._load("weapons", name, (width, 76))

    def map(self, name: str):
        return self._load("maps", name, (320, 180))
