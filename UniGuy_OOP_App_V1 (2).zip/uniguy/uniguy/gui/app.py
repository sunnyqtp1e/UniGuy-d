"""Main window, laid out like the UniGuy website.

Header (History drop-down, UNIGUY'D logo, account chip) + one page at a time with a breadcrumb,
a big capital title and tabs. Pages are chosen by a route name such as "uma-chars" or "apex-guns",
just like the website's #uma-chars links.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

from ..auth import Account, AccountStore, AuthError
from ..database import Database
from ..models import User, ValidationError
from ..repositories import (CardRepository, DeckRepository, GachaPlanRepository, HorseRepository,
                            LegendRepository, MapRepository, RepositoryError, SkillRepository,
                            UserRepository, VisitLogRepository, WeaponRepository)
from . import theme
from .apex_views import LegendView, MapView, WeaponBuilderView, WeaponView
from .base import PageHeader, ScrollFrame, make_tree
from .login import LoginScreen
from .uma_views import CardView, DeckBuilderView, GachaView, HorseView, SkillView
from .widgets import (Breadcrumb, BorderBox, GameCard, PillTabs, ToolCard, hex_points,
                      install_mouse_wheel)

from ..auth import COLORS as PROFILE_COLORS

UMA_TABS = [("uma-chars", "Characters"), ("uma-support", "Support cards"), ("uma-skills", "Skills"),
            ("uma-deck", "Deck builder"), ("uma-gacha", "Gacha")]
APEX_TABS = [("apex-chars", "Legends"), ("apex-guns", "Weapons"), ("apex-builder", "Weapon builder"),
             ("apex-maps", "Maps")]
# route -> text saved in the visit history (same format as before: "Game > Page")
LABELS = {"home": "Home", "uma": "Umamusume > Hub", "uma-chars": "Umamusume > Characters",
          "uma-support": "Umamusume > Support cards", "uma-skills": "Umamusume > Skills",
          "uma-deck": "Umamusume > Deck builder", "uma-gacha": "Umamusume > Gacha calculator",
          "apex-chars": "Apex > Legends", "apex-guns": "Apex > Weapons", "apex-builder": "Apex > Weapon builder",
          "apex-maps": "Apex > Maps", "profile": "Profile"}
ALIASES = {"apex": "apex-chars"}
# pages that fit a narrow window. The others (deck builder, gacha, account) need the full window.
COMPACT_ROUTES = {"home", "uma", "uma-chars", "uma-support", "uma-skills", "apex-chars", "apex-guns",
                  "apex-builder", "apex-maps"}
COMPACT_SIZE = (600, 780)
FULL_MIN = (1100, 720)


def dot_color(label: str) -> str:
    return theme.UMA if label.startswith("Uma") else theme.APEX if label.startswith("Apex") else theme.BRAND


# ==========================================================================
# Pages
# ==========================================================================
class HomeView(tk.Frame):
    """'Pick a game' screen: three big cards and a row of totals."""
    TITLE = "Pick a game"
    SUBTITLE = "Tier lists, builders and calculators for the games you play. More games will be added here."
    EYEBROW = "Game guides in one place"
    ACCENT = theme.BRAND

    def __init__(self, master, app):
        super().__init__(master, bg=theme.BG)
        self.app = app
        for c in range(3):
            self.columnconfigure(c, weight=1, uniform="game")
        self.cards = tk.Frame(self, bg=theme.BG)
        self.cards.grid(row=0, column=0, columnspan=3, sticky="ew")
        for c in range(3):
            self.cards.columnconfigure(c, weight=1, uniform="game")
        self.uma = GameCard(self.cards, "Umamusume", "Plan your roster, decks and pulls for Pretty Derby.",
                            ["Characters", "Support cards", "Skills", "Deck builder", "Gacha"], theme.UMA,
                            decor="uma", command=lambda: app.show("uma"))
        self.apex = GameCard(self.cards, "Apex Legends", "Legend upgrade picks, weapon attachments and map picks.",
                             ["0 Legends", "Weapon menu", "0 Maps"], theme.APEX, decor="apex",
                             command=lambda: app.show("apex"))
        self.nxt = GameCard(self.cards, "Next game", "Placeholder slot for the next guide.", [], theme.MUTE,
                            dashed=True)
        self.game_cards = (self.uma, self.apex, self.nxt)
        for i, card in enumerate(self.game_cards):
            card.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 10, 0 if i == 2 else 10))
        tk.Label(self, text="IN THE DATABASE", bg=theme.BG, fg=theme.MUTE, font=theme.display(11)).grid(
            row=1, column=0, columnspan=3, sticky="w", pady=(26, 6))
        self.tiles = tk.Frame(self, bg=theme.BG)
        self.tiles.grid(row=2, column=0, columnspan=3, sticky="ew")
        self.tile_labels, self.tile_boxes = {}, []
        names = ["Characters", "Support cards", "Skills", "Legends", "Weapons", "Maps", "My decks", "My plans"]
        for i, n in enumerate(names):
            self.tiles.columnconfigure(i, weight=1, uniform="tile")
            box = tk.Frame(self.tiles, bg=theme.PANEL, highlightthickness=1, highlightbackground=theme.LINE, padx=12, pady=8)
            box.grid(row=0, column=i, sticky="ew", padx=(0, 8 if i < len(names) - 1 else 0))
            lab = tk.Label(box, text="0", bg=theme.PANEL, fg=theme.BRAND if i < 6 else theme.GOLD, font=theme.display(22))
            lab.pack(anchor="w")
            tk.Label(box, text=n.upper(), bg=theme.PANEL, fg=theme.MUTE, font=theme.display(9)).pack(anchor="w")
            self.tile_labels[n] = lab
            self.tile_boxes.append(box)
        self.refresh()

    def set_compact(self, on: bool):
        """Narrow window: game cards stacked, totals in two rows."""
        for i, card in enumerate(self.game_cards):
            if on:
                card.grid_configure(row=i, column=0, padx=0, pady=(0, 8))
                card.configure(height=(190, 190, 90)[i])
            else:
                card.grid_configure(row=0, column=i, padx=(0 if i == 0 else 10, 0 if i == 2 else 10), pady=0)
                card.configure(height=300)
        self.cards.columnconfigure(0, weight=1, uniform="game")
        for c in (1, 2):
            self.cards.columnconfigure(c, weight=0 if on else 1, uniform="" if on else "game")
        for i, box in enumerate(self.tile_boxes):
            if on:
                box.grid_configure(row=i // 4, column=i % 4, pady=(0, 8))
            else:
                box.grid_configure(row=0, column=i, pady=0)
        for c in range(8):
            self.tiles.columnconfigure(c, weight=1 if (c < 4 or not on) else 0, uniform="tile" if (c < 4 or not on) else "")

    def refresh(self):
        a = self.app
        counts = {"Characters": HorseRepository().count(), "Support cards": CardRepository().count(),
                  "Skills": SkillRepository().count(), "Legends": LegendRepository().count(),
                  "Weapons": WeaponRepository().count(), "Maps": MapRepository().count(),
                  "My decks": len(DeckRepository().for_user(a.user.id)),
                  "My plans": len(GachaPlanRepository().for_user(a.user.id))}
        for k, v in counts.items():
            self.tile_labels[k].configure(text=str(v))
        self.apex.tags = [f"{counts['Legends']} Legends", "Weapon menu", f"{counts['Maps']} Maps"]
        self.apex.repaint()

    on_data_changed = refresh
    reload_user = refresh


class GameHub(tk.Frame):
    """A grid of ToolCards that open the game's tools. Subclasses only list the tools."""
    TITLE, SUBTITLE, EYEBROW, ACCENT = "", "", "", theme.BRAND
    TOOLS: list[tuple] = []          # (title, description, route)

    def __init__(self, master, app):
        super().__init__(master, bg=theme.BG)
        for c in range(3):
            self.columnconfigure(c, weight=1, uniform="tool")
        self.cards = []
        for i, (title, blurb, route) in enumerate(self.TOOLS):
            card = ToolCard(self, title, blurb, self.ACCENT, lambda r=route: app.show(r))
            card.grid(row=i // 3, column=i % 3, sticky="ew", padx=(0, 10), pady=(0, 10))
            self.cards.append(card)

    def set_compact(self, on: bool):
        for i, card in enumerate(self.cards):
            if on:
                card.grid_configure(row=i, column=0, padx=0)
                card.configure(height=130)
            else:
                card.grid_configure(row=i // 3, column=i % 3, padx=(0, 10))
                card.configure(height=170)
        for c in (1, 2):
            self.columnconfigure(c, weight=0 if on else 1, uniform="" if on else "tool")


class UmaHub(GameHub):
    TITLE = "Umamusume tools"
    SUBTITLE = "Five tools. Tier data is sample data you can edit in the app."
    EYEBROW = "Pretty Derby"
    ACCENT = theme.UMA
    TOOLS = [("Characters", "Universal tier list and track aptitudes for every horse girl.", "uma-chars"),
             ("Support cards", "Support card tier list with type filters.", "uma-support"),
             ("Skills directory", "Search skills and browse by category with tiers.", "uma-skills"),
             ("Deck builder", "Build a six card deck and see skills, stats and compatibility.", "uma-deck"),
             ("Gacha economy", "Pull rates, income simulator and your chance at the horse.", "uma-gacha")]


class ProfileView(ttk.Frame):
    TITLE = "Account & data"
    SUBTITLE = "Everything here belongs to your account only. Other accounts cannot see it or change it."
    EYEBROW = "Account"
    ACCENT = theme.BRAND

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        scroller = ScrollFrame(self, panel=False, width=400)
        scroller.grid(row=0, column=0, sticky="ns", padx=(0, 14))
        body = scroller.body

        def box(title):
            f = ttk.Frame(body, style="Panel.TFrame", padding=14)
            f.pack(fill="x", pady=(0, 12))
            f.columnconfigure(0, weight=1)
            ttk.Label(f, text=title, style="H2.TLabel", background=theme.PANEL).grid(sticky="w", pady=(0, 6))
            return f

        def mute(parent, text):
            return ttk.Label(parent, text=text, style="PanelMute.TLabel", wraplength=330, justify="left")

        # --- account
        acc = box("Account")
        self.who = ttk.Label(acc, text="", style="Big.TLabel")
        self.who.grid(sticky="w")
        mute(acc, "Colour").grid(sticky="w", pady=(8, 0))
        self.color_var = tk.StringVar()
        ttk.Combobox(acc, textvariable=self.color_var, values=PROFILE_COLORS, state="readonly").grid(sticky="ew", pady=(2, 8))
        ttk.Button(acc, text="Save colour", command=self.save_color).grid(sticky="w")

        # --- password
        pw = box("Change password")
        self.old_var, self.new_var, self.new2_var = tk.StringVar(), tk.StringVar(), tk.StringVar()
        for label, var in (("Current password", self.old_var), ("New password", self.new_var),
                           ("Repeat new password", self.new2_var)):
            mute(pw, label).grid(sticky="w")
            ttk.Entry(pw, textvariable=var, show="\u2022").grid(sticky="ew", pady=(2, 8))
        ttk.Button(pw, text="Change password", command=self.change_password).grid(sticky="w")

        # --- history (top right) and delete options (bottom right, so they are visible without scrolling)
        right = ttk.Frame(self)
        right.grid(row=0, column=1, sticky="nsew")
        right.rowconfigure(1, weight=1)
        right.columnconfigure(0, weight=1)
        ttk.Label(right, text="Visit history", style="H2.TLabel").grid(sticky="w")
        self.tree = make_tree(right, [("page", "Page", 380, "w"), ("when", "When", 170, "w")], height=7)
        self.tree.container.grid(row=1, sticky="nsew", pady=6)

        data = ttk.Frame(right, style="Panel.TFrame", padding=14)
        data.grid(row=2, sticky="ew", pady=(8, 0))
        data.columnconfigure((0, 1), weight=1, uniform="del")
        ttk.Label(data, text="Delete data", style="H2.TLabel", background=theme.PANEL).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 4))
        actions = (
            ("Delete saved decks", "Removes every deck you saved in the deck builder.", self.delete_decks),
            ("Delete gacha plans", "Removes every plan you saved in the gacha calculator.", self.delete_plans),
            ("Clear visit history", "Empties the list above and the History menu.", self.clear),
            ("Reset everything to defaults", "Restores the guide data (tier lists, legends, weapons, maps) and removes "
             "your decks, plans and history. Your account stays.", self.reset_all),
            ("Delete my account", "Permanently removes this account and everything stored under it.", self.delete_account))
        for i, (text, hint, cmd) in enumerate(actions):
            cell = ttk.Frame(data, style="Panel.TFrame")
            cell.grid(row=1 + i // 2, column=i % 2, sticky="nsew", padx=(0, 10 if i % 2 == 0 else 0), pady=(8, 0))
            cell.columnconfigure(0, weight=1)
            ttk.Button(cell, text=text, style="Danger.TButton", command=cmd).grid(sticky="ew")
            ttk.Label(cell, text=hint, style="PanelMute.TLabel", wraplength=330, justify="left").grid(sticky="w", pady=(3, 0))
        self.msg = ttk.Label(data, text="", style="Warn.TLabel", background=theme.PANEL)
        self.msg.grid(row=4, column=0, columnspan=2, sticky="w", pady=(10, 0))
        self.reload_user()

    def reload_user(self):
        u = self.app.user
        self.who.configure(text=self.app.account.username)
        self.color_var.set(u.color)
        self.tree.delete(*self.tree.get_children())
        for page, when in self.app.history.recent(u.id, 200):
            self.tree.insert("", "end", values=(page, when))

    def on_data_changed(self):
        self.reload_user()

    def save_color(self):
        u = self.app.user
        u.color = self.color_var.get() or u.color
        self.app.users.update(u)
        self.app.store.set_color(self.app.account.username, u.color)
        self.app.paint_user()
        self.msg.configure(text="Colour saved.")

    def change_password(self):
        if self.new_var.get() != self.new2_var.get():
            messagebox.showwarning("Change password", "The two new passwords do not match.", parent=self)
            return
        try:
            self.app.store.change_password(self.app.account.username, self.old_var.get(), self.new_var.get())
        except AuthError as e:
            messagebox.showwarning("Change password", str(e), parent=self)
            return
        for v in (self.old_var, self.new_var, self.new2_var):
            v.set("")
        self.msg.configure(text="Password changed.")

    def delete_decks(self):
        self._delete_all("decks", DeckRepository(), "deck")

    def delete_plans(self):
        self._delete_all("gacha plans", GachaPlanRepository(), "plan")

    def _delete_all(self, label: str, repo, word: str):
        uid = self.app.user.id
        n = len(repo.for_user(uid))
        if n == 0:
            self.msg.configure(text=f"You have no saved {label}.")
            return
        if not messagebox.askyesno("Delete", f"Delete all {n} of your saved {label}? This cannot be undone.", parent=self):
            return
        repo.delete_for_user(uid)
        self.app.notify_data_changed()
        self.msg.configure(text=f"Deleted {n} {word}{'s' if n != 1 else ''}.")

    def clear(self):
        if not messagebox.askyesno("Clear history", "Clear your visit history?", parent=self):
            return
        self.app.history.clear(self.app.user.id)
        self.reload_user()
        self.msg.configure(text="History cleared.")

    def reset_all(self):
        if messagebox.askyesno("Reset everything", "Restore all guide data to the original values and delete your "
                               "decks, plans and history?\n\nYour account and password stay. This cannot be undone.",
                               icon="warning", parent=self):
            self.after(50, self.app.reset_data)           # let this click finish before the pages are rebuilt

    def delete_account(self):
        if not messagebox.askyesno("Delete account", "Permanently delete this account and all of its data?",
                                   icon="warning", parent=self):
            return
        pw = simpledialog.askstring("Delete account", "Type your password to confirm:", show="*", parent=self)
        if pw is None:
            return
        try:
            self.app.store.verify(self.app.account.username, pw)
        except AuthError:
            messagebox.showwarning("Delete account", "That password is not correct. Nothing was deleted.", parent=self)
            return
        self.after(50, self.app.remove_account)


class Page(tk.Frame):
    """One screen: breadcrumb, page heading, optional tabs, then the view itself."""

    def __init__(self, master, app, view_cls, route, crumbs, tabs=None):
        super().__init__(master, bg=theme.BG, padx=32, pady=14)
        self.route = route
        self._head: list[tuple] = []                 # (widget, pack options): hidden in compact mode
        if crumbs:
            crumb = Breadcrumb(self, app.show)
            crumb.pack(anchor="w", pady=(0, 10))
            crumb.set(crumbs)
            self._head.append((crumb, dict(anchor="w", pady=(0, 10))))
        header = PageHeader(self, view_cls.TITLE, view_cls.SUBTITLE, view_cls.EYEBROW, view_cls.ACCENT)
        header.pack(anchor="w", pady=(0, 14))
        self._head.append((header, dict(anchor="w", pady=(0, 14))))
        if tabs:
            self.tabs = PillTabs(self, tabs, app.show, accent=view_cls.ACCENT, active=route)
            self.tabs.pack(anchor="w", pady=(0, 14))
            self._head.append((self.tabs, dict(anchor="w", pady=(0, 14))))
        self.view = view_cls(self, app)
        self.view.pack(fill="both", expand=True)

    def set_compact(self, on: bool):
        """Narrow window: drop the breadcrumb, heading and tabs (the compact bar has the page menu)."""
        for widget, opts in self._head:
            if on:
                widget.pack_forget()
            else:
                widget.pack(before=self.view, **opts)
        self.configure(padx=10 if on else 32, pady=8 if on else 14)
        if hasattr(self.view, "set_compact"):
            self.view.set_compact(on)


class HistoryDrop(tk.Frame):
    """The History drop-down under the header's left button."""

    def __init__(self, app):
        super().__init__(app, bg=theme.PANEL, highlightthickness=1, highlightbackground=theme.LINE, padx=14, pady=12)
        self.app = app
        self.shown = False
        tk.Label(self, text="RECENT ACTIVITY", bg=theme.PANEL, fg=theme.MUTE, font=theme.display(11)).pack(anchor="w", pady=(0, 6))
        self.rows = tk.Frame(self, bg=theme.PANEL)
        self.rows.pack(fill="x")
        tk.Button(self, text="Clear history", command=self.clear, bg=theme.PANEL, fg=theme.MUTE, relief="flat",
                  highlightthickness=1, highlightbackground=theme.LINE, activebackground=theme.PANEL2,
                  activeforeground=theme.FG, font=theme.body(9), padx=10, pady=3).pack(anchor="w", pady=(10, 0))

    def toggle(self):
        self.hide() if self.shown else self.show()

    def show(self):
        self.refresh()
        self.place(x=16, y=self.app.header_h + 1, width=470)
        self.lift()
        self.shown = True

    def hide(self):
        self.place_forget()
        self.shown = False

    def refresh(self):
        for w in self.rows.winfo_children():
            w.destroy()
        items = self.app.history.recent(self.app.user.id, 10)
        if not items:
            tk.Label(self.rows, text="Nothing yet. Open a page and it shows up here.", bg=theme.PANEL, fg=theme.MUTE,
                     font=theme.body(10)).pack(anchor="w")
        for page, when in items:
            row = tk.Frame(self.rows, bg=theme.PANEL)
            row.pack(fill="x", pady=2)
            tk.Frame(row, bg=dot_color(page), width=8, height=8).pack(side="left", padx=(0, 10))
            tk.Label(row, text=page.upper(), bg=theme.PANEL, fg=theme.FG, font=theme.display(11)).pack(side="left")
            tk.Label(row, text=when[5:16], bg=theme.PANEL, fg=theme.MUTE, font=theme.body(9)).pack(side="right")

    def clear(self):
        self.app.history.clear(self.app.user.id)
        self.refresh()
        self.app.profile.reload_user()


class WindowDrop(tk.Frame):
    """The Window menu: always on top, opacity and compact mode (for playing with the guide open over a game)."""

    def __init__(self, app):
        super().__init__(app, bg=theme.PANEL, highlightthickness=1, highlightbackground=theme.LINE, padx=16, pady=14)
        self.app, self.shown = app, False
        tk.Label(self, text="WINDOW", bg=theme.PANEL, fg=theme.MUTE, font=theme.display(11)).pack(anchor="w", pady=(0, 8))
        tk.Checkbutton(self, text="Always on top", variable=app.pin_var, command=app.apply_window_settings,
                       bg=theme.PANEL, fg=theme.FG, selectcolor=theme.PANEL2, activebackground=theme.PANEL,
                       activeforeground=theme.FG, font=theme.body(11), highlightthickness=0, bd=0).pack(anchor="w")
        tk.Label(self, text="Opacity", bg=theme.PANEL, fg=theme.MUTE, font=theme.body(10)).pack(anchor="w", pady=(12, 0))
        row = tk.Frame(self, bg=theme.PANEL)
        row.pack(fill="x")
        ttk.Scale(row, from_=app.MIN_ALPHA, to=1.0, variable=app.alpha_var, command=lambda _v: app.apply_window_settings(),
                  length=220).pack(side="left")
        self.pct = tk.Label(row, text="100%", bg=theme.PANEL, fg=theme.FG, font=theme.body(10), width=5)
        self.pct.pack(side="left", padx=(8, 0))
        ttk.Button(self, text="Compact mode", style="Accent.TButton", command=lambda: app.set_compact(True)).pack(
            fill="x", pady=(14, 4))
        tk.Label(self, text="A small window for one page at a time. The deck builder, gacha calculator and "
                            "account page need the full window.", bg=theme.PANEL, fg=theme.MUTE, font=theme.body(9),
                 wraplength=290, justify="left").pack(anchor="w")

    def toggle(self):
        self.hide() if self.shown else self.show()

    def show(self):
        if self.app.history_drop:
            self.app.history_drop.hide()
        self.pct.configure(text=f"{round(self.app.alpha_var.get() * 100)}%")
        self.place(relx=1.0, x=-16, y=self.app.header_h + 1, anchor="ne")
        self.lift()
        self.shown = True

    def hide(self):
        self.place_forget()
        self.shown = False


class App(tk.Tk):
    """Window. Starts at the login screen; after signing in it opens that account's own database."""

    def __init__(self, store: AccountStore | None = None):
        super().__init__()
        self.title("UniGuy'd")
        self.geometry("1280x820")
        self.minsize(1100, 720)
        theme.apply_theme(self)
        install_mouse_wheel(self)
        self.store = store or AccountStore()
        self.pin_var = tk.BooleanVar(value=self.store.setting("pinned") == "1")
        self.alpha_var = tk.DoubleVar(value=float(self.store.setting("opacity", "1.0")))
        self.compact, self._full_geometry = False, ""
        self.account: Account | None = None
        self.user: User | None = None
        self.users = self.history = None
        self.views: list = []
        self.pages: dict[str, Page] = {}
        self.route = ""
        self.header_h = 64
        self.header = self.header_line = self.stage = self.history_drop = self.login_screen = None
        self.window_drop = self.compact_bar = self.win_btn = self.compact_title = None
        self.bind_all("<Button-1>", self._click_away, add="+")
        self.bind("<Escape>", lambda _e: [d.hide() for d in (self.history_drop, self.window_drop) if d])
        self.apply_window_settings()
        self.protocol("WM_DELETE_WINDOW", self._quit)
        self.show_login()

    # ----- sessions ------------------------------------------------------------
    def show_login(self, notice: str = ""):
        self._end_session()
        self.login_screen = LoginScreen(self, self.store, self.sign_in, notice)
        self.login_screen.pack(fill="both", expand=True)

    def sign_in(self, account: Account):
        """Open this account's own database file and build the app around it."""
        if self.login_screen is not None:
            self.login_screen.destroy()
            self.login_screen = None
        self.account = account
        self.store.set_last_user(account.username)
        Database.reset()
        Database.instance(self.store.db_path(account.username))
        self.users, self.history = UserRepository(), VisitLogRepository()
        self.user = self._profile_row(account)
        self._build_header()
        self._build_pages()
        self.history_drop = HistoryDrop(self)
        self.window_drop = WindowDrop(self)
        self._build_compact_bar()
        self.paint_user()
        self.show("home")

    def _profile_row(self, account: Account) -> User:
        """Each account database holds one profile row (decks and plans point at it)."""
        rows = self.users.all()
        if not rows:
            return self.users.add(User(account.username, account.color))
        u = rows[0]
        if (u.name, u.color) != (account.username, account.color):
            u.name, u.color = account.username, account.color
            self.users.update(u)
        return u

    def _end_session(self):
        if self.compact:                                  # leave compact mode so the login screen gets a normal window
            self.compact = False
            self.minsize(*FULL_MIN)
            self.geometry(self._full_geometry)
        for name in ("header", "header_line", "stage", "history_drop", "window_drop", "compact_bar", "login_screen"):
            w = getattr(self, name)
            if w is not None:
                w.destroy()
                setattr(self, name, None)
        self.views, self.pages, self.route, self.user = [], {}, "", None
        self.win_btn = self.compact_title = None
        Database.reset()

    def sign_out(self):
        self.show_login()

    def reset_data(self):
        """Throw away this account's database and rebuild it from the seed data (account and password stay)."""
        account = self.account
        self._end_session()
        self.store.wipe_data(account.username)
        self.sign_in(account)

    def remove_account(self):
        name = self.account.username
        self._end_session()
        self.store.delete(name)
        self.account = None
        self.show_login("Your account and all of its data were deleted.")

    def _quit(self):
        Database.reset()
        self.store.close()
        self.destroy()

    # ----- header (same three parts as the website) ----------------------------
    def _build_header(self):
        bar = self.header = tk.Frame(self, bg=theme.BG, height=self.header_h)
        bar.pack(fill="x", padx=16)
        bar.grid_propagate(False)
        bar.columnconfigure((0, 2), weight=1, uniform="hdr")
        bar.columnconfigure(1, weight=0)
        bar.rowconfigure(0, weight=1)

        self.hist_btn = BorderBox(bar, command=lambda: self.history_drop.toggle(), pad=(6, 5))
        self.hist_btn.grid(row=0, column=0, sticky="w")
        logo = tk.Canvas(self.hist_btn, width=30, height=30, bg=theme.BG, highlightthickness=0)
        logo.create_polygon(hex_points(15, 15, 15), fill=theme.BRAND, outline="")
        logo.create_text(15, 15, text="U", fill="#06201c", font=theme.display(13))
        logo.pack(side="left")
        lbl = tk.Label(self.hist_btn, text="HISTORY", bg=theme.BG, fg=theme.MUTE, font=theme.display(11))
        lbl.pack(side="left", padx=(8, 4))
        caret = tk.Label(self.hist_btn, text="\u25BE", bg=theme.BG, fg=theme.MUTE, font=theme.body(9))
        caret.pack(side="left")
        self.hist_btn.adopt(logo, lbl, caret)

        self.brand = tk.Canvas(bar, width=290, height=44, bg=theme.BG, highlightthickness=0, cursor="hand2")
        self.brand.grid(row=0, column=1)
        x = 8
        for text, color in (("UNI", theme.FG), ("GUY'D", theme.BRAND)):
            for ch in text:                                  # hand-spaced letters: Tk has no letter-spacing
                t = self.brand.create_text(x, 22, text=ch, anchor="w", fill=color, font=theme.display(27))
                x = self.brand.bbox(t)[2] + 5
        self.brand.bind("<Button-1>", lambda _e: self.show("home"))

        right = tk.Frame(bar, bg=theme.BG)
        right.grid(row=0, column=2, sticky="e")
        self.win_btn = BorderBox(right, command=lambda: self.window_drop.toggle(), pad=(10, 5))
        self.win_btn.pack(side="left", padx=(0, 8))
        self.pin_dot = tk.Canvas(self.win_btn, width=10, height=10, bg=theme.BG, highlightthickness=0)
        self.pin_dot.pack(side="left", padx=(0, 7))
        win_lbl = tk.Label(self.win_btn, text="WINDOW", bg=theme.BG, fg=theme.MUTE, font=theme.display(11))
        win_lbl.pack(side="left")
        self.win_btn.adopt(self.pin_dot, win_lbl)
        self.acct = BorderBox(right, command=self._account_menu, pad=(6, 5))
        self.acct.pack(side="left")
        self.avatar = tk.Canvas(self.acct, width=30, height=30, bg=theme.BG, highlightthickness=0)
        self.avatar.pack(side="left")
        self.acct_name = tk.Label(self.acct, text="", bg=theme.BG, fg=theme.FG, font=theme.display(13))
        self.acct_name.pack(side="left", padx=(8, 4))
        self.acct.adopt(self.avatar, self.acct_name)
        self.header_line = tk.Frame(self, bg=theme.LINE, height=1)
        self.header_line.pack(fill="x")

    def _build_pages(self):
        self.stage = tk.Frame(self, bg=theme.BG)
        self.stage.pack(fill="both", expand=True)
        self.stage.rowconfigure(0, weight=1)
        self.stage.columnconfigure(0, weight=1)
        home = [("Home", "home")]
        uma = home + [("Umamusume", "uma")]
        spec = [
            ("home", HomeView, [], None),
            ("uma", UmaHub, home + [("Umamusume", None)], None),
            ("uma-chars", HorseView, uma + [("Character tier lists", None)], UMA_TABS),
            ("uma-support", CardView, uma + [("Support card tier lists", None)], UMA_TABS),
            ("uma-skills", SkillView, uma + [("Skills directory", None)], UMA_TABS),
            ("uma-deck", DeckBuilderView, uma + [("Deck builder", None)], UMA_TABS),
            ("uma-gacha", GachaView, uma + [("Gacha economy", None)], UMA_TABS),
            ("apex-chars", LegendView, home + [("Apex Legends", None)], APEX_TABS),
            ("apex-guns", WeaponView, home + [("Apex Legends", "apex-chars"), ("Weapon menu", None)], APEX_TABS),
            ("apex-builder", WeaponBuilderView, home + [("Apex Legends", "apex-chars"), ("Weapon builder", None)], APEX_TABS),
            ("apex-maps", MapView, home + [("Apex Legends", "apex-chars"), ("Maps", None)], APEX_TABS),
            ("profile", ProfileView, home + [("Profile", None)], None),
        ]
        for route, view_cls, crumbs, tabs in spec:
            page = Page(self.stage, self, view_cls, route, crumbs, tabs)
            page.grid(row=0, column=0, sticky="nsew")
            self.pages[route] = page
            self.views.append(page.view)
        self.home = self.pages["home"].view
        self.profile = self.pages["profile"].view

    # ----- navigation ----------------------------------------------------------
    def show(self, route: str):
        route = ALIASES.get(route, route)
        if route not in self.pages:
            return
        if self.compact and route not in COMPACT_ROUTES:
            self.set_compact(False)                       # these pages need the full window
        self.route = route
        if self.compact_title is not None:
            self.compact_title.configure(text=LABELS[route].split(" > ")[-1].upper())
        page = self.pages[route]
        if hasattr(page, "tabs"):
            page.tabs.select(route)          # each page has its own tab bar: keep its highlight in sync
        page.tkraise()
        self.update_idletasks()
        for d in (self.history_drop, self.window_drop):
            if d:
                d.hide()
        self.log_visit(LABELS[route])
        if route == "home":
            self.home.refresh()
        elif route == "profile":
            self.profile.reload_user()

    def log_visit(self, label: str):
        self.history.log(self.user.id, label)

    def _click_away(self, e):
        for drop, button in ((self.history_drop, getattr(self, "hist_btn", None)), (self.window_drop, self.win_btn)):
            if not drop or not drop.shown:
                continue
            w = e.widget
            while w is not None:
                if w is drop or w is button:
                    break
                w = getattr(w, "master", None)
            else:
                drop.hide()

    def notify_data_changed(self, source=None):
        for v in self.views:
            if v is not source and hasattr(v, "on_data_changed"):
                v.on_data_changed()

    # ----- profiles ------------------------------------------------------------
    # ----- window: always on top, opacity, compact mode -------------------------------
    MIN_ALPHA = 0.35

    def apply_window_settings(self):
        pinned = bool(self.pin_var.get())
        alpha = round(max(self.MIN_ALPHA, min(1.0, float(self.alpha_var.get()))), 2)
        try:
            self.attributes("-topmost", pinned)
            self.attributes("-alpha", alpha)              # needs a compositor on Linux; Windows/macOS always work
        except tk.TclError:
            pass
        self.store.set_setting("pinned", "1" if pinned else "0")
        self.store.set_setting("opacity", alpha)
        if self.win_btn is not None:
            self.pin_dot.delete("all")
            self.pin_dot.create_oval(1, 1, 9, 9, fill=theme.BRAND if pinned else theme.LINE, outline="")
            self.window_drop.pct.configure(text=f"{round(alpha * 100)}%")
        if self.compact_bar is not None:
            self.pin_box.configure(bg=theme.BRAND if pinned else theme.BG)
            self.pin_lbl.configure(bg=theme.BRAND if pinned else theme.BG, fg="#06201c" if pinned else theme.MUTE)

    def toggle_pin(self):
        self.pin_var.set(not self.pin_var.get())
        self.apply_window_settings()

    def set_compact(self, on: bool):
        if on == self.compact or self.stage is None:
            return
        self.compact = on
        for d in (self.history_drop, self.window_drop):
            d.hide()
        if on:
            self._full_geometry = self.geometry()
            self.header.pack_forget()
            self.header_line.pack_forget()
            self.compact_bar.pack(fill="x", padx=10, before=self.stage)
            self.minsize(460, 520)
            self.geometry(f"{COMPACT_SIZE[0]}x{COMPACT_SIZE[1]}+{max(self.winfo_x(), 0)}+{max(self.winfo_y(), 0)}")
        else:
            self.compact_bar.pack_forget()
            self.header.pack(fill="x", padx=16, before=self.stage)
            self.header_line.pack(fill="x", before=self.stage)
            self.minsize(*FULL_MIN)
            if self._full_geometry:
                self.geometry(self._full_geometry)
        for page in self.pages.values():
            page.set_compact(on)
        if on and self.route not in COMPACT_ROUTES:
            self.show("home")
        elif on:
            self.show(self.route)                         # refresh the title in the compact bar

    def _build_compact_bar(self):
        """Slim top bar used in compact mode: page menu, opacity, pin, expand."""
        bar = self.compact_bar = tk.Frame(self, bg=theme.BG)
        row = tk.Frame(bar, bg=theme.BG, height=46)
        row.pack(fill="x")
        row.pack_propagate(False)
        nav = BorderBox(row, command=self._compact_menu, pad=(6, 4))
        nav.pack(side="left", pady=6)
        logo = tk.Canvas(nav, width=26, height=26, bg=theme.BG, highlightthickness=0)
        logo.create_polygon(hex_points(13, 13, 13), fill=theme.BRAND, outline="")
        logo.create_text(13, 13, text="U", fill="#06201c", font=theme.display(11))
        logo.pack(side="left")
        self.compact_title = tk.Label(nav, text="HOME", bg=theme.BG, fg=theme.FG, font=theme.display(12))
        self.compact_title.pack(side="left", padx=(8, 4))
        caret = tk.Label(nav, text="\u25BE", bg=theme.BG, fg=theme.MUTE, font=theme.body(9))
        caret.pack(side="left")
        nav.adopt(logo, self.compact_title, caret)

        expand = BorderBox(row, command=lambda: self.set_compact(False), pad=(10, 4))
        expand.pack(side="right", pady=6)
        el = tk.Label(expand, text="EXPAND", bg=theme.BG, fg=theme.MUTE, font=theme.display(10))
        el.pack()
        expand.adopt(el)
        self.pin_box = BorderBox(row, command=self.toggle_pin, pad=(10, 4))
        self.pin_box.pack(side="right", padx=8, pady=6)
        self.pin_lbl = tk.Label(self.pin_box, text="PIN", bg=theme.BG, fg=theme.MUTE, font=theme.display(10))
        self.pin_lbl.pack()
        self.pin_box.adopt(self.pin_lbl)
        ttk.Scale(row, from_=self.MIN_ALPHA, to=1.0, variable=self.alpha_var, length=90,
                  command=lambda _v: self.apply_window_settings()).pack(side="right", padx=(0, 4))
        tk.Label(row, text="OPACITY", bg=theme.BG, fg=theme.MUTE, font=theme.display(9)).pack(side="right", padx=(0, 6))
        tk.Frame(bar, bg=theme.LINE, height=1).pack(fill="x")
        self.apply_window_settings()

    def _compact_menu(self):
        m = tk.Menu(self, tearoff=0, bg=theme.PANEL, fg=theme.FG, activebackground=theme.BRAND,
                    activeforeground="#06201c", disabledforeground=theme.MUTE, bd=1, relief="solid",
                    font=theme.body(10))
        m.add_command(label="Home", command=lambda: self.show("home"))
        for head, items in (("Umamusume", ("uma", "uma-chars", "uma-support", "uma-skills")),
                            ("Apex Legends", ("apex-chars", "apex-guns", "apex-builder", "apex-maps"))):
            m.add_separator()
            m.add_command(label=head.upper(), state="disabled")
            for r in items:
                m.add_command(label="   " + LABELS[r].split(" > ")[-1], command=lambda r=r: self.show(r))
        m.add_separator()
        m.add_command(label="Expand (deck builder, gacha, account)", command=lambda: self.set_compact(False))
        m.tk_popup(self.compact_bar.winfo_rootx(), self.compact_bar.winfo_rooty() + 44)

    def _account_menu(self):
        m = tk.Menu(self, tearoff=0, bg=theme.PANEL, fg=theme.FG, activebackground=theme.BRAND,
                    activeforeground="#06201c", disabledforeground=theme.MUTE, bd=1, relief="solid",
                    font=theme.body(10))
        m.add_command(label=f"Signed in as {self.account.username}", state="disabled")
        m.add_separator()
        m.add_command(label="Account & data", command=lambda: self.show("profile"))
        m.add_command(label="Log out", command=self.sign_out)
        m.tk_popup(self.acct.winfo_rootx(), self.acct.winfo_rooty() + self.acct.winfo_height())

    def paint_user(self):
        self.acct_name.configure(text=self.account.username.upper())
        self.avatar.delete("all")
        self.avatar.create_oval(1, 1, 29, 29, fill=self.user.color, outline="")
        self.avatar.create_text(15, 15, text=self.user.initial, fill="#06100f", font=theme.display(13))
