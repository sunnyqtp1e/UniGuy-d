"""Run with:  python -m unittest discover -s tests -v"""
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from uniguy.auth import AccountStore, AuthError
from uniguy.database import Database
from uniguy.models import (Deck, Entity, GachaPlan, Horse, Legend, Rankable, Skill, SupportCard, User,
                           ValidationError)
from uniguy.repositories import (CardRepository, DeckRepository, GachaPlanRepository, HorseRepository,
                                 LegendRepository, MapRepository, RepositoryError, SkillRepository,
                                 UserRepository, VisitLogRepository, WeaponRepository)
from uniguy.services import (DeckService, GachaCalculator, TierService, WeaponBuild)


class DbCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        Database.reset()
        self.db = Database.instance(Path(self.tmp.name) / "test.db")

    def tearDown(self):
        Database.reset()
        self.tmp.cleanup()


class TestSeedData(DbCase):
    def test_row_counts_match_the_original_html(self):
        self.assertEqual(HorseRepository().count(), 69)
        self.assertEqual(CardRepository().count(), 200)
        self.assertEqual(SkillRepository().count(), 24)
        self.assertEqual(LegendRepository().count(), 28)
        self.assertEqual(WeaponRepository().count(), 32)
        self.assertEqual(MapRepository().count(), 6)

    def test_relationships_are_loaded(self):
        card = CardRepository().find_by_name("Kitasan Black [Fire at My Heels]")
        self.assertEqual(sorted(s.name for s in card.skills), ["Concentration", "Swinging Maestro"])
        ash = LegendRepository().find_by_name("Ash")
        self.assertEqual(ash.legend_class.name, "Skirmisher")
        self.assertTrue(any(p.is_meta for p in ash.perks_at("purple")))
        self.assertEqual(len(MapRepository().find_by_name("Olympus").picks), 3)


class TestOOPRules(unittest.TestCase):
    def test_abstract_classes_cannot_be_created(self):
        with self.assertRaises(TypeError):
            Entity("x")
        with self.assertRaises(TypeError):
            Rankable()

    def test_inheritance_and_polymorphism(self):
        horse = Horse("Test", [1, 2, 3, 10])
        skill = Skill("Zoom", "Speed", "A")
        card = SupportCard("Card", "SSR", "Speed", 8)
        for obj in (horse, skill, card):
            self.assertIsInstance(obj, Entity)
            self.assertIsInstance(obj, Rankable)
            self.assertIsInstance(obj.score(), (float, int))
            self.assertTrue(obj.summary())
        self.assertAlmostEqual(horse.score(), 5.0)     # (10+3+2)/3

    def test_encapsulation_validates_values(self):
        with self.assertRaises(ValidationError):
            Horse("  ", [1, 2, 3, 4])
        with self.assertRaises(ValidationError):
            Horse("A", [1, 2, 3, 11])
        with self.assertRaises(ValidationError):
            Skill("S", "Speed", "Z")
        with self.assertRaises(ValidationError):
            SupportCard("C", "UR", "Speed", 5)
        card = SupportCard("C", "SR", "Guts", 5)
        with self.assertRaises(ValidationError):
            card.rating = 99

    def test_deck_rules(self):
        horse = Horse("H", [5, 5, 5, 5], id=1)
        deck = Deck("D", 1, horse)
        cards = [SupportCard(f"C{i}", "R", "Speed", 5, id=i + 1) for i in range(7)]
        for c in cards[:6]:
            deck.add_card(c)
        with self.assertRaises(ValidationError):
            deck.add_card(cards[6])           # seventh card
        with self.assertRaises(ValidationError):
            deck.add_card(cards[0])           # duplicate


class TestCrud(DbCase):
    def test_create_read_update_delete_horse(self):
        repo = HorseRepository()
        h = repo.add(Horse("Brand New", [1, 2, 3, 4]))
        self.assertIsNotNone(h.id)
        self.assertEqual(repo.get(h.id).aptitude("Long"), 4)
        h.aptitudes = [9, 9, 9, 9]
        repo.update(h)
        self.assertEqual(repo.get(h.id).score(), 9)
        repo.delete(h.id)
        self.assertIsNone(repo.get(h.id))

    def test_unique_name_gives_friendly_error(self):
        repo = HorseRepository()
        with self.assertRaises(RepositoryError) as cm:
            repo.add(Horse("Special Week", [1, 1, 1, 1]))
        self.assertIn("already exists", str(cm.exception))

    def test_card_skill_link_table_is_updated(self):
        repo = CardRepository()
        skills = SkillRepository().all()[:3]
        card = repo.add(SupportCard("Test card", "SSR", "Power", 7, {"Power": 20}, skills))
        self.assertEqual(len(repo.get(card.id).skills), 3)
        card.skills = skills[:1]
        repo.update(card)
        self.assertEqual(len(repo.get(card.id).skills), 1)

    def test_deleting_a_skill_removes_it_from_cards_but_keeps_cards(self):
        skills = SkillRepository()
        s = skills.find_by_name("Concentration")
        cards_before = CardRepository().count()
        skills.delete(s.id)
        self.assertEqual(CardRepository().count(), cards_before)
        self.assertEqual(self.db.query_one("SELECT COUNT(*) n FROM card_skills WHERE skill_id=?", (s.id,))["n"], 0)

    def test_cannot_delete_class_that_is_in_use(self):
        from uniguy.repositories import LegendClassRepository
        repo = LegendClassRepository()
        with self.assertRaises(RepositoryError):
            repo.delete(repo.find_by_name("Assault").id)

    def test_search(self):
        names = [h.name for h in HorseRepository().search("kitasan")]
        self.assertEqual(names, ["Kitasan Black"])

    def test_legend_perk_add_remove(self):
        from uniguy.models import Perk
        repo = LegendRepository()
        wraith = repo.find_by_name("Wraith")
        n = len(wraith.perks)
        repo.add_perk(wraith, Perk("blue", "Test perk", "desc"))
        self.assertEqual(len(repo.get(wraith.id).perks), n + 1)
        repo.remove_perk(wraith, wraith.perks[-1])
        self.assertEqual(len(repo.get(wraith.id).perks), n)

    def test_map_picks(self):
        repo = MapRepository()
        m = repo.find_by_name("Olympus")
        legends = LegendRepository()
        repo.set_picks(m, [(legends.find_by_name("Wraith"), "portals")])
        again = repo.get(m.id)
        self.assertEqual([(l.name, r) for l, r in again.picks], [("Wraith", "portals")])


class TestUserData(DbCase):
    def test_decks_and_plans_belong_to_a_user(self):
        users = UserRepository()
        a = users.all()[0]
        b = users.add(__import__("uniguy.models", fromlist=["User"]).User("Second"))
        horse = HorseRepository().all()[0]
        card = CardRepository().all()[0]
        decks = DeckRepository()
        d = decks.add(Deck("Mine", a.id, horse, "Mile", [card]))
        self.assertEqual([x.name for x in decks.for_user(a.id)], ["Mine"])
        self.assertEqual(decks.for_user(b.id), [])
        loaded = decks.get(d.id)
        self.assertEqual(loaded.track, "Mile")
        self.assertEqual(len(loaded.cards), 1)
        plans = GachaPlanRepository()
        plans.add(GachaPlan("Plan", a.id, {"carats": 1234}))
        self.assertEqual(plans.for_user(a.id)[0].params["carats"], 1234)
        users.delete(a.id)                                 # ON DELETE CASCADE
        self.assertEqual(decks.count(), 0)
        self.assertEqual(plans.count(), 0)

    def test_visit_log_ignores_repeats(self):
        u = UserRepository().all()[0]
        log = VisitLogRepository()
        log.log(u.id, "Home")
        log.log(u.id, "Home")
        log.log(u.id, "Profile")
        self.assertEqual([p for p, _ in log.recent(u.id)], ["Profile", "Home"])


class TestServices(DbCase):
    def test_tier_list_split(self):
        tiers = TierService.tierize(HorseRepository().all())
        self.assertEqual(sum(len(v) for v in tiers.values()), 69)
        self.assertEqual(len(tiers["S"]), 10)           # top 15% of 69, same as the website

    def test_deck_analysis(self):
        horse = HorseRepository().find_by_name("Special Week")
        cards = [CardRepository().find_by_name("Kitasan Black [Fire at My Heels]")]
        r = DeckService.analyse(Deck("d", 1, horse, "Medium", cards))
        self.assertEqual(r.totals["Speed"], 29)
        self.assertEqual(r.average_fit, 96)
        self.assertTrue(any("1 of 6" in w for w in r.warnings))

    def test_gacha_defaults_match_the_website(self):
        r = GachaCalculator(GachaPlan("x", 1).params).calculate()
        self.assertEqual((r.carats, r.pulls, r.total, r.probability, r.remaining),
                         (16950, 118, 158, 69.6, 42))

    def test_weapon_build(self):
        w = WeaponRepository().find_by_name("R-99")
        plain = WeaponBuild(w, 0, 0, 0).calculate()
        self.assertEqual(plain.mag_size, 22)
        purple = WeaponBuild(w, 3, 3, 3).calculate()
        self.assertAlmostEqual(purple.mag_size, 33)
        self.assertEqual(purple.hipfire, 81)
        laser = WeaponBuild(w, 3, 3, 3, "Tactical Laser").calculate()
        self.assertLess(laser.reload_time, purple.reload_time)
        bad = WeaponBuild(w, 3, 3, 3, "Rapid Sniper Stock")   # not compatible -> ignored
        self.assertIsNone(bad.corrupted)


class TestAccounts(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = AccountStore(self.tmp.name, legacy_db=None)

    def tearDown(self):
        Database.reset()
        self.store.close()
        self.tmp.cleanup()

    def test_create_and_login(self):
        self.store.create("Alice", "secret1")
        self.assertEqual(self.store.verify("alice", "secret1").username, "Alice")   # name is case-insensitive
        with self.assertRaises(AuthError):
            self.store.verify("Alice", "wrong-pass")
        with self.assertRaises(AuthError):
            self.store.verify("nobody", "secret1")
        self.assertEqual(self.store.BAD_LOGIN, self._msg(lambda: self.store.verify("nobody", "x")))

    def _msg(self, fn):
        try:
            fn()
        except AuthError as e:
            return str(e)

    def test_validation(self):
        for name, pw in (("ab", "secret1"), ("bad name!", "secret1"), ("x" * 21, "secret1"), ("Okname", "123")):
            with self.assertRaises(AuthError):
                self.store.create(name, pw)
        self.store.create("Okname", "secret1")
        with self.assertRaises(AuthError):
            self.store.create("OKNAME", "secret1")                                  # taken

    def test_password_is_not_stored_in_plain_text(self):
        self.store.create("Alice", "secret1")
        row = self.store._db.execute("SELECT * FROM accounts").fetchone()
        self.assertNotIn("secret1", " ".join(str(v) for v in tuple(row)))
        self.store.create("Bob", "secret1")                                         # same password, different salt
        hashes = [r[0] for r in self.store._db.execute("SELECT pw_hash FROM accounts")]
        self.assertEqual(len(set(hashes)), 2)

    def test_change_password(self):
        self.store.create("Alice", "secret1")
        with self.assertRaises(AuthError):
            self.store.change_password("Alice", "nope", "newpass1")
        self.store.change_password("Alice", "secret1", "newpass1")
        self.store.verify("Alice", "newpass1")
        with self.assertRaises(AuthError):
            self.store.verify("Alice", "secret1")

    def test_each_account_has_its_own_database(self):
        a, b = self.store.create("Alice", "secret1"), self.store.create("Bob", "secret1")
        Database.reset()
        da = Database.instance(self.store.db_path(a.username))
        da.execute("UPDATE horses SET apt_sprint=1 WHERE name='Special Week'")
        Database.reset()
        db = Database.instance(self.store.db_path(b.username))
        self.assertNotEqual(db.query_one("SELECT apt_sprint FROM horses WHERE name='Special Week'")[0], 1)

    def test_delete_account_removes_its_file(self):
        a = self.store.create("Alice", "secret1")
        Database.reset()
        Database.instance(self.store.db_path(a.username))
        path = self.store.db_path(a.username)
        Database.reset()
        self.store.delete("Alice")
        self.assertFalse(path.exists())
        self.assertFalse(self.store.exists("Alice"))

    def test_delete_all_decks_only_for_that_user(self):
        a, b = self.store.create("Alice", "secret1"), self.store.create("Bob", "secret1")
        Database.reset()
        db = Database.instance(self.store.db_path(a.username))
        users = UserRepository()
        u1 = users.all()[0]
        u2 = users.add(User("Other"))
        horse, card = HorseRepository().all()[0], CardRepository().all()[0]
        repo = DeckRepository()
        repo.add(Deck("one", u1.id, horse, "Mile", [card]))
        repo.add(Deck("two", u2.id, horse, "Mile", [card]))
        self.assertEqual(repo.delete_for_user(u1.id), 1)
        self.assertEqual(len(repo.for_user(u1.id)), 0)
        self.assertEqual(len(repo.for_user(u2.id)), 1)
        self.assertEqual(db.query_one("SELECT COUNT(*) FROM deck_cards")[0], 1)    # cards removed with the deck


@unittest.skipUnless(os.environ.get("DISPLAY"), "needs a display (run under xvfb-run)")
class TestGui(DbCase):
    def test_every_screen_opens_and_crud_works(self):
        from uniguy.auth import AccountStore
        from uniguy.gui.app import App
        store = AccountStore(Path(self.tmp.name) / "acc", legacy_db=None)
        app = App(store)
        try:
            app.update()
            self.assertIsNotNone(app.login_screen)          # nothing is shown before logging in
            app.sign_in(store.create("tester", "secret1"))
            app.update()
            for route in app.pages:                       # every page opens, in both Board and Table mode
                app.show(route)
                app.update()
                view = app.pages[route].view
                if getattr(view, "board", None) is not None:
                    view._set_mode("table")
                    app.update()
                    view._set_mode("board")
                    app.update()
            self.assertEqual(app.route, list(app.pages)[-1])
            horses = next(v for v in app.views if type(v).__name__ == "HorseView")
            horses.new()
            horses.form.set({"name": "GUI Horse", "Sprint": 1, "Mile": 2, "Medium": 3, "Long": 4})
            horses.save()
            self.assertIsNotNone(HorseRepository().find_by_name("GUI Horse"))
            horses.search_var.set("GUI Horse")
            app.update()
            self.assertEqual(len(horses.tree.get_children()), 1)
            horses.tree.selection_set(horses.tree.get_children()[0])
            app.update()
            self.assertEqual(horses.current.name, "GUI Horse")
            horses.form.set({"name": "GUI Horse", "Sprint": 10, "Mile": 10, "Medium": 10, "Long": 10})
            horses.save()
            self.assertEqual(HorseRepository().find_by_name("GUI Horse").score(), 10)
            from tkinter import messagebox
            messagebox.askyesno = lambda *a, **k: True
            horses.delete()
            self.assertIsNone(HorseRepository().find_by_name("GUI Horse"))

            deck = next(v for v in app.views if type(v).__name__ == "DeckBuilderView")
            deck.picker.selection_set(deck.picker.get_children()[0])
            deck.add_card()
            deck.name_var.set("GUI deck")
            deck.save_deck()
            self.assertEqual(DeckRepository().for_user(app.user.id)[0].name, "GUI deck")

            gacha = next(v for v in app.views if type(v).__name__ == "GachaView")
            gacha.name_var.set("GUI plan")
            gacha.save_plan()
            self.assertEqual(GachaPlanRepository().for_user(app.user.id)[0].name, "GUI plan")
        finally:
            app.destroy()


if __name__ == "__main__":
    unittest.main()


@unittest.skipUnless(os.environ.get("DISPLAY"), "needs a display (run under xvfb-run)")
class TestWindowModes(unittest.TestCase):
    def test_compact_pin_and_opacity(self):
        from uniguy.gui.app import COMPACT_ROUTES, App
        with tempfile.TemporaryDirectory() as tmp:
            store = AccountStore(Path(tmp), legacy_db=None)
            app = App(store)
            try:
                app.sign_in(store.create("tester", "secret1"))
                app.update()
                app.toggle_pin()
                app.alpha_var.set(0.5)
                app.apply_window_settings()
                self.assertEqual((store.setting("pinned"), store.setting("opacity")), ("1", "0.5"))
                app.set_compact(True)
                app.update()
                self.assertTrue(app.compact)
                for route in sorted(COMPACT_ROUTES):          # every compact page opens without leaving compact mode
                    app.show(route)
                    app.update()
                    self.assertTrue(app.compact, route)
                app.show("uma-deck")                          # needs the full window: expands automatically
                app.update()
                self.assertFalse(app.compact)
                self.assertEqual(app.geometry().split("+")[0], "1280x820")
                app.set_compact(True)
                app.sign_out()                                # logging out while compact restores a normal window
                app.update()
                self.assertFalse(app.compact)
            finally:
                app._quit()
